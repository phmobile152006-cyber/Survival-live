// E2E dos mapas: escolhe cada mapa pelo painel, confere no jogo e tira screenshots.
// Uso: node scripts/e2e-maps.cjs [pasta-de-screenshots]   (requer Playwright)
const { chromium } = require('playwright');
const path = require('path');
const fs = require('fs');

(async () => {
  const out = process.argv[2] || path.join(__dirname, '..', 'e2e-out');
  fs.mkdirSync(out, { recursive: true });
  process.env.RANKING_FILE = require('path').join(require('os').tmpdir(), `sl-e2e-ranking-${process.pid}.json`); // não toca no ranking real
  const { start, stop } = await import('../server/server.js');
  const port = await start(3500, 20);
  const base = `http://127.0.0.1:${port}`;
  let fails = 0;
  const ok = (c, m) => { if (!c) { fails++; console.log('  ✗ FALHOU:', m); } else console.log('  ✓', m); };
  const browser = await chromium.launch();
  const ctx = await browser.newContext({ viewport: { width: 1920, height: 1080 } });
  const errors = [];
  const watch = (p, n) => { p.on('pageerror', (e) => errors.push(`${n}: ${e.message}`)); p.on('console', (m) => { if (m.type() === 'error') errors.push(`${n}: ${m.text()}`); }); };

  const game = await ctx.newPage(); watch(game, 'jogo');
  await game.goto(base + '/');
  await game.waitForFunction(() => window.__game && window.__game.fighters.length >= 3, null, { timeout: 15000 });
  ok(await game.evaluate(() => window.__game.map.theme.id) === 'forest', 'padrão continua sendo a Floresta');

  const admin = await ctx.newPage(); watch(admin, 'admin'); admin.on('dialog', (d) => d.accept());
  await admin.goto(base + '/admin.html');
  await admin.waitForFunction(() => document.querySelectorAll('#mapPick canvas').length === 3, null, { timeout: 20000 });
  ok(true, 'painel mostra 3 miniaturas de mapa + opção aleatória (' + (await admin.locator('.mapcard').count()) + ' cartões)');
  await admin.locator('#mapPick').screenshot({ path: path.join(out, 'admin-mapas.png') });

  for (const id of ['desert', 'snow', 'forest']) {
    await admin.click(`.mapcard[data-map=${id}]`);
    await admin.click('#btnMapApply');
    await game.waitForFunction((i) => window.__game.map.theme.id === i && window.__game.phase === 'lobby', id, { timeout: 8000 });
    ok(true, `painel trocou para "${id}" e reiniciou a sala`);
    await game.waitForTimeout(1200);
    await game.screenshot({ path: path.join(out, `${id}-1-lobby.png`) });
    await admin.click('[data-cmd=start]');
    await game.waitForFunction(() => window.__game.phase === 'playing', null, { timeout: 8000 });
    await game.waitForTimeout(5000);
    await game.evaluate(() => window.__game.command({ cmd: 'camera', mode: 'overview' }));
    await game.waitForTimeout(2500);
    await game.screenshot({ path: path.join(out, `${id}-2-visaogeral.png`) });
    await game.evaluate(() => window.__game.command({ cmd: 'camera', mode: 'auto' }));
    await game.waitForTimeout(3500);
    await game.screenshot({ path: path.join(out, `${id}-3-acao.png`) });
  }
  // persistência da escolha
  await admin.click('.mapcard[data-map=snow]'); await admin.click('#btnMapNext');
  await game.waitForFunction(() => window.__game.settings.get('mapId') === 'snow', null, { timeout: 5000 });
  ok(await game.evaluate(() => window.__game.map.theme.id) === 'forest', '"só na próxima rodada" não derruba a partida atual');
  await game.evaluate(() => window.__game.command({ cmd: 'endRound' }));
  await game.waitForFunction(() => window.__game.map.theme.id === 'snow', null, { timeout: 30000 });
  ok(true, 'na rodada seguinte o mapa escolhido é usado automaticamente');
  await game.reload();
  await game.waitForFunction(() => window.__game, null, { timeout: 10000 });
  ok(await game.evaluate(() => window.__game.map.theme.id) === 'snow', 'escolha persiste após recarregar o jogo (localStorage)');

  const real = errors.filter((e) => !/WebSocket|ERR_CONNECTION|Failed to load resource/i.test(e));
  ok(real.length === 0, 'sem erros JS no console' + (real.length ? ': ' + real.slice(0, 3).join(' | ') : ''));
  await stop(); await browser.close();
  console.log(fails ? `\n${fails} FALHA(S)` : '\nE2E dos mapas passou');
  process.exit(fails ? 1 : 0);
})().catch((e) => { console.error(e); process.exit(1); });
