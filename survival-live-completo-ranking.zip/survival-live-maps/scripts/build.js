// Build de produção: valida a sintaxe de todos os módulos e gera dist/ (site estático pronto para publicar).
// Não exige PORT nem nenhuma variável de ambiente.
import fs from 'node:fs';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const dist = path.join(root, 'dist');
const walk = (d) => fs.readdirSync(d, { withFileTypes: true }).flatMap((e) => (e.isDirectory() ? walk(path.join(d, e.name)) : [path.join(d, e.name)]));

console.log('› Verificando sintaxe…');
let bad = 0;
for (const f of [...walk(path.join(root, 'src')), ...walk(path.join(root, 'server')), ...walk(path.join(root, 'scripts'))].filter((f) => f.endsWith('.js'))) {
  const r = spawnSync(process.execPath, ['--check', f], { encoding: 'utf8' });
  if (r.status !== 0) { bad++; console.error(`✗ ${path.relative(root, f)}\n${r.stderr}`); }
}
if (bad) { console.error(`\nBuild falhou: ${bad} arquivo(s) com erro.`); process.exit(1); }

console.log('› Verificando referências de index.html e admin.html…');
for (const page of ['index.html', 'admin.html']) {
  const html = fs.readFileSync(path.join(root, page), 'utf8');
  for (const m of html.matchAll(/(?:src|href)="((?:src|styles|assets)\/[^"]+)"/g)) {
    if (!fs.existsSync(path.join(root, m[1]))) { console.error(`✗ ${page} referencia arquivo inexistente: ${m[1]}`); process.exit(1); }
  }
}

console.log('› Gerando dist/…');
fs.rmSync(dist, { recursive: true, force: true });
fs.mkdirSync(dist, { recursive: true });
for (const f of ['index.html', 'admin.html']) fs.copyFileSync(path.join(root, f), path.join(dist, f));
for (const d of ['src', 'styles', 'assets']) if (fs.existsSync(path.join(root, d))) fs.cpSync(path.join(root, d), path.join(dist, d), { recursive: true });
// sem Node: servidores estáticos só precisam do dist/. (O servidor WebSocket continua em server/.)
const files = walk(dist);
const size = files.reduce((s, f) => s + fs.statSync(f).size, 0);
console.log(`✓ Build concluído: ${files.length} arquivos, ${(size / 1024).toFixed(0)} KB em dist/`);
