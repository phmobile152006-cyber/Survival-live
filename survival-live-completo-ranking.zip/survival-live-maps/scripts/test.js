// Testes headless do núcleo do jogo + servidor. Uso: node scripts/test.js
import { Game } from '../src/game.js';
import { createSettings } from '../src/settings.js';
import { History } from '../src/leaderboard.js';
import os0 from 'node:os';
import path0 from 'node:path';
// os testes nunca tocam no ranking real: o servidor grava em um arquivo temporário
process.env.RANKING_FILE = path0.join(os0.tmpdir(), `survival-live-test-ranking-${process.pid}.json`);

let fails = 0;
const ok = (c, msg) => { if (!c) { fails++; console.log('  ✗ FALHOU:', msg); } else console.log('  ✓', msg); };

function mk(patch = {}) {
  const s = createSettings();
  s.patch({ fillBotsTo: 0, lobbyTime: 5, matchDuration: 120, ...patch }, false);
  const g = new Game({ settings: s, history: new History() });
  return g;
}
function step(g, secs, dt = 1 / 30) { for (let t = 0; t < secs; t += dt) g.update(dt); }
function sane(g) {
  for (const e of [...g.fighters, ...g.monsters]) {
    if (!Number.isFinite(e.x) || !Number.isFinite(e.y) || !Number.isFinite(e.hp)) return `NaN em ${e.name}`;
    if (e.x < 0 || e.y < 0 || e.x > g.map.w || e.y > g.map.h) return `fora do mapa: ${e.name}`;
  }
  return null;
}

console.log('1) Entrada por comentário (!entrar / !join)');
{
  const g = mk();
  ok(g.onChat('@alice', '!entrar') === 'ok', '!entrar adiciona jogador');
  ok(g.onChat('bob', '!JOIN') === 'ok', '!join (maiúsculas) adiciona jogador');
  ok(g.onChat('alice', '!entrar') === 'dup', 'duplicado é ignorado');
  ok(g.fighters.length === 2, '2 jogadores na sala');
  ok(g.onChat('carol', 'oi gente') === null, 'comentário comum é ignorado');
  g.onChat('alice', '!agressivo');
  ok(g.findFighter('alice').behavior === 'aggressive', '!agressivo muda comportamento');
  g.settings.patch({ maxPlayers: 3 }, false);
  g.onChat('d', '!entrar');
  ok(g.onChat('e', '!entrar') === 'full' && g.queue.length === 1, 'limite de jogadores envia para a fila');
}

console.log('2) Ciclo completo: sala de espera -> contagem -> partida -> vencedor -> nova rodada');
{
  const g = mk({ difficulty: 'normal' });
  g.command({ cmd: 'addBot', n: 12 });
  ok(g.fighters.length === 12, '12 bots adicionados');
  ok(g.phase === 'lobby' && g.countdown === null, 'sala de espera ainda sem contagem antes de update');
  step(g, 1);
  ok(g.countdown !== null && g.countdown < 5, 'contagem regressiva iniciou');
  let sawPlaying = false, sawEnding = false, err = null, winner = null;
  g.on('winner', (w) => { winner = w; });
  const kills = [];
  g.on('kill', (k) => kills.push(k));
  const t0 = Date.now();
  for (let i = 0; i < 30 * 600 && !sawEnding; i++) {
    g.update(1 / 30);
    if (g.phase === 'playing') sawPlaying = true;
    if (g.phase === 'ending') sawEnding = true;
    if (i % 30 === 0 && (err = sane(g))) break;
  }
  ok(!err, 'sem NaN / fora do mapa durante a partida (' + (err || 'ok') + ')');
  ok(sawPlaying, 'partida iniciou após contagem');
  ok(sawEnding && winner && winner.name, 'houve vencedor: ' + (winner && winner.name) + ' com ' + (winner && winner.kills) + ' abates, tempo ' + (winner && winner.time));
  ok(kills.length >= 11, 'eliminações anunciadas: ' + kills.length);
  console.log('    exemplos:', kills.slice(0, 3).map((k) => k.text).join(' | '));
  const pk = kills.filter((k) => k.killer).length;
  console.log(`    abates entre jogadores: ${pk}/${kills.length}`);
  console.log(`    tempo de CPU: ${Date.now() - t0}ms`);
  ok(g.history.winners.length === 1, 'histórico de campeões registrou');
  const r = g.round;
  step(g, 14);
  ok(g.phase === 'lobby' && g.round === r + 1, 'reinício automático para nova rodada');
}

console.log('3) Duração das partidas (8 partidas com 30 jogadores, devem terminar)');
{
  let durations = [];
  for (let n = 0; n < 8; n++) {
    const g = mk({ matchDuration: 300, difficulty: ['easy', 'normal', 'hard', 'insane'][n % 4] });
    g.command({ cmd: 'addBot', n: 30 });
    g.command({ cmd: 'start' });
    let ended = false;
    for (let i = 0; i < 30 * 600; i++) {
      g.update(1 / 30);
      if (g.phase === 'ending') { ended = true; break; }
      if (i % 60 === 0) { const e = sane(g); if (e) { ok(false, e); break; } }
    }
    durations.push(ended ? Math.round(g.time) : -1);
  }
  ok(durations.every((d) => d > 0), 'todas terminaram: ' + durations.join('s, ') + 's');
}

console.log('4) Eventos, monstros e presentes');
{
  const g = mk();
  g.command({ cmd: 'addBot', n: 10 });
  g.command({ cmd: 'start' });
  step(g, 4);
  for (const ev of ['meteors', 'zombies', 'storm', 'boss', 'supply']) {
    g.command({ cmd: 'event', name: ev });
  }
  ok(g.events.active.length >= 5, '5 eventos ativos');
  ok(g.monsters.some((m) => m.type === 'giant'), 'chefe gigante apareceu');
  ok(g.monsters.filter((m) => m.type === 'zombie').length > 10, 'zumbis presentes');
  ok(g.monsters.some((m) => m.type === 'wolf'), 'lobos presentes');
  step(g, 20);
  ok(!sane(g), 'estado válido após eventos');
  const p = g.fighters.find((f) => f.alive);
  p.hp = 40;
  g.onGift({ user: p.name, gift: 'Rose', count: 1 });
  ok(p.hp >= 65, 'Rosa cura (+25)');
  g.onGift({ user: p.name, gift: 'Heart' });
  ok(p.shield >= 40, 'Coração dá escudo');
  g.onGift({ user: p.name, gift: 'TikTok' });
  ok(p.rageT > 0, 'presente TikTok libera fúria');
  g.onGift({ user: p.name, gift: 'Lion' });
  ok(['staff', 'hammer', 'flame'].includes(p.weapon), 'Leão entrega arma especial');
  const n0 = g.events.active.length;
  g.onGift({ user: p.name, gift: 'Galaxy' });
  ok(g.events.active.length > n0 || g.events.active.some((e) => e.key === 'meteors'), 'Galáxia invoca meteoros');
  g.onGift({ user: p.name, gift: 'Universe' });
  g.onGift({ user: 'desconhecido', gift: 'PresenteNovo', coins: 2000 });
  ok(!sane(g), 'presentes desconhecidos por valor funcionam');
  const m = g.monsters.find((x) => x.alive && x.type === 'zombie');
  g.command({ cmd: 'summon', kind: 'wolf', n: 3 });
  ok(g.monsters.filter((x) => x.type === 'wolf').length >= 6, 'invocar monstros pelo painel');
  g.command({ cmd: 'pause' }); const t = g.time; step(g, 1); ok(g.time === t, 'pausa congela a simulação');
  g.command({ cmd: 'resume' });
  g.command({ cmd: 'remove', name: p.name });
  ok(!p.alive, 'remover jogador durante a partida o elimina');
  g.command({ cmd: 'restart' });
  ok(g.phase === 'lobby', 'reiniciar volta à sala de espera');
}

console.log('5) Entrada durante partida vai para a fila e entra na próxima rodada');
{
  const g = mk();
  g.command({ cmd: 'addBot', n: 4 });
  g.command({ cmd: 'start' });
  ok(g.onChat('late', '!entrar') === 'queued', 'espectador tardio entra na fila');
  g.command({ cmd: 'endRound' });
  step(g, 14);
  ok(g.phase === 'lobby' && g.findFighter('late'), 'fila entra na próxima rodada');
}

console.log('6) Servidor WebSocket, API e adaptador TikTok (sem biblioteca instalada)');
{
  const { start, stop } = await import('../server/server.js');
  const port = await start(3400, 30);
  const open = (role) => new Promise((res, rej) => {
    const ws = new WebSocket(`ws://127.0.0.1:${port}/ws`); const got = [];
    ws.onmessage = (e) => got.push(JSON.parse(e.data));
    ws.onopen = () => { ws.send(JSON.stringify({ type: 'hello', role })); res({ ws, got }); };
    ws.onerror = rej;
  });
  const wait = (ms) => new Promise((r) => setTimeout(r, ms));
  const a = await open('admin'), b = await open('game');
  await wait(100);
  a.ws.send(JSON.stringify({ type: 'cmd', cmd: 'start' }));
  await wait(150);
  ok(b.got.some((m) => m.type === 'cmd' && m.cmd === 'start'), 'servidor retransmite comandos do painel ao jogo');
  ok(!a.got.some((m) => m.type === 'cmd'), 'remetente não recebe o próprio eco');
  const r = await fetch(`http://127.0.0.1:${port}/api/event`, { method: 'POST', body: JSON.stringify({ type: 'gift', user: 'x', gift: 'Rose' }) });
  await wait(100);
  ok(r.ok && b.got.some((m) => m.type === 'gift' && m.gift === 'Rose'), 'POST /api/event chega ao jogo');
  const bad = await fetch(`http://127.0.0.1:${port}/api/event`, { method: 'POST', body: '{nope' });
  ok(bad.status === 400, 'JSON inválido é rejeitado (400)');
  const blocked = await fetch(`http://127.0.0.1:${port}/server/server.js`);
  ok(blocked.status === 403, 'código do servidor não é servido publicamente');
  const traversal = await fetch(`http://127.0.0.1:${port}/..%2f..%2fetc/passwd`);
  ok(traversal.status !== 200, 'path traversal bloqueado');
  const page = await fetch(`http://127.0.0.1:${port}/index.html`);
  ok(page.ok && (await page.text()).includes('SURVIVAL LIVE'), 'servidor entrega o jogo');
  a.ws.send(JSON.stringify({ type: 'tiktok.connect', username: 'alguem' }));
  await wait(600);
  const st = [...a.got, ...b.got].find((m) => m.type === 'tiktok.status' && m.state === 'error');
  ok(st && /não instalado|Falha/.test(st.message), 'sem biblioteca, o TikTok informa erro claro (nada é simulado): ' + (st && st.message.slice(0, 60)));
  // ranking no servidor: ack, retransmissão, deduplicação, persistência e id único nos eventos reais
  const srv = await import('../server/server.js');
  const op = { id: 'k:srv:1', t: 'kill', user: 'Wsuser', pts: 25, rid: 'r', ts: Date.now() };
  a.ws.send(JSON.stringify({ type: 'rank.op', op })); await wait(200);
  ok(a.got.some((m) => m.type === 'rank.ack' && m.ids[0] === 'k:srv:1'), 'servidor confirma (ack) a op do ranking');
  ok(b.got.filter((m) => m.type === 'rank.op' && m.op.id === 'k:srv:1').length === 1, 'op do ranking é retransmitida às outras telas');
  a.ws.send(JSON.stringify({ type: 'rank.op', op })); await wait(200);
  ok(b.got.filter((m) => m.type === 'rank.op' && m.op.id === 'k:srv:1').length === 1, 'op duplicada não é retransmitida de novo');
  const snap = await (await fetch(`http://127.0.0.1:${port}/api/ranking`)).json();
  ok(snap.state.profiles.wsuser && snap.state.profiles.wsuser.total.points === 25, 'GET /api/ranking devolve o estado (pontos contados uma vez)');
  srv.adapter.emit('event', { type: 'gift', src: 'tiktok', user: 'real1', gift: 'Rose', coins: 1 });
  srv.adapter.emit('event', { type: 'gift', src: 'tiktok', user: 'real1', gift: 'Rose', coins: 1 });
  await wait(150);
  const gifts = b.got.filter((m) => m.type === 'gift' && m.user === 'real1');
  ok(gifts.length === 2 && gifts[0].eid && gifts[0].eid !== gifts[1].eid && gifts[0].src === 'tiktok', 'eventos reais do TikTok saem do servidor com id único e origem "tiktok"');
  const noAuth = await fetch(`http://127.0.0.1:${port}/data/ranking.json`);
  ok(noAuth.status === 403, 'arquivo do ranking não é servido publicamente');
  a.ws.close(); b.ws.close();
  await stop();
}

console.log('7) Mapas (Floresta, Deserto, Montanha Congelada, Aleatório)');
{
  const { GameMap, PLAZA } = await import('../src/map.js');
  const { MAPS, MAP_IDS, resolveMapId } = await import('../src/maps.js');
  const { settings: gs } = await import('../src/settings.js');
  ok(MAP_IDS.length === 3 && MAP_IDS.includes('forest') && MAP_IDS.includes('desert') && MAP_IDS.includes('snow'), 'catálogo tem 3 mapas');
  gs.patch({ mapId: 'invalido' }, false); ok(gs.get('mapId') === 'forest', 'mapId inválido volta para a floresta');
  for (const id of MAP_IDS) {
    let bad = null; const stats = [];
    for (let n = 0; n < 6; n++) {
      const m = new GameMap(1000 + n * 7919, id);
      if (m.theme.id !== id) bad = 'tema errado';
      if (!m.trees.length || !m.houses.length || !m.mountains.length || !m.rocks.length || !m.bushes.length) bad = 'faltam elementos';
      if (!m.lakes.length || !m.swamps.length) bad = 'faltam lagos/áreas perigosas';
      if (m.solidAt(PLAZA.x, PLAZA.y, 30)) bad = 'praça bloqueada';
      for (const f of [...m.trees, ...m.rocks]) if (Math.hypot(f.x - PLAZA.x, f.y - PLAZA.y) < PLAZA.r) { bad = 'objeto dentro da praça'; break; }
      for (let k = 0; k < 40; k++) { const p = m.randomFree(Math.random, null, 30); if (m.solidAt(p.x, p.y, 20)) { bad = 'ponto livre dentro de sólido'; break; } }
      stats.push(`${m.trees.length}á/${m.houses.length}c/${m.mountains.length}m/${m.lakes.length}l`);
    }
    ok(!bad, `mapa "${MAPS[id].name}" gera corretamente (${bad || stats[0] + ' árvores/casas/montanhas/lagos'})`);
  }
  const t0 = MAPS.forest.gen;
  ok(t0.lakes === 4 && t0.mountains === 5 && t0.villages === 5 && t0.rocks === 90 && t0.forests === 12 && t0.scatterTrees === 160 && t0.bushes === 70, 'Floresta mantém exatamente os valores originais de geração');
  const seen = new Set(); for (let i = 0; i < 80; i++) seen.add(resolveMapId('random'));
  ok(seen.size === 3, 'modo Aleatório sorteia os 3 mapas');
  for (const id of MAP_IDS) {
    gs.patch({ mapId: id }, false);
    const g = mk({ difficulty: 'normal' });
    ok(g.map.theme.id === id, `Game usa o mapa escolhido nas configurações (${id})`);
    g.command({ cmd: 'addBot', n: 24 }); g.command({ cmd: 'start' });
    let ended = false, err = null;
    for (let i = 0; i < 30 * 700 && !ended; i++) { g.update(1 / 30); if (g.phase === 'ending') ended = true; if (i % 60 === 0 && (err = sane(g))) break; }
    ok(ended && !err, `partida completa no mapa ${id}: vencedor ${g.winner && g.winner.name}, ${Math.round(g.time)}s ${err || ''}`);
    g.command({ cmd: 'event', name: 'meteors' });
    const r = g.round; step(g, 14);
    ok(g.round === r + 1 && g.map.theme.id === id, `nova rodada mantém o mapa ${id}`);
  }
  gs.patch({ mapId: 'random' }, false);
  const ids = new Set(); const g = mk(); for (let i = 0; i < 25; i++) { g.newRound(); ids.add(g.map.theme.id); }
  ok(ids.size >= 2, 'com Aleatório o mapa muda entre rodadas: ' + [...ids].join(','));
  gs.patch({ mapId: 'forest' }, false);
}

console.log('8) Ranking de espectadores (pontos, perfis, níveis, persistência, deduplicação)');
{
  const V = await import('../src/viewers.js');
  const { RankingSystem } = await import('../src/ranking.js');
  const fs = await import('node:fs'); const os = await import('node:os'); const pth = await import('node:path');
  const mem = () => { const m = new Map(); return { getItem: (k) => (m.has(k) ? m.get(k) : null), setItem: (k, v) => m.set(k, String(v)), m }; };
  const cfg = V.sanitizeConfig({});
  ok(cfg.participation === 10 && cfg.elimination === 25 && cfg.victory === 100 && cfg.giftSmall === 5 && cfg.giftMedium === 25 && cfg.giftLarge === 100, 'pontuação padrão: +10 / +25 / +100 / presentes 5-25-100');

  // --- núcleo ---
  const st = new V.ViewerStore();
  const k1 = V.ops.kill('k:r1:bob', 'Alice', 'r1', cfg), k1b = { ...k1 };
  ok(st.apply(k1) === 'applied' && st.apply(k1b) === 'dup', 'mesma eliminação aplicada 2x conta só uma vez');
  ok(st.profile('alice').total.points === 25 && st.profile('ALICE').total.kills === 1, 'eliminação = +25 pontos; perfil é por usuário (sem diferenciar maiúsculas)');
  const m1 = V.ops.match('m:r1:alice', 'Alice', { rid: 'r1', round: 1, won: true, place: 1, kills: 1 }, cfg);
  st.apply(m1); st.apply(m1);
  const a = st.profile('alice');
  ok(a.total.points === 25 + 10 + 100 && a.total.wins === 1 && a.total.matches === 1, 'participação (+10) e vitória (+100) somadas uma única vez: ' + a.total.points);
  ok(a.history.length === 1 && a.history[0].won && a.history[0].pts === 135, 'histórico guarda a partida (inclui pontos das eliminações da rodada)');
  st.apply(V.ops.match('m:r1:bob', 'Bob', { rid: 'r1', round: 1, won: false, place: 2, kills: 0 }, cfg));
  ok(st.profile('bob').total.points === 10 && st.profile('bob').total.wins === 0, 'quem perde ganha só a participação');
  // presentes
  const gg = (id, g, coins, count, real) => st.apply(V.ops.gift(id, 'Carol', { gift: g, coins, count }, cfg, real));
  gg('g1', 'Rosa', 1, 1, false); gg('g2', 'Galaxy', 1000, 1, true); gg('g3', 'Doughnut', 30, 1, true); gg('g4', 'rose', 0, 3, false); gg('g4', 'rose', 0, 3, false);
  const c = st.profile('carol');
  ok(c.total.points === 5 + 100 + 25 + 15 && c.total.gifts === 1 + 1 + 1 + 3, `presentes: rosa +5, médio +25, grande +100, combo x3 +15 (dedup) = ${c.total.points}`);
  ok(c.total.giftsReal === 2 && c.real, 'presentes simulados não contam como reais; origem real marca o perfil');
  ok(V.giftTier('Lion', 0, 1, cfg) === 'L' && V.giftTier('Rosa', 0, 1, cfg) === 'S', 'sem preço, o tipo do presente define a faixa');
  // ajustes manuais
  st.apply(V.ops.adjust('a1', 'Bob', 500, 'bônus'));
  ok(st.profile('bob').total.points === 510, 'adicionar pontos manualmente');
  st.apply(V.ops.adjust('a2', 'Bob', -9999, 'teste'));
  ok(st.profile('bob').total.points === 0, 'remover pontos nunca deixa negativo');
  st.apply(V.ops.adjust('a3', 'Novato', 40, 'sorteio'));
  ok(st.profile('novato').total.points === 40, 'ajuste cria o perfil se não existir');
  ok(st.apply({ id: 'x', t: 'kill', user: '<>', pts: 5 }) === 'invalid' && st.apply({ t: 'kill', user: 'z' }) === 'invalid' && st.apply({ id: 'y', t: 'hack', user: 'z' }) === 'invalid', 'ops inválidas são rejeitadas');
  { const t = new V.ViewerStore(); ok(t.apply({ id: 'big', t: 'kill', user: 'cheater', pts: 9e12, rid: 'r' }) === 'applied' && t.profile('cheater').total.points <= 100000, 'pontos absurdos em uma op são limitados'); }
  // níveis
  const lv = (p) => V.levelOf(p).id;
  ok(lv(0) === 'bronze' && lv(249) === 'bronze' && lv(250) === 'silver' && lv(750) === 'gold' && lv(2000) === 'platinum' && lv(5000) === 'diamond' && lv(12000) === 'legendary', 'níveis Bronze→Lendário pelos pontos');
  const ups = []; st.on('levelup', (e) => ups.push(e.to.id));
  st.apply(V.ops.adjust('a4', 'Alice', 300, 'x'));
  ok(ups.join() === 'silver', 'subir de nível dispara o evento: ' + ups.join());
  ok(V.sanitizeConfig({ levelMins: [0, 900, 100, 50, 40, 30] }).levelMins.every((v, i, ar) => i === 0 || v > ar[i - 1]), 'limiares de nível configurados ficam sempre crescentes');
  // quadros e ordenação
  st.apply(V.ops.kill('k:r2:z1', 'Bob', 'r2', cfg)); st.apply(V.ops.kill('k:r2:z2', 'Bob', 'r2', cfg));
  ok(st.board({ sort: 'points' })[0].key === 'alice', 'ranking geral por pontos');
  ok(st.board({ sort: 'kills' })[0].key === 'bob' && st.board({ sort: 'wins' })[0].key === 'alice', 'ordenar por eliminações e por vitórias');
  ok(st.board({ sort: 'matches' }).length === st.size, 'ordenar por participação');
  ok(st.board({ search: 'ali' }).length === 1 && st.board({ search: '@ALI' })[0].name === 'Alice', 'busca por usuário');
  ok(st.board({ includeSim: false }).every((r) => r.real) && st.board({ includeSim: false }).length === 1, 'filtro de perfis simulados');
  const d = st.detail('alice');
  ok(d.rank === 1 && d.winRate === 100 && d.total.matches === 1 && d.level.id === 'silver', 'perfil: posição, taxa de vitória, nível');
  // semanal / mensal
  ok(st.board({ period: 'week' }).length > 0 && st.board({ period: 'month' })[0].points > 0, 'rankings semanal e mensal acumulam');
  st.apply(V.ops.reset('r1', 'week'));
  ok(st.board({ period: 'week' }).length === 0 && st.profile('alice').total.points > 0 && st.board({ period: 'month' }).length > 0, 'zerar semanal não afeta o geral nem o mensal');
  st.apply(V.ops.reset('r2', 'month'));
  ok(st.board({ period: 'month' }).length === 0, 'zerar mensal');
  st.apply(V.ops.kill('k:r3:q', 'Alice', 'r3', cfg));
  ok(st.board({ period: 'week' })[0].points === 25, 'pontuação volta a contar após o reset');
  // configuração
  st.apply(V.ops.config('c1', { ...cfg, elimination: 40 }));
  ok(st.config.elimination === 40, 'configuração de pontos alterada');
  // exportação / persistência / purge
  const csv = st.exportCSV(); ok(csv.split('\n')[0].startsWith('posicao,usuario') && csv.includes('Alice') && csv.split('\n').length === st.size + 1, 'exportação CSV');
  ok(JSON.parse(st.exportJSON()).profiles.length === st.size, 'exportação JSON');
  const copy = new V.ViewerStore(JSON.parse(JSON.stringify(st.snapshot())));
  ok(copy.profile('alice').total.points === st.profile('alice').total.points && copy.apply(k1) === 'dup', 'estado restaurado de JSON mantém pontos e a lista de ids (sem duplicar)');
  st.apply(V.ops.purge('p1'));
  ok(st.size === 1 && st.profile('carol'), 'apagar simulados mantém só perfis reais');

  // --- integração com o jogo (partidas reais com bots) ---
  const link = { send() {}, onMessage() {}, onStatus() {} };
  const storage = mem();
  const rk = new RankingSystem({ link, role: 'game', storage, fetchFn: null, base: '' });
  const g = mk({ difficulty: 'normal' });
  rk.attachGame(g);
  rk.withChat({ user: 'viewer1', src: 'tiktok' }, () => g.onChat('viewer1', '!entrar'));
  const VIEWERS = ['viewer1', 'viewer2', 'viewer3', 'viewer4', 'viewer5', 'viewer6', 'viewer7', 'viewer8'];
  for (const v of VIEWERS.slice(1)) g.onChat(v, '!entrar');
  g.command({ cmd: 'addBot', n: 3 });
  ok(rk.store.profile('viewer1') && rk.store.profile('viewer1').real && !rk.store.profile('viewer2').real, 'comentário real (TikTok) marca o perfil; comentário simulado não');
  ok(!rk.store.profile(g.fighters.find((f) => f.bot).name), 'bots não ganham perfil');
  g.command({ cmd: 'start' });
  const kills = []; g.on('kill', (k) => kills.push(k));
  g.command({ cmd: 'remove', name: 'viewer3' });
  let winner = null; g.on('winner', (w) => { winner = w; });
  for (let i = 0; i < 30 * 700 && g.phase !== 'ending'; i++) g.update(1 / 30);
  ok(g.phase === 'ending', 'partida terminou');
  const p1 = rk.store.profile('viewer1'), p2 = rk.store.profile('viewer2');
  ok(VIEWERS.filter((v) => v !== 'viewer3').every((v) => rk.store.profile(v).total.matches === 1), 'participação (partida concluída) registrada para todos que jogaram');
  ok(!rk.store.profile('viewer3') || rk.store.profile('viewer3').total.matches === 0, 'jogador removido pelo streamer não ganha participação');
  const expect = (n) => kills.filter((k) => k.killer === n).length;
  ok(VIEWERS.every((v) => (rk.store.profile(v) ? rk.store.profile(v).total.kills : 0) === expect(v)), 'eliminações de cada perfil = eliminações vistas no jogo');
  ok(VIEWERS.some((v) => expect(v) > 0), 'pelo menos um espectador eliminou alguém nesta partida (teste significativo)');
  if (winner && winner.name && !g.winner.bot) ok(rk.store.profile(winner.name).total.wins === 1, 'vencedor recebe a vitória: ' + winner.name); else ok(true, 'vencedor da rodada era bot — sem vitória de espectador');
  const total = (n) => rk.store.profile(n).total.points;
  ok(VIEWERS.filter((v) => v !== 'viewer3').every((v) => total(v) === expect(v) * 25 + 10 + (winner && winner.name === v ? 100 : 0)), 'pontos de cada espectador = 25/eliminação + 10 participação (+100 vitória)');
  // reprocessar o mesmo fim de partida não duplica
  const before = JSON.stringify(rk.store.snapshot().profiles);
  g.emit('winner', { name: winner && winner.name }); for (const k of [...kills]) g.emit('kill', k);
  ok(JSON.stringify(rk.store.snapshot().profiles) === before, 'reprocessar kill/winner não duplica pontos');
  // presentes pela ponte
  const { TikTokBridge } = await import('../src/tiktok-bridge.js');
  const handlers = []; const fakeLink = { onMessage: (f) => handlers.push(f), send() {}, onStatus() {} };
  const br = new TikTokBridge(g, fakeLink); br.ranking = rk;
  const gift = { type: 'gift', user: 'viewer1', gift: 'Rose', count: 1, coins: 1, src: 'tiktok', eid: 'srv-1' };
  const p0 = total('viewer1'); handlers[0](gift); handlers[0](gift);
  ok(total('viewer1') === p0 + 5 && rk.store.profile('viewer1').total.giftsReal === 1, 'presente real (TikTok): +5 e entregue duas vezes conta uma');
  handlers[0]({ type: 'gift', user: 'viewer2', gift: 'Rose', count: 1, src: 'sim', _id: 'a1' });
  ok(rk.store.profile('viewer2').total.gifts === 1 && rk.store.profile('viewer2').total.giftsReal === 0, 'presente simulado conta pontos, mas nunca como presente real');
  rk.flush();
  const rk2 = new RankingSystem({ link, role: 'game', storage, fetchFn: null, base: '' });
  ok(rk2.store.profile('viewer1').total.points === total('viewer1') && rk2.store.size === rk.store.size, 'ranking sobrevive a recarregar a página (localStorage)');
  ok(rk2.badgeOf('viewer1') === null || rk2.badgeOf('viewer1').index >= 1, 'emblema de nível disponível para a arena');
}

{
  console.log('   servidor: persistência em arquivo e sincronização');
  const V = await import('../src/viewers.js');
  const { RankingStore } = await import('../server/ranking-store.js');
  const fs = await import('node:fs'); const os = await import('node:os'); const pth = await import('node:path');
  const file = pth.join(fs.mkdtempSync(pth.join(os.tmpdir(), 'rk-')), 'data', 'ranking.json');
  const cfg = V.sanitizeConfig({});
  const a = new RankingStore(file);
  a.apply(V.ops.kill('k:1:x', 'Zed', 'r', cfg)); a.apply(V.ops.match('m:1:zed', 'Zed', { rid: 'r', round: 1, won: true, place: 1, kills: 1 }, cfg, true));
  a.flush();
  ok(fs.existsSync(file), 'servidor grava data/ranking.json');
  const b = new RankingStore(file);
  ok(b.snapshot().profiles.zed.total.points === 135 && b.apply(V.ops.kill('k:1:x', 'Zed', 'r', cfg)) === 'dup', 'ranking sobrevive ao reinício do servidor e continua sem duplicar');
  fs.writeFileSync(file, '{ quebrado');
  const c = new RankingStore(file);
  ok(c.snapshot().rev === 0 && fs.readdirSync(pth.dirname(file)).some((f) => f.includes('corrompido')), 'arquivo corrompido é preservado e o servidor inicia limpo');
  const e = new RankingStore(pth.join(pth.dirname(file), 'novo.json'));
  ok(e.importState(a.snapshot()) === true && e.importState(a.snapshot()) === false, 'importação inicial só é aceita com o servidor vazio');
}

console.log(fails ? `\n${fails} FALHA(S)` : '\nTodos os testes passaram');
process.exit(fails ? 1 : 0);
