// Teste ponta a ponta (opcional, requer Playwright instalado): node scripts/e2e.cjs [pasta-de-screenshots]
const { chromium } = require('playwright');
const path = require('path');
const fs = require('fs');

(async () => {
  const out = process.argv[2] || path.join(__dirname, '..', 'e2e-out');
  fs.mkdirSync(out, { recursive: true });
  process.env.RANKING_FILE = require('path').join(require('os').tmpdir(), `sl-e2e-ranking-${process.pid}.json`); // não toca no ranking real
  const { start, stop } = await import('../server/server.js');
  const port = await start(3100, 20);
  const base = `http://127.0.0.1:${port}`;
  let fails = 0;
  const ok = (c, m) => { if (!c) { fails++; console.log('  ✗ FALHOU:', m); } else console.log('  ✓', m); };

  const browser = await chromium.launch();
  const ctx = await browser.newContext({ viewport: { width: 1920, height: 1080 } });
  const errors = [];
  const watch = (p, name) => { p.on('pageerror', (e) => errors.push(`${name}: ${e.message}`)); p.on('console', (m) => { if (m.type() === 'error') errors.push(`${name}: ${m.text()}`); }); };

  const game = await ctx.newPage(); watch(game, 'jogo');
  await game.goto(base + '/');
  await game.waitForFunction(() => window.__game && window.__game.fighters.length >= 3, null, { timeout: 15000 });
  ok(true, 'jogo abriu e a sala de espera recebeu bots (modo demonstração)');
  await game.waitForTimeout(1500);
  await game.screenshot({ path: path.join(out, '1-lobby.png') });

  const admin = await ctx.newPage(); watch(admin, 'admin');
  await admin.goto(base + '/admin.html');
  await admin.waitForFunction(() => document.getElementById('gameStatus').textContent.includes('conectado') && !document.getElementById('gameStatus').textContent.includes('desconectado'), null, { timeout: 10000 });
  ok(true, 'painel detectou o jogo (estado em tempo real)');
  await admin.waitForFunction(() => document.getElementById('wsStatus').textContent.includes('servidor: conectado'), null, { timeout: 8000 });
  ok(true, 'WebSocket conectado ao servidor');

  // botões do painel
  await admin.fill('#simUser', 'espectador_teste'); await admin.fill('#simText', '!entrar'); await admin.click('#btnChat');
  await game.waitForFunction(() => window.__game.findFighter('espectador_teste'), null, { timeout: 5000 });
  ok(true, 'comentário simulado "!entrar" criou o jogador');
  await admin.fill('#newName', 'manual1'); await admin.click('#btnAddPlayer');
  await game.waitForFunction(() => window.__game.findFighter('manual1'), null, { timeout: 5000 });
  ok(true, 'botão "Adicionar jogador" funciona');
  await admin.click('#btnAddBots');
  await admin.fill('#s_maxPlayers', '20'); await admin.fill('#s_lobbyTime', '5'); await admin.click('#btnSave');
  await game.waitForFunction(() => window.__game.settings.get('maxPlayers') === 20, null, { timeout: 5000 });
  ok(true, 'configurações aplicadas no jogo');
  await admin.click('[data-cmd=start]');
  await game.waitForFunction(() => window.__game.phase === 'playing', null, { timeout: 5000 });
  ok(true, 'botão "Iniciar partida" funciona');
  await game.waitForTimeout(6000);
  await game.screenshot({ path: path.join(out, '2-partida.png') });
  for (const ev of ['meteors', 'zombies', 'storm', 'boss', 'supply']) { await admin.click(`[data-event=${ev}]`); }
  await game.waitForFunction(() => window.__game.events.active.length >= 4, null, { timeout: 5000 });
  ok(true, 'botões de evento funcionam');
  await game.waitForTimeout(3500);
  await game.screenshot({ path: path.join(out, '3-eventos.png') });
  await admin.selectOption('#giftName', { index: 0 }); await admin.fill('#giftUser', 'manual1'); await admin.click('#btnGift');
  await admin.click('#btnSummon');
  await admin.click('#btnPause');
  await game.waitForFunction(() => window.__game.paused === true, null, { timeout: 5000 });
  ok(true, 'pausa funciona');
  await admin.click('#btnPause');
  await game.waitForFunction(() => window.__game.paused === false, null, { timeout: 5000 });

  // via API HTTP (integração externa)
  const r = await fetch(base + '/api/event', { method: 'POST', body: JSON.stringify({ type: 'chat', user: 'via_api', text: '!join' }) });
  ok(r.ok, 'POST /api/event aceito');
  await game.waitForFunction(() => window.__game.findFighter('via_api') || window.__game.queue.some((q) => q.id === 'via_api'), null, { timeout: 5000 });
  ok(true, 'evento externo chegou ao jogo via WebSocket');

  // acelera até o fim da partida para ver vencedor
  await admin.selectOption('#s_timeScale', '4'); await admin.click('#btnSave');
  await game.waitForFunction(() => window.__game.phase === 'ending', null, { timeout: 120000 });
  await game.waitForTimeout(2500);
  await game.screenshot({ path: path.join(out, '4-vencedor.png') });
  ok(await game.isVisible('#winnerOverlay'), 'animação do vencedor exibida');
  await game.keyboard.press('h');
  await game.waitForTimeout(400);
  ok(await game.evaluate(() => document.body.classList.contains('hide-ui')), 'tecla H oculta a interface');
  await game.screenshot({ path: path.join(out, '5-sem-ui.png') });
  await admin.screenshot({ path: path.join(out, '6-admin.png'), fullPage: true });

  // reconexão do WebSocket
  await stop();
  await game.waitForTimeout(500);
  const st1 = await game.evaluate(() => document.querySelector('#conn em').textContent);
  ok(/reconect|conectando/.test(st1), 'jogo detectou queda do servidor e tenta reconectar: ' + st1);

  const real = errors.filter((e) => !/WebSocket|ERR_CONNECTION|Failed to load resource/i.test(e));
  ok(real.length === 0, 'sem erros JS no console' + (real.length ? ': ' + real.slice(0, 3).join(' | ') : ''));
  await browser.close();
  console.log(fails ? `\n${fails} FALHA(S) no e2e` : '\nE2E passou');
  process.exit(fails ? 1 : 0);
})().catch((e) => { console.error(e); process.exit(1); });
