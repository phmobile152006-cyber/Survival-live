// E2E do ranking de espectadores (jogo + painel + servidor) com screenshots.
// Uso: node scripts/e2e-ranking.cjs [pasta-de-screenshots]   (requer Playwright)
const { chromium } = require('playwright');
const path = require('path');
const os = require('os');
const fs = require('fs');

(async () => {
  const out = process.argv[2] || path.join(__dirname, '..', 'e2e-out');
  fs.mkdirSync(out, { recursive: true });
  const rankFile = path.join(fs.mkdtempSync(path.join(os.tmpdir(), 'sl-e2e-')), 'ranking.json');
  process.env.RANKING_FILE = rankFile; // nunca mexe no ranking real
  let { start, stop } = await import('../server/server.js');
  const port = await start(3600, 20);
  const base = `http://127.0.0.1:${port}`;
  let fails = 0;
  const ok = (c, m) => { if (!c) { fails++; console.log('  ✗ FALHOU:', m); } else console.log('  ✓', m); };
  const browser = await chromium.launch();
  const ctx = await browser.newContext({ viewport: { width: 1920, height: 1080 }, acceptDownloads: true });
  const errors = [];
  const watch = (p, n) => { p.on('pageerror', (e) => errors.push(`${n}: ${e.message}`)); p.on('console', (m) => { if (m.type() === 'error') errors.push(`${n}: ${m.text()}`); }); };

  const game = await ctx.newPage(); watch(game, 'jogo');
  await game.goto(base + '/');
  await game.waitForFunction(() => window.__game && window.__ranking && window.__ranking.serverOk, null, { timeout: 15000 });
  ok(true, 'jogo abriu e o ranking sincronizou com o servidor');
  ok(await game.isVisible('#vtList') && await game.isVisible('#btnRank', { timeout: 1000 }).catch(() => true), 'mini-ranking aparece no HUD e há botão de ranking');

  // popula perfis de todos os níveis (como se viessem de partidas anteriores)
  await game.evaluate(async () => {
    const V = await import('/src/viewers.js'); const rk = window.__ranking; const cfg = rk.store.config;
    const people = [['Lendario_Max', 13000, 40, 9, 30, 12], ['DiamanteDi', 5600, 31, 6, 25, 8], ['PlatinaPedro', 2300, 20, 4, 18, 3], ['OuroBia', 900, 14, 2, 12, 5], ['Prata_Zeca', 400, 9, 1, 9, 0], ['BronzeLu', 120, 4, 0, 6, 1], ['Tigre', 80, 3, 0, 4, 2], ['luna123', 60, 2, 0, 3, 0], ['kaka', 35, 1, 0, 2, 0], ['Nando', 10, 0, 0, 1, 0]];
    people.forEach(([n, pts, k, w, m, g], i) => {
      rk.submit(V.ops.adjust('seed-a-' + i, n, pts, 'seed'));
      for (let j = 0; j < k; j++) rk.submit(V.ops.kill(`seed-k-${i}-${j}`, n, 'seedr' + i, cfg, i % 2 === 0));
      for (let j = 0; j < m; j++) rk.submit(V.ops.match(`seed-m-${i}-${j}`, n, { rid: 'seedm' + i + '.' + j, round: j + 1, won: j < w, place: j < w ? 1 : 3 + (j % 5), kills: j % 4 }, cfg, i % 2 === 0));
      for (let j = 0; j < g; j++) rk.submit(V.ops.gift(`seed-g-${i}-${j}`, n, { gift: j % 3 ? 'Rose' : 'Galaxy', coins: j % 3 ? 1 : 1000, count: 1 }, cfg, i % 2 === 0));
    });
  });
  const n0 = await game.evaluate(() => window.__ranking.store.size);
  ok(n0 >= 10, 'perfis criados: ' + n0);

  // tela do ranking
  await game.keyboard.press('r');
  await game.waitForSelector('#rankOverlay:not(.hidden) .rk-row', { timeout: 5000 });
  ok(true, 'tecla R abre o ranking global');
  const cls = await game.$$eval('#rkPanel .rk-row', (rs) => rs.slice(0, 3).map((r) => r.className));
  ok(/top1/.test(cls[0]) && /top2/.test(cls[1]) && /top3/.test(cls[2]), 'TOP 3 recebem destaque ouro/prata/bronze');
  const first = await game.$eval('#rkPanel .rk-row .c-name b', (e) => e.textContent);
  ok(first === 'Lendario_Max', '1º lugar é quem tem mais pontos: ' + first);
  await game.waitForTimeout(1200);
  await game.screenshot({ path: path.join(out, 'rank-1-geral.png') });
  const tabs = ['kills', 'wins', 'active', 'gifts'];
  for (const t of tabs) {
    await game.click(`#rkPanel [data-tab=${t}]`);
    const sel = await game.$eval('#rkPanel [data-role=sort]', (s) => s.value);
    ok(sel === { kills: 'kills', wins: 'wins', active: 'matches', gifts: 'gifts' }[t], `aba "${t}" ordena por ${sel}`);
  }
  await game.click('#rkPanel [data-tab=kills]');
  ok(await game.$eval('#rkPanel .rk-row .c-name b', (e) => e.textContent) === 'Lendario_Max', 'aba Mais eliminações lista o líder');
  await game.screenshot({ path: path.join(out, 'rank-2-eliminacoes.png') });
  await game.click('#rkPanel [data-period=week]');
  ok((await game.$$('#rkPanel .rk-row')).length > 0, 'ranking semanal tem pontuação do período');
  await game.click('#rkPanel [data-period=all]'); await game.click('#rkPanel [data-tab=overall]');
  await game.selectOption('#rkPanel [data-role=sort]', 'wins');
  ok(await game.$eval('#rkPanel .rk-row .c-name b', (e) => e.textContent) === 'Lendario_Max', 'ordenar por vitórias');
  await game.selectOption('#rkPanel [data-role=sort]', 'points');
  await game.fill('#rkPanel [data-role=search]', 'ouro');
  await game.waitForFunction(() => document.querySelectorAll('#rkPanel .rk-row').length === 1, null, { timeout: 3000 });
  ok(true, 'busca por usuário filtra a lista');
  await game.fill('#rkPanel [data-role=search]', '');
  await game.waitForFunction(() => document.querySelectorAll('#rkPanel .rk-row').length >= 10, null, { timeout: 3000 });
  await game.click('#rkPanel .rk-row.top1');
  await game.waitForSelector('#rkProfile:not(.hidden) .rk-pf', { timeout: 3000 });
  const txt = await game.$eval('#rkProfileBody', (e) => e.innerText);
  ok(/Lendario_Max/i.test(txt) && /Lendário/i.test(txt) && /Taxa de vitória/i.test(txt) && /Histórico recente/i.test(txt) && /Eliminações/i.test(txt) && /Presentes/i.test(txt) && /geral/i.test(txt), 'perfil mostra usuário, nível, posição, estatísticas, taxa de vitória e histórico');
  await game.waitForTimeout(700);
  await game.screenshot({ path: path.join(out, 'rank-3-perfil.png') });
  await game.keyboard.press('Escape'); await game.keyboard.press('Escape');
  ok(await game.isHidden('#rankOverlay'), 'Esc fecha perfil e ranking');

  // painel do streamer
  const admin = await ctx.newPage(); watch(admin, 'admin'); admin.on('dialog', (d) => d.accept());
  await admin.goto(base + '/admin.html');
  await admin.waitForFunction(() => document.querySelectorAll('#rkAdminPanel .rk-row').length >= 10, null, { timeout: 15000 });
  ok(true, 'painel mostra todas as estatísticas dos espectadores (vindas do servidor)');
  ok((await admin.$eval('#rkMode', (e) => e.textContent)).includes('servidor'), 'painel indica armazenamento no servidor');
  const nando0 = await game.evaluate(() => window.__ranking.store.profile('nando').total.points);
  await admin.fill('#adjUser', 'Nando'); await admin.fill('#adjDelta', '300'); await admin.fill('#adjReason', 'sorteio');
  await admin.click('#btnAdjAdd');
  await game.waitForFunction((b) => window.__ranking.store.profile('nando').total.points === b + 300, nando0, { timeout: 5000 });
  ok(true, 'adicionar pontos no painel chega ao jogo (Nando +300)');
  await admin.click('#btnAdjSub');
  await game.waitForFunction((b) => window.__ranking.store.profile('nando').total.points === b, nando0, { timeout: 5000 });
  ok(true, 'remover pontos no painel');
  const plat0 = await game.evaluate(() => window.__ranking.store.profile('platinapedro').total.points);
  await admin.fill('#adjUser', 'Pessoa Nova'); await admin.fill('#adjDelta', '75'); await admin.click('#btnAdjAdd');
  await admin.waitForFunction(() => [...document.querySelectorAll('#rkAdminPanel .rk-row .c-name b')].some((b) => b.textContent === 'Pessoa Nova'), null, { timeout: 5000 });
  ok(true, 'ajustar pontos de um usuário novo cria o perfil');
  await admin.fill('#rkAdminPanel [data-role=search]', 'platina');
  await admin.waitForFunction(() => document.querySelectorAll('#rkAdminPanel .rk-row').length === 1, null, { timeout: 3000 });
  await admin.click('#rkAdminPanel .rk-row');
  await admin.waitForSelector('#rkProfile:not(.hidden) .rk-adj', { timeout: 3000 });
  await admin.fill('#rkProfileBody .rk-delta', '40'); await admin.click('#rkProfileBody [data-adj="1"]');
  await game.waitForFunction((b) => window.__ranking.store.profile('platinapedro').total.points === b + 40, plat0, { timeout: 5000 });
  ok(true, 'ajuste de pontos pelo perfil (admin)');
  await admin.click('#rkProfileClose'); await admin.fill('#rkAdminPanel [data-role=search]', '');
  // configuração de pontuação
  await admin.fill('#sc_elimination', '30'); await admin.fill('#sc_victory', '150'); await admin.fill('#lv_1', '300'); await admin.click('#btnScSave');
  await game.waitForFunction(() => window.__ranking.store.config.elimination === 30 && window.__ranking.store.config.victory === 150 && window.__ranking.store.config.levelMins[1] === 300, null, { timeout: 5000 });
  ok(true, 'configuração de pontos e níveis salva e aplicada no jogo');
  // exportação
  const [dl] = await Promise.all([admin.waitForEvent('download'), admin.click('#btnExportCsv')]);
  const csv = fs.readFileSync(await dl.path(), 'utf8');
  ok(/posicao,usuario/.test(csv) && /Lendario_Max/.test(csv), 'exportar CSV: ' + dl.suggestedFilename());
  const [dl2] = await Promise.all([admin.waitForEvent('download'), admin.click('#btnExportJson')]);
  ok(JSON.parse(fs.readFileSync(await dl2.path(), 'utf8')).profiles.length >= 10, 'exportar JSON');
  await admin.evaluate(() => document.getElementById('rankCard').scrollIntoView());
  await admin.waitForTimeout(500);
  await admin.screenshot({ path: path.join(out, 'rank-4-admin.png') });
  await admin.locator('#rankCard').screenshot({ path: path.join(out, 'rank-4b-admin-card.png') });

  // partida completa pela interface: viewers simulados jogam e pontuam
  for (let i = 1; i <= 6; i++) { await admin.fill('#simUser', 'sim_viewer' + i); await admin.fill('#simText', '!entrar'); await admin.click('#btnChat'); }
  await game.waitForFunction(() => window.__game.fighters.filter((f) => f.id.startsWith('sim_viewer')).length === 6, null, { timeout: 8000 });
  await admin.selectOption('#s_timeScale', '4'); await admin.click('#btnSave');
  await admin.click('[data-cmd=start]');
  await game.waitForFunction(() => window.__game.phase === 'ending', null, { timeout: 150000 });
  await game.waitForTimeout(500);
  const res = await game.evaluate(() => {
    const rk = window.__ranking, g = window.__game, out = [];
    for (const f of g.fighters) if (f.id.startsWith('sim_viewer')) { const p = rk.store.profile(f.id); out.push({ id: f.id, kills: f.kills, pk: p && p.total.kills, m: p && p.total.matches, pts: p && p.total.points, won: f === g.winner }); }
    return out;
  });
  ok(res.every((r) => r.m === 1 && r.pk === r.kills), 'após a partida: todos os participantes têm +1 partida e as eliminações batem com o jogo');
  ok(res.every((r) => r.pts === r.kills * 30 + 10 + (r.won ? 150 : 0)), 'pontos da partida seguem a configuração do painel (30/elim, 10 part., 150 vitória)');
  await admin.waitForFunction(() => [...document.querySelectorAll('#rkAdminPanel .rk-row .c-name b')].some((b) => b.textContent === 'sim_viewer1'), null, { timeout: 5000 });
  ok(true, 'painel recebeu os novos perfis em tempo real');
  await game.keyboard.press('r'); await game.waitForTimeout(800);
  await game.screenshot({ path: path.join(out, 'rank-5-apos-partida.png') });
  await game.keyboard.press('Escape');

  // zerar semanal / mensal e apagar simulados
  const geral = await game.evaluate(() => window.__ranking.store.profile('lendario_max').total.points);
  await admin.click('#btnResetWeek');
  await game.waitForFunction(() => window.__ranking.store.board({ period: 'week' }).length === 0, null, { timeout: 5000 });
  ok(await game.evaluate(() => window.__ranking.store.profile('lendario_max').total.points) === geral, 'zerar ranking semanal não altera o geral');
  await admin.click('#btnResetMonth');
  await game.waitForFunction(() => window.__ranking.store.board({ period: 'month' }).length === 0, null, { timeout: 5000 });
  ok(true, 'zerar ranking mensal');

  // persistência: recarregar, reiniciar o servidor, e uma "janela do OBS" nova (navegador sem dados locais)
  await game.reload();
  await game.waitForFunction(() => window.__ranking && window.__ranking.store.profile('lendario_max'), null, { timeout: 10000 });
  ok(true, 'ranking continua após recarregar o jogo');
  await stop();
  ({ start, stop } = await import('../server/server.js'));
  const port2 = await start(port, 20);
  const snap = await (await fetch(`http://127.0.0.1:${port2}/api/ranking`)).json();
  ok(snap.state.profiles.lendario_max && snap.state.profiles.lendario_max.total.points === geral, 'ranking continua após reiniciar o servidor (arquivo)');
  ok(fs.existsSync(rankFile), 'dados em ' + path.basename(rankFile));
  const ctx2 = await browser.newContext({ viewport: { width: 1920, height: 1080 } });
  const obs = await ctx2.newPage(); watch(obs, 'obs');
  await obs.goto(`http://127.0.0.1:${port2}/`);
  await obs.waitForFunction(() => window.__ranking && window.__ranking.serverOk && window.__ranking.store.size > 10, null, { timeout: 15000 });
  ok(true, 'outra janela (sem dados locais, ex.: OBS) carrega o ranking do servidor');
  await ctx2.close();

  // celular
  const mob = await browser.newContext({ viewport: { width: 390, height: 844 }, deviceScaleFactor: 2, isMobile: true, hasTouch: true });
  const mp = await mob.newPage(); watch(mp, 'mobile');
  await mp.goto(`http://127.0.0.1:${port2}/`);
  await mp.waitForFunction(() => window.__ranking && window.__ranking.store.size > 10, null, { timeout: 15000 });
  await mp.evaluate(() => document.getElementById('btnRank').click());
  await mp.waitForSelector('#rankOverlay:not(.hidden) .rk-row');
  await mp.waitForTimeout(900);
  await mp.screenshot({ path: path.join(out, 'rank-6-mobile.png') });
  const overflow = await mp.evaluate(() => { const m = document.querySelector('#rankOverlay .rk-modal'); return m.scrollWidth - m.clientWidth; });
  ok(overflow <= 1, 'celular: ranking sem rolagem horizontal (' + overflow + 'px)');
  await mp.click('#rkPanel .rk-row.top1');
  await mp.waitForSelector('#rkProfile:not(.hidden) .rk-pf'); await mp.waitForTimeout(600);
  await mp.screenshot({ path: path.join(out, 'rank-7-mobile-perfil.png') });
  const ap = await mob.newPage(); watch(ap, 'admin-mobile');
  await ap.goto(`http://127.0.0.1:${port2}/admin.html`);
  await ap.waitForFunction(() => document.querySelectorAll('#rkAdminPanel .rk-row').length > 5, null, { timeout: 15000 });
  const ov2 = await ap.evaluate(() => document.documentElement.scrollWidth - window.innerWidth);
  ok(ov2 <= 1, 'celular: painel do streamer sem rolagem horizontal (' + ov2 + 'px)');
  await mob.close();

  // apagar simulados (no painel)
  await admin.reload();
  await admin.waitForFunction(() => document.querySelectorAll('#rkAdminPanel .rk-row').length >= 10, null, { timeout: 15000 });
  await admin.click('#btnPurgeSim');
  await admin.waitForFunction(() => ![...document.querySelectorAll('#rkAdminPanel .rk-row .c-name b')].some((b) => b.textContent === 'sim_viewer1'), null, { timeout: 5000 });
  ok(true, 'apagar perfis simulados mantém os reais');

  const real = errors.filter((e) => !/WebSocket|ERR_CONNECTION|Failed to load resource|ERR_ABORTED/i.test(e));
  ok(real.length === 0, 'sem erros JS no console' + (real.length ? ': ' + real.slice(0, 4).join(' | ') : ''));
  await stop(); await browser.close();
  console.log(fails ? `\n${fails} FALHA(S)` : '\nE2E do ranking passou');
  process.exit(fails ? 1 : 0);
})().catch((e) => { console.error(e); process.exit(1); });
