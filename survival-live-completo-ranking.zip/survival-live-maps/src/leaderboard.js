// Ranking em tempo real e histórico de campeões (sem DOM obrigatório)
const KEY = 'survivalLive.history.v1';

export function computeRanking(game) {
  const alive = game.fighters.filter((f) => f.alive)
    .sort((a, b) => b.kills - a.kills || b.hp + b.shield - (a.hp + a.shield));
  const dead = game.fighters.filter((f) => !f.alive)
    .sort((a, b) => (a.placement || 99) - (b.placement || 99));
  return { alive, dead, all: [...alive, ...dead] };
}

export class History {
  constructor() {
    this.winners = [];
    this.wins = {};
    try {
      const raw = globalThis.sessionStorage && globalThis.sessionStorage.getItem(KEY);
      if (raw) { const d = JSON.parse(raw); this.winners = d.winners || []; this.wins = d.wins || {}; }
    } catch { /* ignora */ }
  }
  save() {
    try { globalThis.sessionStorage && globalThis.sessionStorage.setItem(KEY, JSON.stringify({ winners: this.winners, wins: this.wins })); } catch { /* ignora */ }
  }
  add(entry) {
    this.winners.unshift(entry);
    this.winners.length = Math.min(this.winners.length, 20);
    const k = entry.name.toLowerCase();
    this.wins[k] = (this.wins[k] || 0) + 1;
    this.save();
  }
  winsOf(name) { return this.wins[name.toLowerCase()] || 0; }
  clear() { this.winners = []; this.wins = {}; this.save(); }
}
