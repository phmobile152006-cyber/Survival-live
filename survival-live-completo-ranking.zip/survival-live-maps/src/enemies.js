// Monstros controlados por IA: zumbi, lobo e monstro gigante (sem DOM)
import { rand, angleTo, TAU } from './utils.js';
import { moveEntity } from './player.js';
import { DIFFICULTY } from './settings.js';

export const MONSTER_TYPES = {
  zombie: { label: 'Zumbi', hp: 70, speed: 52, dmg: 9, cd: 1.0, r: 14, aggro: 300, reach: 20 },
  wolf: { label: 'Lobo', hp: 45, speed: 150, dmg: 7, cd: 0.55, r: 12, aggro: 440, reach: 18 },
  giant: { label: 'Monstro Gigante', hp: 900, speed: 70, dmg: 34, cd: 2.6, r: 40, aggro: 720, reach: 50 },
};

let mid = 1;

export class Monster {
  constructor(game, type, x, y, { hunt = false } = {}) {
    const T = MONSTER_TYPES[type];
    const D = DIFFICULTY[game.settings.get('difficulty')] || DIFFICULTY.normal;
    this.game = game; this.isMonster = true; this.id = 'm' + mid++;
    this.type = type; this.name = T.label; this.T = T;
    this.x = x; this.y = y; this.vx = this.vy = 0; this.r = T.r;
    let hp = T.hp * D.monsterHp;
    if (type === 'giant') hp += game.aliveCount() * 18;
    this.maxHp = this.hp = hp;
    this.dmg = T.dmg * D.monsterDmg;
    this.alive = true; this.hunt = hunt; this.attackCd = rand(0.3, T.cd);
    this.facing = rand(TAU); this.animT = rand(10); this.hitFlash = 0; this.invuln = 0;
    this.shield = 0; this.ignoreSwamp = true; this.lastX = x; this.lastY = y;
    this.wp = null; this.wpT = 0; this.windup = 0; this.attackAnim = 0; this.deadT = 0;
    this.spawnT = 0.6; this.home = { x, y }; this.thinkT = rand(0.3);
    this.weave = rand(TAU); this.stuckT = 0; this.lastCheck = 0; this.detourT = 0;
    this.hasTarget = false;
  }
  findTarget() {
    const g = this.game;
    let best = null, bd = Infinity;
    for (const f of g.fighters) {
      if (!f.alive || f.dropT > 0 || f.invuln > 0) continue;
      let reach = this.hunt ? 1e9 : this.T.aggro;
      if (f.hidden && !this.hunt) reach *= 0.3;
      const d = Math.hypot(f.x - this.x, f.y - this.y);
      if (d < reach && d < bd) { bd = d; best = f; }
    }
    return best;
  }
  update(dt) {
    const g = this.game, T = this.T;
    if (!this.alive) { this.deadT += dt; return; }
    if (this.hitFlash > 0) this.hitFlash -= dt;
    if (this.attackCd > 0) this.attackCd -= dt;
    if (this.attackAnim > 0) this.attackAnim -= dt;
    if (this.spawnT > 0) this.spawnT -= dt;
    this.thinkT -= dt;
    if (this.thinkT <= 0) { this.thinkT = 0.2 + Math.random() * 0.1; this.target = this.findTarget(); }
    const t = this.target && this.target.alive ? this.target : null;
    let dx = 0, dy = 0, sp = T.speed;
    if (this.windup > 0) {
      this.windup -= dt; // gigante preparando o pisão
      if (this.windup <= 0) this.slam();
    } else if (t) {
      const d = Math.hypot(t.x - this.x, t.y - this.y), edge = d - t.r - this.r;
      const ux = (t.x - this.x) / (d || 1), uy = (t.y - this.y) / (d || 1);
      this.facing = Math.atan2(uy, ux);
      if (this.type === 'giant') {
        if (edge < 60 && this.attackCd <= 0) { this.startSlam(); }
        else if (edge >= 40) { dx = ux; dy = uy; }
      } else {
        if (edge <= T.reach) {
          if (this.attackCd <= 0) {
            this.attackCd = T.cd * rand(0.9, 1.1); this.attackAnim = 0.2;
            g.combat.damage(t, this.dmg, this, { cause: 'monster', weapon: T.label });
            g.audio?.(this.type === 'wolf' ? 'bite' : 'zombie', this);
          }
        } else {
          dx = ux; dy = uy;
          if (this.type === 'wolf' && d > 90) { this.weave += 0.12; const w = Math.sin(this.weave) * 0.45; const c = Math.cos(w), s = Math.sin(w); const nx = dx * c - dy * s; dy = dx * s + dy * c; dx = nx; }
        }
      }
    } else {
      // vagueia
      this.wpT -= dt;
      if (!this.wp || this.wpT <= 0 || Math.hypot(this.wp.x - this.x, this.wp.y - this.y) < 30) {
        const a = rand(TAU), d = rand(40, 220);
        this.wp = { x: this.home.x + Math.cos(a) * d, y: this.home.y + Math.sin(a) * d }; this.wpT = rand(3, 7);
      }
      dx = this.wp.x - this.x; dy = this.wp.y - this.y;
      const l = Math.hypot(dx, dy) || 1; dx /= l; dy /= l; sp *= 0.4;
      if (Math.hypot(this.vx, this.vy) > 8) this.facing = Math.atan2(this.vy, this.vx);
    }
    // destrava
    this.lastCheck += dt;
    if (this.lastCheck > 0.6) {
      if ((dx || dy) && Math.hypot(this.x - this.lastX, this.y - this.lastY) < 6) { this.detourT = 0.8; this.detourAng = rand(TAU); }
      this.lastX = this.x; this.lastY = this.y; this.lastCheck = 0;
    }
    if (this.detourT > 0) { this.detourT -= dt; dx = Math.cos(this.detourAng); dy = Math.sin(this.detourAng); }
    if (this.windup > 0) { dx = dy = 0; }
    moveEntity(this, g, dx, dy, sp, dt);
    this.animT += Math.hypot(this.vx, this.vy) * dt * 0.07;
  }
  startSlam() {
    const g = this.game;
    this.windup = 0.85; this.attackCd = this.T.cd; this.attackAnim = 0.85;
    g.dangers.push({ x: this.x, y: this.y, r: 115, t: 0.85, T: 0.85, kind: 'slam', follow: this });
    g.audio?.('roar', this);
  }
  slam() {
    const g = this.game;
    g.fx.explosion(this.x, this.y, 100);
    g.fx.shake = Math.max(g.fx.shake, 10);
    g.audio?.('slam', this);
    for (const f of g.fighters) {
      if (!f.alive) continue;
      const d = Math.hypot(f.x - this.x, f.y - this.y) - f.r;
      if (d < 115) g.combat.damage(f, this.dmg * (1 - Math.max(0, d) / 230), this, { cause: 'monster', weapon: this.T.label });
    }
  }
}

export function spawnMonster(game, type, x, y, opts) {
  const m = new Monster(game, type, x, y, opts);
  game.monsters.push(m);
  game.fx.burst(x, y, 10, { speed: 90, life: 0.6, size: 4, color: 'rgba(60,40,70,0.8)', kind: 'smoke', grow: 10 });
  return m;
}

/** ponto livre longe de jogadores */
export function freeSpotAwayFromPlayers(game, region, minDist = 380) {
  for (let i = 0; i < 30; i++) {
    const p = game.map.randomFree(Math.random, region, 40);
    if (game.fighters.every((f) => !f.alive || Math.hypot(f.x - p.x, f.y - p.y) > minDist)) return p;
  }
  return game.map.randomFree(Math.random, region, 40);
}

export function spawnInitialMonsters(game) {
  if (!game.settings.get('monsters')) return;
  const D = DIFFICULTY[game.settings.get('difficulty')] || DIFFICULTY.normal;
  const scale = Math.max(0.5, game.settings.get('maxPlayers') / 30) * D.monsterCount;
  const region = { x: game.zone.cx, y: game.zone.cy, r: game.zone.r * 0.95 };
  const nz = Math.round(12 * scale), nw = Math.round(3 * scale);
  for (let i = 0; i < nz; i++) { const p = freeSpotAwayFromPlayers(game, region); spawnMonster(game, 'zombie', p.x, p.y); }
  for (let i = 0; i < nw; i++) {
    const p = freeSpotAwayFromPlayers(game, region);
    for (let k = 0; k < 3; k++) spawnMonster(game, 'wolf', p.x + rand(-40, 40), p.y + rand(-40, 40));
  }
}
