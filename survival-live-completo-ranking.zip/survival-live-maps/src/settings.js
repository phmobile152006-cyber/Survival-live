// Configurações persistidas em localStorage (com fallback em memória para testes/Node)
import { MAP_CHOICES } from './maps.js';

const KEY = 'survivalLive.settings.v1';

export const DEFAULT_GIFTS = {
  rose: { label: 'Rosa', action: 'heal', value: 25 },
  heart: { label: 'Coração', action: 'shield', value: 40 },
  fingerheart: { label: 'Mini Coração', action: 'energy', value: 60 },
  tiktok: { label: 'TikTok', action: 'rage', value: 12 },
  doughnut: { label: 'Rosquinha', action: 'heal', value: 60 },
  gg: { label: 'GG', action: 'energy', value: 100 },
  handhearts: { label: 'Mãos de Coração', action: 'shield', value: 80 },
  dramaqueen: { label: 'Drama Queen', action: 'supply', value: 1 },
  galaxy: { label: 'Galáxia', action: 'meteors', value: 8 },
  lion: { label: 'Leão', action: 'weapon', value: 'special' },
  universe: { label: 'Universo', action: 'nova', value: 60 },
};

export const GIFT_ACTIONS = ['heal', 'shield', 'energy', 'rage', 'weapon', 'meteors', 'supply', 'nova', 'zombies', 'boss'];

export const DEFAULTS = {
  maxPlayers: 30,
  minPlayers: 2,
  lobbyTime: 30,
  matchDuration: 300,
  difficulty: 'normal',
  effects: true,
  sound: true,
  monsters: true,
  autoEvents: true,
  autoRestart: true,
  lateJoin: false,
  keepPlayers: true,
  mapId: 'forest', // 'forest' | 'desert' | 'snow' | 'random' (vale a partir da próxima rodada)
  fillBotsTo: 10, // modo demonstração: completa a sala com bots (0 = desligado)
  timeScale: 1,
  gifts: DEFAULT_GIFTS,
};

const LIMITS = {
  maxPlayers: [2, 60], minPlayers: [2, 60], lobbyTime: [3, 120], matchDuration: [60, 1800],
  fillBotsTo: [0, 60], timeScale: [0.5, 4],
};

function sanitize(data) {
  for (const k in LIMITS) {
    const [a, b] = LIMITS[k];
    const v = Number(data[k]);
    data[k] = Number.isFinite(v) ? Math.min(b, Math.max(a, v)) : DEFAULTS[k];
  }
  if (!['easy', 'normal', 'hard', 'insane'].includes(data.difficulty)) data.difficulty = 'normal';
  if (!MAP_CHOICES.includes(data.mapId)) data.mapId = 'forest';
  if (data.minPlayers > data.maxPlayers) data.minPlayers = data.maxPlayers;
  if (!data.gifts || typeof data.gifts !== 'object') data.gifts = structuredClone(DEFAULT_GIFTS);
  return data;
}

class Settings {
  constructor(persistent = true) {
    this.persistent = persistent;
    this.data = structuredClone(DEFAULTS);
    this.listeners = new Set();
    if (persistent) this.load();
  }
  load() {
    try {
      const raw = globalThis.localStorage && globalThis.localStorage.getItem(KEY);
      if (raw) Object.assign(this.data, JSON.parse(raw));
    } catch { /* ignora */ }
    this.data.timeScale = 1; // velocidade de teste nunca persiste entre sessões
    sanitize(this.data);
  }
  save() {
    if (!this.persistent) return;
    try {
      const { timeScale, ...rest } = this.data;
      globalThis.localStorage && globalThis.localStorage.setItem(KEY, JSON.stringify(rest));
    } catch { /* ignora */ }
  }
  get(k) { return this.data[k]; }
  patch(p, persist = true) {
    if (!p || typeof p !== 'object') return;
    for (const k in p) if (k in DEFAULTS) this.data[k] = p[k];
    sanitize(this.data);
    if (persist) this.save();
    this.listeners.forEach((fn) => fn(this.data));
  }
  reset() { this.data = structuredClone(DEFAULTS); this.save(); this.listeners.forEach((fn) => fn(this.data)); }
  onChange(fn) { this.listeners.add(fn); return () => this.listeners.delete(fn); }
}

export const settings = new Settings(true);
export function createSettings() { return new Settings(false); }

export const DIFFICULTY = {
  easy: { monsterHp: 0.7, monsterDmg: 0.7, monsterCount: 0.6, zoneDps: 0.8, eventRate: 0.7 },
  normal: { monsterHp: 1, monsterDmg: 1, monsterCount: 1, zoneDps: 1, eventRate: 1 },
  hard: { monsterHp: 1.3, monsterDmg: 1.25, monsterCount: 1.5, zoneDps: 1.2, eventRate: 1.3 },
  insane: { monsterHp: 1.8, monsterDmg: 1.6, monsterCount: 2.2, zoneDps: 1.5, eventRate: 1.8 },
};
