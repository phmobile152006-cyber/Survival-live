// Eventos aleatórios da partida (sem DOM)
import { rand, pick, TAU } from './utils.js';
import { spawnMonster } from './enemies.js';
import { DIFFICULTY } from './settings.js';

export const EVENT_DEFS = {
  meteors: { name: 'CHUVA DE METEOROS', icon: '☄️', msg: 'Meteoros caindo! Fujam das áreas vermelhas!', dur: 14, color: '#ff7a2e' },
  zombies: { name: 'INVASÃO DE ZUMBIS', icon: '🧟', msg: 'Uma horda de zumbis invadiu a arena!', dur: 6, color: '#7bd14a' },
  storm: { name: 'TEMPESTADE', icon: '⛈️', msg: 'Tempestade! A zona fecha mais rápido e raios caem!', dur: 30, color: '#6aa8ff' },
  boss: { name: 'CHEFE FINAL', icon: '👹', msg: 'O Monstro Gigante despertou! Sobrevivam!', dur: 4, color: '#ff4d6d' },
  supply: { name: 'CAIXA DE SUPRIMENTOS', icon: '🎁', msg: 'Uma caixa de suprimentos caiu! Procurem o feixe de luz!', dur: 4, color: '#ffd166' },
};

export class EventManager {
  constructor(game) { this.game = game; this.active = []; this.nextAuto = 45; this.last = null; this.bossDone = false; this.stormT = 0; }
  reset() { this.active.length = 0; this.nextAuto = 40 + rand(0, 10); this.last = null; this.bossDone = false; this.stormT = 0; }
  get stormMult() { return this.stormT > 0 ? 2.5 : 1; }

  trigger(key, opts = {}) {
    const g = this.game, def = EVENT_DEFS[key];
    if (!def) return false;
    if (g.phase !== 'playing') return false;
    const D = DIFFICULTY[g.settings.get('difficulty')] || DIFFICULTY.normal;
    const ev = { key, t: 0, dur: def.dur, opts, acc: 0 };
    this.active.push(ev);
    this.last = key;
    g.emit('event', { key, name: def.name, icon: def.icon, msg: opts.by ? `${opts.by}: ${def.msg}` : def.msg, color: def.color });
    g.audio?.('event', null);
    const zr = { x: g.zone.cx, y: g.zone.cy, r: Math.max(120, g.zone.r * 0.9) };
    switch (key) {
      case 'zombies': {
        const n = Math.round((opts.count || 10) * D.monsterCount + g.aliveCount() / 4);
        const side = rand(TAU);
        for (let i = 0; i < n; i++) {
          const a = side + rand(-0.8, 0.8), d = Math.max(80, g.zone.r * 0.95);
          const p = g.map.randomFree(Math.random, { x: g.zone.cx + Math.cos(a) * d * 0.8, y: g.zone.cy + Math.sin(a) * d * 0.8, r: 200 }, 24);
          spawnMonster(g, 'zombie', p.x, p.y, { hunt: true });
        }
        break;
      }
      case 'boss': {
        const a = rand(TAU), d = g.zone.r * 0.8;
        const p = g.map.randomFree(Math.random, { x: g.zone.cx + Math.cos(a) * d * 0.7, y: g.zone.cy + Math.sin(a) * d * 0.7, r: 150 }, 60);
        const m = spawnMonster(g, 'giant', p.x, p.y, { hunt: true });
        g.fx.explosion(p.x, p.y, 120);
        ev.boss = m;
        this.bossDone = true;
        break;
      }
      case 'supply': {
        const c = g.items.spawnCrate(opts.at ? { x: opts.at.x, y: opts.at.y, r: 90 } : zr, true);
        c.beacon = true;
        ev.crate = c;
        break;
      }
      case 'storm':
        this.stormT = def.dur; ev.lightningT = 0.5;
        break;
      case 'meteors':
        ev.count = opts.count || 10; ev.spawned = 0; ev.interval = def.dur / ev.count;
        break;
    }
    return true;
  }

  meteor(ev, x, y, small = false) {
    const g = this.game;
    const r = small ? 42 : 78, T = small ? 0.9 : 1.7, dmg = small ? 32 : 46;
    g.dangers.push({
      x, y, r, t: T, T, kind: small ? 'lightning' : 'meteor',
      onEnd: (gm) => {
        gm.fx.explosion(x, y, r);
        if (small) gm.fx.flash = 0.6;
        gm.audio?.(small ? 'thunder' : 'explosion', { x, y });
        const cause = small ? 'lightning' : 'meteor';
        for (const f of gm.fighters) if (f.alive && !(ev.opts && ev.opts.spare === f)) {
          const d = Math.hypot(f.x - x, f.y - y) - f.r;
          if (d < r) gm.combat.damage(f, dmg * (1 - Math.max(0, d) / r * 0.4), null, { cause });
        }
        for (const m of gm.monsters) if (m.alive) {
          const d = Math.hypot(m.x - x, m.y - y) - m.r;
          if (d < r) gm.combat.damage(m, dmg * 1.2, null, { cause });
        }
      },
    });
  }

  update(dt) {
    const g = this.game;
    if (this.stormT > 0) this.stormT -= dt;
    for (let i = this.active.length - 1; i >= 0; i--) {
      const ev = this.active[i];
      ev.t += dt;
      if (ev.key === 'meteors') {
        ev.acc += dt;
        while (ev.acc >= ev.interval && ev.spawned < ev.count) {
          ev.acc -= ev.interval; ev.spawned++;
          const alive = g.fighters.filter((f) => f.alive && f !== (ev.opts && ev.opts.spare));
          let x, y;
          if (alive.length && Math.random() < 0.65) { const f = pick(alive); x = f.x + rand(-170, 170); y = f.y + rand(-170, 170); }
          else { const p = g.map.randomFree(Math.random, { x: g.zone.cx, y: g.zone.cy, r: Math.max(100, g.zone.r) }, 10); x = p.x; y = p.y; }
          if (ev.opts && ev.opts.spare && Math.hypot(x - ev.opts.spare.x, y - ev.opts.spare.y) < 160) { ev.spawned--; ev.acc += ev.interval * 0.5; continue; }
          this.meteor(ev, x, y);
        }
      } else if (ev.key === 'storm') {
        ev.lightningT -= dt;
        if (ev.lightningT <= 0) {
          ev.lightningT = rand(0.8, 1.6);
          const alive = g.fighters.filter((f) => f.alive);
          if (alive.length) { const f = pick(alive); this.meteor(ev, f.x + rand(-90, 90), f.y + rand(-90, 90), true); }
        }
      }
      if (ev.t >= ev.dur) this.active.splice(i, 1);
    }
    // eventos automáticos
    if (g.settings.get('autoEvents') && g.phase === 'playing') {
      const D = DIFFICULTY[g.settings.get('difficulty')] || DIFFICULTY.normal;
      const total = g.settings.get('matchDuration');
      this.nextAuto -= dt;
      const alive = g.aliveCount();
      if (!this.bossDone && g.settings.get('monsters') && (g.time > total * 0.65 || (alive <= Math.max(3, g.fighters.length * 0.2) && g.time > total * 0.3))) {
        this.trigger('boss');
        this.nextAuto = rand(25, 35);
      } else if (this.nextAuto <= 0) {
        const bigBusy = this.active.some((e) => e.key !== 'supply');
        if (!bigBusy) {
          const pool = ['meteors', 'zombies', 'storm', 'supply', 'supply'].filter((k) => k !== this.last && (g.settings.get('monsters') || k !== 'zombies'));
          this.trigger(pick(pool));
          this.nextAuto = rand(26, 44) / D.eventRate;
        } else this.nextAuto = 4;
      }
    }
  }
}
