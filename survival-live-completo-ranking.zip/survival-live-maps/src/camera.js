// Câmera diretora: acompanha a ação automaticamente (sem DOM)
import { clamp } from './utils.js';
import { MAP_W, MAP_H, PLAZA } from './map.js';

export class Camera {
  constructor() {
    this.x = PLAZA.x; this.y = PLAZA.y; this.zoom = 0.6;
    this.tx = this.x; this.ty = this.y; this.tz = 0.6;
    this.hotId = null; this.hotT = 0; this.evalT = 0;
    this.vw = 1920; this.vh = 1080;
  }
  snap() { this.x = this.tx; this.y = this.ty; this.zoom = this.tz; }
  update(g, dt, vw, vh) {
    this.vw = vw; this.vh = vh;
    this.compute(g, dt);
    const kp = 1 - Math.exp(-dt * 2.6), kz = 1 - Math.exp(-dt * 1.8);
    this.x += (this.tx - this.x) * kp; this.y += (this.ty - this.y) * kp; this.zoom += (this.tz - this.zoom) * kz;
    // limites do mapa
    const hw = vw / 2 / this.zoom, hh = vh / 2 / this.zoom;
    this.x = hw * 2 >= MAP_W ? MAP_W / 2 : clamp(this.x, hw, MAP_W - hw);
    this.y = hh * 2 >= MAP_H ? MAP_H / 2 : clamp(this.y, hh, MAP_H - hh);
  }
  fit(minX, minY, maxX, maxY, pad, zmin, zmax) {
    const w = maxX - minX + pad * 2, h = maxY - minY + pad * 1.2;
    this.tx = (minX + maxX) / 2; this.ty = (minY + maxY) / 2;
    this.tz = clamp(Math.min(this.vw / w, this.vh / h), zmin, zmax);
  }
  compute(g, dt) {
    const vw = this.vw, vh = this.vh;
    if (g.phase === 'lobby' || g.cameraMode === 'overview') {
      if (g.phase === 'lobby') { this.tx = PLAZA.x; this.ty = PLAZA.y; this.tz = Math.min(vw / 1100, vh / 700); }
      else { this.tx = g.zone.cx; this.ty = g.zone.cy; this.tz = Math.min(vw / (g.zone.r * 2 + 300), vh / (g.zone.r * 2 + 300)); }
      return;
    }
    if (g.phase === 'ending' && g.winner) { this.tx = g.winner.x; this.ty = g.winner.y - 20; this.tz = Math.min(1.5, vh / 420); return; }
    if (g.cameraMode === 'follow' && g.followId) {
      const f = g.findFighter(g.followId);
      if (f && f.alive) { this.tx = f.x; this.ty = f.y; this.tz = Math.min(1.35, vh / 520); return; }
    }
    const alive = g.fighters.filter((f) => f.alive);
    if (!alive.length) return;
    // poucos sobreviventes: enquadra todos
    if (alive.length <= 3) {
      let a = 1e9, b = 1e9, c = -1e9, d = -1e9;
      for (const f of alive) { a = Math.min(a, f.x); b = Math.min(b, f.y); c = Math.max(c, f.x); d = Math.max(d, f.y); }
      this.fit(a, b, c, d, 260, 0.35, 1.25);
      return;
    }
    this.hotT += dt; this.evalT -= dt;
    if (this.evalT <= 0) {
      this.evalT = 0.5;
      let best = null, bs = -1;
      const cur = g.findFighter(this.hotId);
      for (const f of alive) {
        let s = 1;
        for (const o of alive) if (o !== f && (o.x - f.x) ** 2 + (o.y - f.y) ** 2 < 300 * 300) s += 1;
        for (const m of g.monsters) if (m.alive && (m.x - f.x) ** 2 + (m.y - f.y) ** 2 < 300 * 300) s += m.type === 'giant' ? 3 : 0.6;
        if (g.time - f.lastHitT < 2) s += 2.5;
        if (f.attackedT < 2) s += 1.5;
        if (f === cur) s += 1.5;
        if (s > bs) { bs = s; best = f; }
      }
      if (best && (!cur || !cur.alive || (best !== cur && this.hotT > 3.5))) { this.hotId = best.id; this.hotT = 0; }
    }
    const hot = g.findFighter(this.hotId) || alive[0];
    let a = hot.x, b = hot.y, c = hot.x, d = hot.y;
    for (const f of alive) if ((f.x - hot.x) ** 2 + (f.y - hot.y) ** 2 < 420 * 420) { a = Math.min(a, f.x); b = Math.min(b, f.y); c = Math.max(c, f.x); d = Math.max(d, f.y); }
    for (const m of g.monsters) if (m.alive && (m.x - hot.x) ** 2 + (m.y - hot.y) ** 2 < 300 * 300) { a = Math.min(a, m.x); b = Math.min(b, m.y); c = Math.max(c, m.x); d = Math.max(d, m.y); }
    this.fit(a, b, c, d, 320, 0.6, 1.4);
  }
}
