// Cliente WebSocket com reconexão automática + canal local (BroadcastChannel) para
// painel e jogo no mesmo navegador. Mensagens são deduplicadas por id.
export class Link {
  constructor({ role = 'game', url, token = '', local = true } = {}) {
    this.role = role;
    this.token = token;
    this.url = url || (typeof location !== 'undefined' ? `${location.protocol === 'https:' ? 'wss' : 'ws'}://${location.host}/ws` : '');
    this.handlers = new Set();
    this.statusHandlers = new Set();
    this.ws = null;
    this.status = 'disconnected';
    this.attempt = 0;
    this.seen = new Set();
    this.closedByUser = false;
    this.timer = null;
    this.bc = null;
    if (local && typeof BroadcastChannel !== 'undefined') {
      this.bc = new BroadcastChannel('survival-live');
      this.bc.onmessage = (e) => this._recv(e.data);
    }
  }
  onMessage(fn) { this.handlers.add(fn); return () => this.handlers.delete(fn); }
  onStatus(fn) { this.statusHandlers.add(fn); fn(this.status, this.attempt); }
  _setStatus(s) { this.status = s; this.statusHandlers.forEach((f) => f(s, this.attempt)); }
  connect() {
    if (typeof WebSocket === 'undefined' || !this.url) return;
    this.closedByUser = false;
    clearTimeout(this.timer);
    this._setStatus('connecting');
    let ws;
    try { ws = new WebSocket(this.url); } catch { return this._retry(); }
    this.ws = ws;
    ws.onopen = () => {
      this.attempt = 0;
      this._setStatus('connected');
      ws.send(JSON.stringify({ type: 'hello', role: this.role, token: this.token }));
    };
    ws.onmessage = (e) => { try { this._recv(JSON.parse(e.data)); } catch { /* ignora */ } };
    ws.onclose = () => { this.ws = null; if (!this.closedByUser) { this._setStatus('reconnecting'); this._retry(); } else this._setStatus('disconnected'); };
    ws.onerror = () => { try { ws.close(); } catch { /* ignora */ } };
  }
  _retry() {
    this.attempt++;
    const delay = Math.min(10000, 1000 * Math.pow(1.6, Math.min(this.attempt, 8)));
    clearTimeout(this.timer);
    this.timer = setTimeout(() => this.connect(), delay);
  }
  close() { this.closedByUser = true; clearTimeout(this.timer); if (this.ws) this.ws.close(); if (this.bc) this.bc.close(); }
  _recv(m) {
    if (!m || typeof m !== 'object') return;
    if (m._id) {
      if (this.seen.has(m._id)) return;
      this.seen.add(m._id);
      if (this.seen.size > 300) this.seen.delete(this.seen.values().next().value);
    }
    this.handlers.forEach((f) => { try { f(m); } catch (e) { console.error('[link]', e); } });
  }
  send(msg) {
    msg = { ...msg, _id: msg._id || Math.random().toString(36).slice(2) + Date.now().toString(36), _from: this.role };
    this.seen.add(msg._id);
    if (this.ws && this.ws.readyState === 1) this.ws.send(JSON.stringify(msg));
    if (this.bc) this.bc.postMessage(msg);
  }
}
