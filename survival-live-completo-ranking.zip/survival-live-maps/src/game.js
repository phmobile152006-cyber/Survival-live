// Núcleo do jogo: ciclo de partidas, entrada de jogadores, eliminações, presentes e comandos (sem DOM)
import { rand, pick, cleanName, normGift, fmtTime, TAU } from './utils.js';
import { settings as defaultSettings, DIFFICULTY } from './settings.js';
import { GameMap, PLAZA } from './map.js';
import { Effects } from './effects.js';
import { Combat, SPECIAL_WEAPONS, WEAPONS } from './combat.js';
import { SafeZone } from './safe-zone.js';
import { Items } from './items.js';
import { EventManager } from './events.js';
import { Fighter, BEHAVIORS } from './player.js';
import { spawnMonster, spawnInitialMonsters, MONSTER_TYPES, freeSpotAwayFromPlayers } from './enemies.js';
import { History, computeRanking } from './leaderboard.js';

const BOT_NAMES = ['Raven', 'Shadow', 'Blaze', 'Viper', 'Nova', 'Ghost', 'Titan', 'Pixel', 'Rocket', 'Ninja', 'Wolfie', 'Storm', 'Joker', 'Falcon', 'Mamba', 'Cobra', 'Turbo', 'Zeus', 'Hunter', 'Panda', 'Drift', 'Lynx', 'Maverick', 'Echo', 'Atlas', 'Bruxo', 'Capitão', 'Dragão', 'Fênix', 'Trovão', 'Tigre', 'Cacto'];
const ENDING_TIME = 12;

export class Game {
  constructor({ settings = defaultSettings, history } = {}) {
    this.settings = settings;
    this.history = history || new History();
    this.fx = new Effects();
    this.combat = new Combat(this);
    this.zone = new SafeZone(this);
    this.items = new Items(this);
    this.events = new EventManager(this);
    this.listeners = {};
    this.fighters = [];
    this.monsters = [];
    this.dangers = [];
    this.queue = [];
    this.round = 0;
    this.paused = false;
    this.audio = null;
    this.cameraMode = 'auto';
    this.followId = null;
    this.holdEnding = false;
    this.winner = null;
    this.botT = 0;
    this.botSeq = 0;
    this.fx.enabled = settings.get('effects');
    settings.onChange?.((d) => { this.fx.enabled = d.effects; });
    this.newRound();
  }

  // ---------- eventos internos ----------
  on(evt, fn) { (this.listeners[evt] ||= []).push(fn); }
  emit(evt, data) { const l = this.listeners[evt]; if (l) for (const fn of l) fn(data); }
  aliveCount() { let n = 0; for (const f of this.fighters) if (f.alive) n++; return n; }
  get diff() { return DIFFICULTY[this.settings.get('difficulty')] || DIFFICULTY.normal; }
  findFighter(name) { const id = String(name || '').replace(/^@/, '').toLowerCase(); return this.fighters.find((f) => f.id === id) || null; }

  // ---------- rodada ----------
  newRound() {
    const old = this.fighters;
    this.round++;
    this.map = new GameMap();
    this.fx.clear(); this.combat.clear(); this.items.clear(); this.events.reset();
    this.monsters = []; this.dangers = [];
    this.time = 0; this.phase = 'lobby'; this.countdown = null; this.winner = null; this.endT = 0; this.holdEnding = false; this.botT = 0;
    this.fighters = [];
    this.zone.reset(this.settings.get('matchDuration'), this.map.w / 2, this.map.h / 2);
    const max = this.settings.get('maxPlayers');
    if (this.settings.get('keepPlayers')) {
      for (const f of old) {
        if (f.bot || this.fighters.length >= max) continue;
        const nf = new Fighter(this, f.name, { behavior: f.behavior });
        nf.wins = f.wins; this.fighters.push(nf); nf.placeInLobby(this.fighters);
      }
    }
    while (this.queue.length && this.fighters.length < max) {
      const q = this.queue.shift();
      if (this.fighters.some((f) => f.id === q.id)) continue;
      const nf = new Fighter(this, q.name, { behavior: q.behavior });
      nf.wins = this.history.winsOf(q.name);
      this.fighters.push(nf); nf.placeInLobby(this.fighters);
    }
    this.emit('map', this.map);
    this.emit('phase', { phase: 'lobby', round: this.round });
  }

  startMatch() {
    if (this.phase !== 'lobby') return false;
    const min = this.settings.get('minPlayers');
    while (this.fighters.length < min) this.addBot(true);
    this.phase = 'playing'; this.countdown = null; this.time = 0;
    this.zone.reset(this.settings.get('matchDuration'), this.map.w / 2, this.map.h / 2);
    this.events.reset(); this.items.clear(); this.fx.clear();
    this.items.spawnInitial();
    const placed = [];
    for (const f of this.fighters) {
      let p = null;
      for (let t = 0; t < 25; t++) {
        const c = this.map.randomFree(Math.random, { x: this.zone.cx, y: this.zone.cy, r: this.zone.r * 0.88 }, 30);
        if (placed.every((o) => Math.hypot(o.x - c.x, o.y - c.y) > 220)) { p = c; break; }
        p = c;
      }
      placed.push(p);
      f.startMatch(p.x, p.y);
      f.kills = 0; f.alive = true; f.placement = 0; f.hp = f.maxHp;
    }
    spawnInitialMonsters(this);
    this.emit('phase', { phase: 'playing', round: this.round });
    this.emit('start', { players: this.fighters.length });
    this.audio?.('start', null);
    return true;
  }

  endMatch(winner, reason = 'last') {
    if (this.phase !== 'playing') return;
    this.phase = 'ending'; this.endT = ENDING_TIME; this.winner = winner;
    this.monsters = []; this.dangers = []; this.combat.clear(); this.events.active.length = 0; this.events.stormT = 0;
    if (winner) {
      winner.placement = 1; winner.wins++; winner.invuln = 999; winner.hp = winner.maxHp; winner.surviveTime = this.time;
      const entry = { name: winner.name, kills: winner.kills, time: fmtTime(this.time), round: this.round, bot: winner.bot };
      this.history.add(entry);
      this.emit('winner', { ...entry, wins: this.history.winsOf(winner.name), reason });
      this.audio?.('win', null);
    } else this.emit('winner', { name: null, reason });
    this.emit('phase', { phase: 'ending', round: this.round });
  }

  // ---------- jogadores ----------
  addBot(silent = false) {
    let name;
    for (let i = 0; i < 50; i++) {
      name = `${pick(BOT_NAMES)}${Math.random() < 0.5 ? '' : '_' + ((Math.random() * 99) | 0)}`;
      if (!this.findFighter(name)) break;
    }
    return this.addPlayer(name, { bot: true, silent });
  }
  addPlayer(rawName, { bot = false, behavior, silent = false } = {}) {
    const name = cleanName(rawName);
    if (!name) return 'invalid';
    const id = name.toLowerCase();
    if (this.fighters.some((f) => f.id === id)) return 'dup';
    if (this.queue.some((q) => q.id === id)) return 'queued';
    const max = this.settings.get('maxPlayers');
    const canSpawnNow = this.phase === 'lobby' || (this.phase === 'playing' && this.settings.get('lateJoin') && !bot && this.time < 90);
    if (!canSpawnNow) {
      if (bot) return 'busy';
      this.queue.push({ id, name, behavior });
      this.emit('queued', { name, position: this.queue.length });
      return 'queued';
    }
    if (this.fighters.length >= max) {
      const bi = bot ? -1 : this.fighters.findIndex((f) => f.bot && f.alive);
      if (bi < 0) {
        if (bot) return 'full';
        this.queue.push({ id, name, behavior });
        this.emit('queued', { name, position: this.queue.length, full: true });
        return 'full';
      }
      this.fighters.splice(bi, 1);
    }
    const f = new Fighter(this, name, { bot, behavior });
    f.wins = this.history.winsOf(name);
    this.fighters.push(f);
    if (this.phase === 'lobby') f.placeInLobby(this.fighters);
    else {
      const p = this.map.randomFree(Math.random, { x: this.zone.cx, y: this.zone.cy, r: this.zone.r * 0.8 }, 30);
      f.startMatch(p.x, p.y);
    }
    if (!silent) { this.emit('join', { name, bot, behavior: f.behavior }); this.audio?.('join', null); }
    this.fx.burst(f.x, f.y, 10, { speed: 100, life: 0.6, size: 3, color: f.look.accent });
    return 'ok';
  }
  removePlayer(name) {
    const id = String(name || '').replace(/^@/, '').toLowerCase();
    const qi = this.queue.findIndex((q) => q.id === id);
    if (qi >= 0) { this.queue.splice(qi, 1); return true; }
    const i = this.fighters.findIndex((f) => f.id === id);
    if (i < 0) return false;
    const f = this.fighters[i];
    if (this.phase === 'playing' && f.alive) { this.kill(f, null, { cause: 'removed' }); return true; }
    this.fighters.splice(i, 1);
    return true;
  }
  removeWhere(pred) {
    if (this.phase === 'playing') { for (const f of [...this.fighters]) if (f.alive && pred(f)) this.kill(f, null, { cause: 'removed' }); }
    else this.fighters = this.fighters.filter((f) => !pred(f));
  }

  // ---------- eliminação ----------
  kill(v, src, o = {}) {
    if (!v.alive) return;
    v.alive = false; v.hp = 0; v.deathCause = o.cause || null;
    this.fx.burst(v.x, v.y, v.isMonster ? 16 : 24, { speed: 170, life: 0.8, size: 4, color: v.isMonster ? ['#6a3a8a', '#3b2a4a', '#8bd14a'] : [v.look.shirt, '#d62d3a', '#fff'], drag: 3 });
    this.fx.ring(v.x, v.y, 5, v.isMonster && v.type === 'giant' ? 120 : 40, 0.5, '#fff', 3);
    this.audio?.(v.isMonster ? 'monsterDeath' : 'death', v);
    if (v.isMonster) {
      v.deadT = 0;
      const killer = src && src.isFighter ? src : null;
      if (killer) killer.monsterKills++;
      if (v.type === 'giant') {
        this.items.spawnCrate({ x: v.x, y: v.y, r: 60 }, true);
        this.emit('monsterKill', { text: `👹 ${v.name} foi derrotado${killer ? ' por ' + killer.name : ''}!` });
        this.fx.explosion(v.x, v.y, 130);
      } else if (Math.random() < 0.3) this.items.addRandom(v.x, v.y);
      return;
    }
    const remaining = this.aliveCount();
    v.placement = remaining + 1; v.deathT = this.time; v.surviveTime = this.time; v.corpseT = 0;
    let killer = null, text;
    const weapon = o.weapon || (src && src.isFighter ? WEAPONS[src.weapon]?.name : null);
    if (src && src.isFighter && src !== v) {
      killer = src; killer.kills++; killer.heal(12);
      text = `⚔️ ${killer.name} eliminou ${v.name}${weapon ? ' com ' + weapon : ''}`;
    } else if (src && src.isMonster) text = `💀 ${v.name} foi morto por ${src.name}`;
    else {
      const c = o.cause;
      text = c === 'zone' ? `☠️ ${v.name} foi consumido pela zona`
        : c === 'meteor' ? `☄️ ${v.name} foi atingido por um meteoro`
        : c === 'lightning' ? `⚡ ${v.name} foi atingido por um raio`
        : c === 'swamp' ? `🟣 ${v.name} sucumbiu ao pântano tóxico`
        : c === 'removed' ? `🚪 ${v.name} saiu da partida`
        : `💀 ${v.name} foi eliminado`;
    }
    this.emit('kill', { victim: v.name, killer: killer ? killer.name : null, text, placement: v.placement, remaining });
  }

  // ---------- chat e presentes ----------
  onChat(user, text) {
    const name = cleanName(user);
    if (!name) return;
    const t = String(text || '').trim().toLowerCase();
    if (/^!(entrar|join)(\s|$)/.test(t)) { const r = this.addPlayer(name); this.emit('chat', { user: name, text: t, result: r }); return r; }
    const m = /^!(agressivo|defensivo|explorador|estrategico|estratégico|aggressive|defensive|explorer|strategic)\b/.exec(t);
    if (m) {
      const map = { agressivo: 'aggressive', defensivo: 'defensive', explorador: 'explorer', estrategico: 'strategic', 'estratégico': 'strategic' };
      const b = map[m[1]] || m[1];
      const f = this.findFighter(name);
      if (f) { f.behavior = b; this.emit('chat', { user: name, text: t, result: 'style' }); return 'style'; }
      const q = this.queue.find((x) => x.id === name.toLowerCase());
      if (q) q.behavior = b;
    }
    return null;
  }

  onGift({ user, gift, count = 1, coins = 0, target = null }) {
    const key = normGift(gift);
    const cfg = this.settings.get('gifts') || {};
    let rule = cfg[key];
    if (!rule) {
      rule = coins >= 5000 ? { action: 'nova', value: 60 } : coins >= 1000 ? { action: 'meteors', value: 8 }
        : coins >= 100 ? { action: 'rage', value: 12 } : coins >= 10 ? { action: 'shield', value: 40 } : { action: 'heal', value: 20 };
    }
    const label = rule.label || gift || 'Presente';
    const uname = cleanName(user) || 'Alguém';
    const mult = Math.min(10, Math.max(1, Math.floor(count) || 1));
    let f = target ? this.findFighter(target) : this.findFighter(uname);
    if ((!f || !f.alive) && !target && this.phase === 'lobby' && user) { this.addPlayer(uname); f = this.findFighter(uname); }
    let fallback = false;
    if (!f || !f.alive) {
      const alive = this.fighters.filter((x) => x.alive);
      if (alive.length) { f = pick(alive); fallback = true; }
    }
    const who = f ? f.name : null;
    let text = '';
    const playing = this.phase === 'playing';
    const v = rule.value;
    switch (rule.action) {
      case 'heal': if (f) { f.heal(Number(v) * mult); text = `curou ${who} (+${Number(v) * mult})`; } break;
      case 'shield': if (f) { f.addShield(Number(v) * mult, 15); text = `deu escudo a ${who}`; this.fx.ring(f.x, f.y, 10, 40, 0.5, '#7ad7ff', 4); } break;
      case 'energy': if (f) { f.energy = Math.min(f.maxEnergy, f.energy + Number(v) * mult); f.heal(10 * mult); text = `energizou ${who}`; } break;
      case 'rage': if (f) { f.rageT = Math.min(40, f.rageT + Number(v) * mult); text = `liberou FÚRIA em ${who}`; this.fx.ring(f.x, f.y, 10, 60, 0.6, '#ff4d4d', 5); } break;
      case 'weapon': if (f) {
        const k = v && WEAPONS[v] ? v : pick(SPECIAL_WEAPONS);
        f.weapon = k; text = `deu ${WEAPONS[k].name} a ${who}`; this.fx.ring(f.x, f.y, 10, 50, 0.6, WEAPONS[k].color, 4);
      } break;
      case 'meteors': if (playing) { this.events.trigger('meteors', { count: Math.min(24, Number(v) * mult), by: uname, spare: f && !fallback ? f : null }); text = 'invocou CHUVA DE METEOROS'; } else text = '(guardado: eventos só durante a partida)'; break;
      case 'supply': if (playing) { this.events.trigger('supply', { by: uname, at: f }); text = 'chamou uma CAIXA DE SUPRIMENTOS'; } else text = '(guardado: só durante a partida)'; break;
      case 'zombies': if (playing) { this.events.trigger('zombies', { count: 10 * mult, by: uname }); text = 'soltou uma INVASÃO DE ZUMBIS'; } break;
      case 'boss': if (playing) { this.events.trigger('boss', { by: uname }); text = 'despertou o CHEFE FINAL'; } break;
      case 'nova': if (f && playing) {
        const R = 280, dmg = Math.min(200, Number(v) * mult);
        this.fx.explosion(f.x, f.y, 150); this.fx.ring(f.x, f.y, 20, R, 0.7, '#9ad7ff', 8); this.fx.shake = 14;
        f.heal(50); f.addShield(30, 15); this.audio?.('explosion', f);
        for (const e of [...this.fighters, ...this.monsters]) {
          if (e === f || !e.alive) continue;
          const d = Math.hypot(e.x - f.x, e.y - f.y) - e.r;
          if (d < R) this.combat.damage(e, dmg, f, { weapon: 'Supernova' });
        }
        text = `detonou uma SUPERNOVA em ${who}`;
      } else text = '(guardado: só durante a partida)'; break;
      default: text = 'enviou um presente';
    }
    this.emit('gift', { user: uname, gift: label, count: mult, text: `🎁 ${uname} enviou ${label}${mult > 1 ? ' x' + mult : ''}: ${text}${fallback ? ' (jogador sorteado)' : ''}` });
    this.audio?.('gift', null);
  }

  // ---------- comandos do painel ----------
  command(c) {
    switch (c.cmd) {
      case 'start': if (this.phase === 'ending') this.newRound(); this.startMatch(); break;
      case 'pause': this.paused = true; break;
      case 'resume': this.paused = false; break;
      case 'togglePause': this.paused = !this.paused; break;
      case 'restart': this.paused = false; this.newRound(); break;
      case 'skipLobby': if (this.phase === 'lobby') this.countdown = Math.min(this.countdown ?? 3, 3); if (this.countdown === null) { this.countdown = 3; } break;
      case 'endRound': if (this.phase === 'playing') {
        const alive = this.fighters.filter((f) => f.alive).sort((a, b) => b.kills - a.kills || b.hp - a.hp);
        this.endMatch(alive[0] || null, 'admin');
      } break;
      case 'addBot': { const n = Math.min(60, Math.max(1, c.n | 0 || 1)); for (let i = 0; i < n; i++) this.addBot(); break; }
      case 'addPlayer': this.addPlayer(c.name, { behavior: c.behavior }); break;
      case 'remove': this.removePlayer(c.name); break;
      case 'removeBots': this.removeWhere((f) => f.bot); break;
      case 'removeAll': this.removeWhere(() => true); this.queue.length = 0; break;
      case 'summon': {
        if (!MONSTER_TYPES[c.kind]) break;
        const n = Math.min(30, Math.max(1, c.n | 0 || 1));
        const region = { x: this.zone.cx, y: this.zone.cy, r: Math.max(100, this.zone.r * 0.9) };
        for (let i = 0; i < n; i++) {
          const p = freeSpotAwayFromPlayers(this, region, 200);
          spawnMonster(this, c.kind, p.x, p.y, { hunt: c.kind === 'giant' });
        }
        this.emit('event', { key: 'summon', name: `${MONSTER_TYPES[c.kind].label.toUpperCase()} INVOCADO`, icon: '👾', msg: `Streamer invocou ${n}x ${MONSTER_TYPES[c.kind].label}`, color: '#c58cff' });
        break;
      }
      case 'event': this.events.trigger(c.name, { by: null }); break;
      case 'follow': this.followId = c.name ? String(c.name).toLowerCase() : null; this.cameraMode = c.name ? 'follow' : 'auto'; break;
      case 'camera': this.cameraMode = ['auto', 'overview', 'follow'].includes(c.mode) ? c.mode : 'auto'; break;
      case 'clearHistory': this.history.clear(); break;
      default: break;
    }
  }

  snapshot() {
    const rk = computeRanking(this);
    return {
      phase: this.phase, round: this.round, time: Math.floor(this.time), countdown: this.countdown === null ? null : Math.ceil(this.countdown),
      alive: this.aliveCount(), total: this.fighters.length, queue: this.queue.length, paused: this.paused,
      monsters: this.monsters.filter((m) => m.alive).length, zoneStage: this.zone.stage, zoneR: Math.round(this.zone.r),
      events: this.events.active.map((e) => e.key), cameraMode: this.cameraMode,
      players: rk.all.slice(0, 80).map((f) => ({ name: f.name, alive: f.alive, kills: f.kills, hp: Math.round(f.hp), bot: f.bot, behavior: f.behavior, placement: f.placement })),
      winners: this.history.winners.slice(0, 8),
    };
  }

  // ---------- atualização ----------
  update(dt) {
    this.fx.update(dt);
    if (this.paused) return;
    switch (this.phase) {
      case 'lobby': this.updateLobby(dt); break;
      case 'playing': this.updatePlaying(dt); break;
      case 'ending': this.updateEnding(dt); break;
    }
  }

  updateLobby(dt) {
    const max = this.settings.get('maxPlayers');
    const target = Math.min(this.settings.get('fillBotsTo'), max);
    if (this.fighters.length < target) {
      this.botT -= dt;
      if (this.botT <= 0) { this.botT = 0.45; this.addBot(); }
    }
    for (const f of this.fighters) f.update(dt);
    this.separate();
    if (this.fighters.length >= this.settings.get('minPlayers')) {
      if (this.countdown === null) { this.countdown = this.settings.get('lobbyTime'); this.emit('countdown', { t: this.countdown }); }
      const before = Math.ceil(this.countdown);
      this.countdown -= dt;
      const after = Math.ceil(this.countdown);
      if (after !== before && after <= 5 && after > 0) this.audio?.('tick', null);
      if (this.countdown <= 0) this.startMatch();
    } else this.countdown = null;
  }

  updatePlaying(dt) {
    this.time += dt;
    this.zone.update(dt, this.events.stormMult);
    this.events.update(dt);
    this.items.update(dt);
    for (const f of this.fighters) f.update(dt);
    for (const m of this.monsters) m.update(dt);
    this.combat.update(dt);
    this.separate();
    // perigos telegrafados
    for (let i = this.dangers.length - 1; i >= 0; i--) {
      const d = this.dangers[i];
      d.t -= dt;
      if (d.follow) { d.x = d.follow.x; d.y = d.follow.y; if (!d.follow.alive) { this.dangers.splice(i, 1); continue; } }
      if (d.t <= 0) { this.dangers.splice(i, 1); d.onEnd && d.onEnd(this); }
    }
    // dano ambiental: zona e pântano
    const dps = this.zone.dps(this.diff.zoneDps);
    const over = Math.max(0, this.time - this.settings.get('matchDuration')) * 0.3;
    for (const f of this.fighters) {
      if (!f.alive || f.invuln > 0) continue;
      f.envT = (f.envT || 0) - dt;
      const out = this.zone.outside(f.x, f.y);
      if (out) f.outT = (f.outT || 0) + dt; else f.outT = 0;
      if (f.envT <= 0) {
        f.envT = 0.5;
        if (out) this.combat.damage(f, (dps + over + Math.min(8, f.outT * 0.4)) * 0.5, null, { cause: 'zone', quiet: true });
        if (f.alive && this.map.terrain(f.x, f.y) === 2) this.combat.damage(f, 3, null, { cause: 'swamp', quiet: true });
      }
    }
    // corpos de monstros somem
    for (let i = this.monsters.length - 1; i >= 0; i--) if (!this.monsters[i].alive && this.monsters[i].deadT > 1.5) this.monsters.splice(i, 1);
    // fim de partida
    const alive = this.aliveCount();
    if (this.fighters.length >= 2 && alive <= 1) {
      let w = this.fighters.find((f) => f.alive);
      if (!w) w = [...this.fighters].sort((a, b) => b.deathT - a.deathT || b.kills - a.kills)[0];
      this.endMatch(w || null, 'last');
    } else if (this.time > this.settings.get('matchDuration') + 120) {
      const best = this.fighters.filter((f) => f.alive).sort((a, b) => b.kills - a.kills || b.hp - a.hp)[0];
      this.endMatch(best || null, 'timeout');
    }
  }

  updateEnding(dt) {
    this.endT -= dt;
    const w = this.winner;
    if (w) {
      w.update(dt);
      this.fireT = (this.fireT || 0) - dt;
      if (this.fireT <= 0) {
        this.fireT = 0.35;
        const a = rand(TAU), d = rand(60, 220);
        const x = w.x + Math.cos(a) * d, y = w.y + Math.sin(a) * d - 60;
        this.fx.burst(x, y, 26, { speed: 190, life: 1.1, size: 3.5, color: ['#ffd166', '#ff6b6b', '#6bd6ff', '#9aff8a', '#d68cff'], drag: 1.6, grav: 60 });
        this.fx.ring(x, y, 4, 40, 0.5, '#ffd166', 3);
        this.audio?.('firework', { x, y });
      }
    }
    for (const f of this.fighters) if (f !== w) f.update(dt);
    if (this.endT <= 0) {
      if (this.settings.get('autoRestart')) this.newRound();
      else if (!this.holdEnding) { this.holdEnding = true; this.emit('hold', {}); }
    }
  }

  /** empurra entidades sobrepostas */
  separate() {
    const arr = [];
    for (const f of this.fighters) if (f.alive) arr.push(f);
    for (const m of this.monsters) if (m.alive) arr.push(m);
    for (let i = 0; i < arr.length; i++) {
      const a = arr[i];
      for (let j = i + 1; j < arr.length; j++) {
        const b = arr[j];
        const dx = b.x - a.x, dy = b.y - a.y, m = (a.r + b.r) * 0.85;
        const d2 = dx * dx + dy * dy;
        if (d2 < m * m && d2 > 0.0001) {
          const d = Math.sqrt(d2), o = (m - d) * 0.5;
          const wa = b.r / (a.r + b.r), wb = a.r / (a.r + b.r);
          a.x -= (dx / d) * o * 2 * wa * 0.5; a.y -= (dy / d) * o * 2 * wa * 0.5;
          b.x += (dx / d) * o * 2 * wb * 0.5; b.y += (dy / d) * o * 2 * wb * 0.5;
        }
      }
    }
  }
}
