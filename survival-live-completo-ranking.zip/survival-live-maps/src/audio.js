// Efeitos sonoros sintetizados com WebAudio (sem arquivos externos)
export class AudioSystem {
  constructor() { this.ctx = null; this.enabled = true; this.master = null; this.last = {}; this.voices = 0; }
  unlock() {
    if (this.ctx) { if (this.ctx.state === 'suspended') this.ctx.resume(); return; }
    const AC = globalThis.AudioContext || globalThis.webkitAudioContext;
    if (!AC) return;
    try {
      this.ctx = new AC();
      this.master = this.ctx.createGain(); this.master.gain.value = 0.35; this.master.connect(this.ctx.destination);
      const len = this.ctx.sampleRate;
      this.noiseBuf = this.ctx.createBuffer(1, len, this.ctx.sampleRate);
      const d = this.noiseBuf.getChannelData(0);
      for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;
    } catch { this.ctx = null; }
  }
  tone(f0, f1, dur, type = 'sine', vol = 0.3, delay = 0) {
    const c = this.ctx; if (!c) return;
    const t = c.currentTime + delay;
    const o = c.createOscillator(), g = c.createGain();
    o.type = type; o.frequency.setValueAtTime(f0, t); o.frequency.exponentialRampToValueAtTime(Math.max(20, f1), t + dur);
    g.gain.setValueAtTime(vol, t); g.gain.exponentialRampToValueAtTime(0.0008, t + dur);
    o.connect(g); g.connect(this.master); o.start(t); o.stop(t + dur + 0.02);
    this.voices++; o.onended = () => { this.voices--; };
  }
  noise(dur, vol = 0.3, f0 = 2000, f1 = 400, delay = 0, type = 'lowpass') {
    const c = this.ctx; if (!c) return;
    const t = c.currentTime + delay;
    const s = c.createBufferSource(); s.buffer = this.noiseBuf;
    const f = c.createBiquadFilter(); f.type = type; f.frequency.setValueAtTime(f0, t); f.frequency.exponentialRampToValueAtTime(Math.max(40, f1), t + dur);
    const g = c.createGain(); g.gain.setValueAtTime(vol, t); g.gain.exponentialRampToValueAtTime(0.0008, t + dur);
    s.connect(f); f.connect(g); g.connect(this.master); s.start(t, Math.random() * 0.5); s.stop(t + dur + 0.02);
    this.voices++; s.onended = () => { this.voices--; };
  }
  play(name) {
    if (!this.enabled || !this.ctx || this.voices > 28) return;
    const now = this.ctx.currentTime;
    const gap = { hit: 0.05, swing: 0.07, shoot: 0.05, bow: 0.1, flame: 0.12, explosion: 0.08, bite: 0.1, zombie: 0.3 }[name] ?? 0.03;
    if (now - (this.last[name] || 0) < gap) return;
    this.last[name] = now;
    switch (name) {
      case 'hit': this.noise(0.08, 0.25, 1800, 300); this.tone(180, 70, 0.08, 'square', 0.1); break;
      case 'swing': this.noise(0.12, 0.12, 3000, 900, 0, 'bandpass'); break;
      case 'shoot': this.tone(900, 180, 0.1, 'square', 0.12); this.noise(0.06, 0.1, 4000, 800); break;
      case 'bow': this.tone(380, 120, 0.12, 'triangle', 0.15); break;
      case 'flame': this.noise(0.15, 0.1, 2500, 600); break;
      case 'explosion': this.noise(0.6, 0.5, 1400, 90); this.tone(110, 28, 0.5, 'sine', 0.4); break;
      case 'death': this.tone(320, 70, 0.4, 'sawtooth', 0.18); break;
      case 'monsterDeath': this.tone(140, 40, 0.5, 'sawtooth', 0.2); break;
      case 'pickup': this.tone(520, 880, 0.12, 'triangle', 0.18); this.tone(880, 1320, 0.1, 'triangle', 0.14, 0.08); break;
      case 'crate': this.tone(300, 700, 0.2, 'square', 0.15); this.tone(600, 1200, 0.25, 'triangle', 0.15, 0.1); break;
      case 'join': this.tone(660, 990, 0.09, 'sine', 0.14); break;
      case 'tick': this.tone(880, 880, 0.08, 'square', 0.12); break;
      case 'start': this.tone(220, 220, 0.5, 'sawtooth', 0.2); this.tone(330, 330, 0.5, 'sawtooth', 0.15); this.noise(0.5, 0.15, 1200, 300); break;
      case 'win': [523, 659, 784, 1047, 1319].forEach((f, i) => this.tone(f, f, 0.35, 'triangle', 0.2, i * 0.12)); break;
      case 'event': this.tone(700, 500, 0.25, 'square', 0.15); this.tone(700, 500, 0.25, 'square', 0.15, 0.3); break;
      case 'gift': [880, 1175, 1568].forEach((f, i) => this.tone(f, f * 1.01, 0.18, 'sine', 0.15, i * 0.07)); break;
      case 'dash': this.noise(0.14, 0.12, 2500, 500, 0, 'highpass'); break;
      case 'roar': this.tone(95, 45, 0.7, 'sawtooth', 0.3); break;
      case 'slam': this.noise(0.5, 0.5, 600, 60); this.tone(70, 25, 0.5, 'sine', 0.5); break;
      case 'thunder': this.noise(0.9, 0.45, 900, 70); break;
      case 'zombie': this.tone(110, 70, 0.25, 'sawtooth', 0.1); break;
      case 'bite': this.noise(0.08, 0.15, 2500, 700); break;
      case 'firework': this.noise(0.4, 0.15, 3500, 800, 0, 'highpass'); this.tone(900, 300, 0.3, 'triangle', 0.07); break;
      default: break;
    }
  }
}
