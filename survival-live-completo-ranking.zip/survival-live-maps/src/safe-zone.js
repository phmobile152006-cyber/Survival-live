// Zona segura que diminui durante a partida (sem DOM)
import { lerp, rand, TAU } from './utils.js';

export const ZONE_RADII = [1750, 1250, 880, 560, 320, 150, 40];
const DPS = [2.5, 4, 6, 9, 13, 18, 30];

export class SafeZone {
  constructor(game) { this.game = game; this.reset(300, 1800, 1800, 'idle'); }
  reset(duration = 300, cx = 1800, cy = 1800) {
    this.cx = cx; this.cy = cy; this.r = ZONE_RADII[0];
    this.stage = 0;
    this.phase = 'hold';
    this.hold0 = Math.max(10, duration * 0.14);
    this.hold = Math.max(8, duration * 0.085);
    this.shrinkDur = Math.max(6, duration * 0.065);
    this.timer = this.hold0;
    this.shrinkT = 0;
    this.active = false;
    this._next();
  }
  _next() {
    const nr = ZONE_RADII[this.stage + 1];
    if (nr === undefined) { this.nr = this.r; this.nx = this.cx; this.ny = this.cy; return; }
    const off = rand(0.2, 0.85) * Math.max(0, this.r - nr);
    const a = rand(TAU);
    this.nr = nr; this.nx = this.cx + Math.cos(a) * off; this.ny = this.cy + Math.sin(a) * off;
  }
  get overtime() { return this.stage >= ZONE_RADII.length - 1; }
  /** onde os bots devem mirar (próximo círculo quando a redução é iminente) */
  get aim() {
    if (this.phase === 'shrink' || (this.phase === 'hold' && this.timer < 10 && !this.overtime)) return { x: this.nx, y: this.ny, r: this.nr };
    return { x: this.cx, y: this.cy, r: this.r };
  }
  update(dt, stormMult = 1) {
    if (this.overtime) return;
    if (this.phase === 'hold') {
      this.timer -= dt;
      if (this.timer <= 0) { this.phase = 'shrink'; this.shrinkT = 0; this.fx = this.cx; this.fy = this.cy; this.fr = this.r; }
    } else {
      this.shrinkT += dt * stormMult;
      const p = Math.min(1, this.shrinkT / this.shrinkDur);
      this.cx = lerp(this.fx, this.nx, p); this.cy = lerp(this.fy, this.ny, p); this.r = lerp(this.fr, this.nr, p);
      if (p >= 1) { this.stage++; this.phase = 'hold'; this.timer = this.hold; this._next(); }
    }
  }
  outside(x, y, pad = 0) { return Math.hypot(x - this.cx, y - this.cy) > this.r - pad; }
  dps(diffMul = 1) { return DPS[Math.min(this.stage, DPS.length - 1)] * diffMul; }
}
