// Núcleo do ranking de espectadores (sem DOM — roda no navegador e no servidor Node).
//
// Tudo que muda o ranking é uma "operação" (op) com id único. Aplicar a mesma op duas vezes
// não faz nada (idempotente), então eventos repetidos, reenvios e reconexões não duplicam pontos.
// O mesmo código é usado pelo jogo, pelo painel e pelo servidor (server/ranking-store.js).
import { cleanName, normGift } from './utils.js';

export const STATE_VERSION = 1;
const LEDGER_MAX = 8000;
const MAX_PROFILES = 20000;
const HISTORY_MAX = 20;

// ---------- pontuação (configurável no painel) ----------
export const DEFAULT_SCORING = {
  participation: 10, // por partida concluída
  elimination: 25, // por jogador eliminado
  victory: 100, // bônus por vencer a partida
  giftSmall: 5, // ex.: Rosa
  giftMedium: 25,
  giftLarge: 100,
  mediumMinCoins: 10, // moedas (por unidade) a partir das quais o presente é "médio"
  largeMinCoins: 500, // ... e "grande"
  maxGiftCount: 10, // limite de unidades por presente (combos)
  botKills: true, // eliminar bots também pontua
};
const SCORING_LIMITS = {
  participation: [0, 100000], elimination: [0, 100000], victory: [0, 100000], giftSmall: [0, 100000], giftMedium: [0, 100000], giftLarge: [0, 100000],
  mediumMinCoins: [1, 1000000], largeMinCoins: [1, 1000000], maxGiftCount: [1, 100],
};

// ---------- níveis ----------
export const LEVELS = [
  { id: 'bronze', name: 'Bronze', icon: '🥉', color: '#cd7f32' },
  { id: 'silver', name: 'Prata', icon: '🥈', color: '#c7d0dc' },
  { id: 'gold', name: 'Ouro', icon: '🥇', color: '#ffc933' },
  { id: 'platinum', name: 'Platina', icon: '💠', color: '#5eead4' },
  { id: 'diamond', name: 'Diamante', icon: '💎', color: '#60a5fa' },
  { id: 'legendary', name: 'Lendário', icon: '👑', color: '#f472d0' },
];
export const DEFAULT_LEVEL_MINS = [0, 250, 750, 2000, 5000, 12000];

export const TABS = {
  overall: { label: 'Geral', sort: 'points' },
  kills: { label: 'Mais eliminações', sort: 'kills' },
  wins: { label: 'Mais vitórias', sort: 'wins' },
  active: { label: 'Mais ativos', sort: 'matches' },
  gifts: { label: 'Mais presentes', sort: 'gifts' },
};
export const SORTS = { points: 'Pontos', wins: 'Vitórias', kills: 'Eliminações', matches: 'Participação', gifts: 'Presentes' };

// valor aproximado (moedas) quando o evento não traz o preço — só vale para presentes sem "coins"
const GIFT_TIER_BY_NAME = {
  rose: 'S', tiktok: 'S', gg: 'S', fingerheart: 'S', heart: 'M', doughnut: 'M', handhearts: 'M', dramaqueen: 'L', galaxy: 'L', lion: 'L', universe: 'L',
};

const num = (v, min, max, def) => { v = Number(v); return Number.isFinite(v) ? Math.min(max, Math.max(min, v)) : def; };
export const keyOf = (user) => cleanName(user).toLowerCase();

export function sanitizeConfig(c = {}) {
  const out = {};
  for (const k in DEFAULT_SCORING) {
    if (typeof DEFAULT_SCORING[k] === 'boolean') out[k] = c[k] === undefined ? DEFAULT_SCORING[k] : !!c[k];
    else { const [a, b] = SCORING_LIMITS[k]; out[k] = Math.round(num(c[k], a, b, DEFAULT_SCORING[k])); }
  }
  const mins = Array.isArray(c.levelMins) ? c.levelMins.map(Number) : [];
  const lm = [0];
  for (let i = 1; i < LEVELS.length; i++) {
    const v = Math.round(num(mins[i], 1, 100000000, DEFAULT_LEVEL_MINS[i]));
    lm.push(Math.max(v, lm[i - 1] + 1)); // sempre crescente
  }
  out.levelMins = lm;
  return out;
}

// ---------- períodos (semana ISO / mês), no fuso de quem gerou a op ----------
export function periodKeys(ts = Date.now()) {
  const d = new Date(ts);
  const t = new Date(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate()));
  const day = t.getUTCDay() || 7;
  t.setUTCDate(t.getUTCDate() + 4 - day);
  const y0 = new Date(Date.UTC(t.getUTCFullYear(), 0, 1));
  const wk = Math.ceil(((t - y0) / 86400000 + 1) / 7);
  return { wk: `${t.getUTCFullYear()}-W${String(wk).padStart(2, '0')}`, mk: `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}` };
}

// ---------- classificação de presentes ----------
export function giftTier(gift, coins, count, cfg) {
  const n = Math.max(1, Math.floor(count) || 1);
  const unit = Number(coins) > 0 ? Number(coins) / n : 0;
  if (unit > 0) return unit >= cfg.largeMinCoins ? 'L' : unit >= cfg.mediumMinCoins ? 'M' : 'S';
  return GIFT_TIER_BY_NAME[normGift(gift)] || 'S';
}
export function giftPoints(gift, coins, count, cfg) {
  const tier = giftTier(gift, coins, count, cfg);
  const n = Math.min(cfg.maxGiftCount, Math.max(1, Math.floor(count) || 1));
  const per = tier === 'L' ? cfg.giftLarge : tier === 'M' ? cfg.giftMedium : cfg.giftSmall;
  return { tier, pts: per * n, n };
}

// ---------- níveis ----------
export function levelOf(points, mins = DEFAULT_LEVEL_MINS) {
  let i = 0;
  for (let k = 0; k < mins.length; k++) if (points >= mins[k]) i = k;
  const cur = LEVELS[i], next = LEVELS[i + 1] || null;
  const progress = next ? Math.min(1, (points - mins[i]) / (mins[i + 1] - mins[i])) : 1;
  return { index: i, ...cur, min: mins[i], next: next ? { ...next, min: mins[i + 1] } : null, progress };
}

const emptyBlock = () => ({ points: 0, kills: 0, wins: 0, matches: 0, gifts: 0, giftsReal: 0, coins: 0 });
const emptyState = () => ({ v: STATE_VERSION, rev: 0, createdAt: Date.now(), updatedAt: 0, config: sanitizeConfig({}), resets: { week: 0, month: 0 }, profiles: {}, ledger: [] });
const OPS = new Set(['join', 'kill', 'gift', 'match', 'adjust', 'reset', 'config', 'purge']);

export class ViewerStore {
  constructor(state) {
    this.listeners = {};
    this.load(state);
  }
  // ----- estado -----
  load(state) {
    const s = state && typeof state === 'object' && state.v === STATE_VERSION && state.profiles ? state : emptyState();
    this.state = s;
    this.state.config = sanitizeConfig(s.config);
    this.state.resets ||= { week: 0, month: 0 };
    this.state.ledger = Array.isArray(s.ledger) ? s.ledger.slice(-LEDGER_MAX) : [];
    this.ids = new Set(this.state.ledger);
    this._sorted = null;
  }
  snapshot() { return this.state; }
  get config() { return this.state.config; }
  get rev() { return this.state.rev; }
  get size() { return Object.keys(this.state.profiles).length; }

  // ----- eventos -----
  on(evt, fn) { (this.listeners[evt] ||= []).push(fn); return () => { this.listeners[evt] = this.listeners[evt].filter((f) => f !== fn); }; }
  emit(evt, data) { const l = this.listeners[evt]; if (l) for (const fn of l) { try { fn(data); } catch (e) { console.error('[viewers]', e); } } }

  // ----- leitura -----
  profile(user) { return this.state.profiles[keyOf(user)] || null; }
  has(id) { return this.ids.has(id); }
  block(p, period, keys = periodKeys()) {
    if (period === 'week') return p.week && p.week.k === keys.wk ? p.week : emptyBlock();
    if (period === 'month') return p.month && p.month.k === keys.mk ? p.month : emptyBlock();
    return p.total;
  }
  levelOfProfile(p) { return levelOf(p ? p.total.points : 0, this.state.config.levelMins); }
  /** classificação já ordenada: [{rank, key, name, real, level, ...bloco}] */
  board({ period = 'all', sort = 'points', includeSim = true, search = '', limit = 0 } = {}) {
    const keys = periodKeys(), q = String(search || '').trim().toLowerCase().replace(/^@/, '');
    const sk = SORTS[sort] ? sort : 'points';
    let rows = [];
    for (const k in this.state.profiles) {
      const p = this.state.profiles[k];
      if (!includeSim && !p.real) continue;
      const b = this.block(p, period, keys);
      if (period !== 'all' && !(b.points || b.matches || b.gifts || b.kills)) continue;
      rows.push({ key: k, name: p.name, real: !!p.real, lastSeen: p.lastSeen, ...b, level: this.levelOfProfile(p) });
    }
    rows.sort((a, b) => b[sk] - a[sk] || b.points - a.points || b.wins - a.wins || (a.name < b.name ? -1 : a.name > b.name ? 1 : 0));
    rows.forEach((r, i) => { r.rank = i + 1; });
    if (q) rows = rows.filter((r) => r.key.includes(q));
    return limit ? rows.slice(0, limit) : rows;
  }
  rankOf(user, opts = {}) {
    const k = keyOf(user);
    const r = this.board({ includeSim: true, ...opts }).find((x) => x.key === k);
    return r ? r.rank : null;
  }
  /** perfil completo para a tela de detalhes */
  detail(user) {
    const p = this.profile(user); if (!p) return null;
    const keys = periodKeys(), t = p.total;
    return {
      key: keyOf(user), name: p.name, real: !!p.real, firstSeen: p.firstSeen, lastSeen: p.lastSeen,
      rank: this.rankOf(user), rankWeek: this.rankOf(user, { period: 'week' }), rankMonth: this.rankOf(user, { period: 'month' }),
      total: { ...t }, week: { ...this.block(p, 'week', keys) }, month: { ...this.block(p, 'month', keys) },
      winRate: t.matches ? Math.round((t.wins / t.matches) * 1000) / 10 : 0,
      level: this.levelOfProfile(p), history: p.history.slice(),
    };
  }
  stats() {
    let real = 0, points = 0;
    for (const k in this.state.profiles) { const p = this.state.profiles[k]; if (p.real) real++; points += p.total.points; }
    return { profiles: this.size, real, sim: this.size - real, points, rev: this.state.rev };
  }

  // ----- escrita -----
  _profile(key, name, ts, create = true) {
    let p = this.state.profiles[key];
    if (!p) {
      if (!create || this.size >= MAX_PROFILES) return null;
      p = this.state.profiles[key] = { name, real: false, firstSeen: ts, lastSeen: ts, total: emptyBlock(), week: { k: '', ...emptyBlock() }, month: { k: '', ...emptyBlock() }, history: [], cur: null };
    }
    p.lastSeen = Math.max(p.lastSeen || 0, ts);
    return p;
  }
  _periodBlocks(p, op) {
    if (p.week.k !== op.wk) p.week = { k: op.wk, ...emptyBlock() };
    if (p.month.k !== op.mk) p.month = { k: op.mk, ...emptyBlock() };
    return [p.total, p.week, p.month];
  }
  /** aplica uma op. Retorna 'applied' | 'dup' | 'invalid' */
  apply(raw) {
    const op = this._clean(raw);
    if (!op) return 'invalid';
    if (this.ids.has(op.id)) return 'dup';
    const before = op.user ? this.profile(op.user) : null;
    const lvBefore = before ? this.levelOfProfile(before).index : 0;
    let touched = null;
    switch (op.t) {
      case 'join': {
        const p = this._profile(op.key, op.name, op.ts); if (!p) return 'invalid';
        if (op.real) p.real = true;
        touched = p; break;
      }
      case 'kill': {
        const p = this._profile(op.key, op.name, op.ts); if (!p) return 'invalid';
        if (op.real) p.real = true;
        for (const b of this._periodBlocks(p, op)) { b.points += op.pts; b.kills++; }
        if (!p.cur || p.cur.rid !== op.rid) p.cur = { rid: op.rid, pts: 0 };
        p.cur.pts += op.pts;
        touched = p; break;
      }
      case 'gift': {
        const p = this._profile(op.key, op.name, op.ts); if (!p) return 'invalid';
        if (op.real) p.real = true;
        for (const b of this._periodBlocks(p, op)) { b.points += op.pts; b.gifts += op.count; b.coins += op.coins; if (op.real) b.giftsReal += op.count; }
        touched = p; break;
      }
      case 'match': {
        const p = this._profile(op.key, op.name, op.ts); if (!p) return 'invalid';
        if (op.real) p.real = true;
        for (const b of this._periodBlocks(p, op)) { b.points += op.pts; b.matches++; if (op.won) b.wins++; }
        const killPts = p.cur && p.cur.rid === op.rid ? p.cur.pts : 0;
        p.history.unshift({ ts: op.ts, round: op.round, won: op.won, place: op.place, kills: op.kills, pts: op.pts + killPts, real: !!op.real });
        p.history.length = Math.min(p.history.length, HISTORY_MAX);
        p.cur = null;
        touched = p; break;
      }
      case 'adjust': {
        const p = this._profile(op.key, op.name, op.ts); if (!p) return 'invalid';
        for (const b of this._periodBlocks(p, op)) b.points = Math.max(0, b.points + op.delta);
        touched = p; break;
      }
      case 'reset': {
        for (const k in this.state.profiles) {
          const p = this.state.profiles[k];
          if (op.scope === 'week') p.week = { k: op.wk, ...emptyBlock() }; else p.month = { k: op.mk, ...emptyBlock() };
        }
        this.state.resets[op.scope] = op.ts; break;
      }
      case 'config': this.state.config = sanitizeConfig(op.config); break;
      case 'purge': {
        for (const k in this.state.profiles) if (!this.state.profiles[k].real) delete this.state.profiles[k];
        break;
      }
      default: return 'invalid';
    }
    this.ids.add(op.id); this.state.ledger.push(op.id);
    if (this.state.ledger.length > LEDGER_MAX + 500) { this.state.ledger = this.state.ledger.slice(-LEDGER_MAX); this.ids = new Set(this.state.ledger); }
    this.state.rev++; this.state.updatedAt = op.ts;
    this.emit('change', { op });
    if (touched) {
      const lv = this.levelOfProfile(touched);
      if (lv.index > lvBefore) this.emit('levelup', { key: op.key, name: touched.name, from: LEVELS[lvBefore], to: lv });
    }
    return 'applied';
  }

  _clean(o) {
    if (!o || typeof o !== 'object' || !OPS.has(o.t)) return null;
    const id = String(o.id || '').slice(0, 90);
    if (!id) return null;
    const keys = periodKeys();
    const op = {
      id, t: o.t, ts: num(o.ts, 0, 4e12, Date.now()), real: o.real === true,
      wk: /^\d{4}-W\d{2}$/.test(o.wk) ? o.wk : keys.wk, mk: /^\d{4}-\d{2}$/.test(o.mk) ? o.mk : keys.mk,
    };
    if (['join', 'kill', 'gift', 'match', 'adjust'].includes(o.t)) {
      op.name = cleanName(o.user); op.key = op.name.toLowerCase(); op.user = op.name;
      if (!op.key) return null;
    }
    switch (o.t) {
      case 'kill': op.pts = Math.round(num(o.pts, 0, 100000, 0)); op.rid = String(o.rid || '').slice(0, 40); break;
      case 'gift': op.pts = Math.round(num(o.pts, 0, 1000000, 0)); op.count = Math.round(num(o.count, 1, 1000, 1)); op.coins = Math.round(num(o.coins, 0, 1e9, 0)); break;
      case 'match':
        op.pts = Math.round(num(o.pts, 0, 100000, 0)); op.rid = String(o.rid || '').slice(0, 40); op.round = Math.round(num(o.round, 0, 1e7, 0));
        op.won = o.won === true; op.place = Math.round(num(o.place, 0, 1000, 0)); op.kills = Math.round(num(o.kills, 0, 1000, 0)); break;
      case 'adjust': op.delta = Math.round(num(o.delta, -1e7, 1e7, 0)); if (!op.delta) return null; break;
      case 'reset': if (o.scope !== 'week' && o.scope !== 'month') return null; op.scope = o.scope; break;
      case 'config': op.config = o.config || {}; break;
      default: break;
    }
    return op;
  }

  // ----- exportação -----
  exportJSON() {
    const rows = this.board({ period: 'all' });
    return JSON.stringify({ exportedAt: new Date().toISOString(), config: this.state.config, resets: this.state.resets, profiles: rows.map((r) => this.detail(r.name)) }, null, 2);
  }
  exportCSV() {
    const keys = periodKeys();
    const head = ['posicao', 'usuario', 'origem', 'nivel', 'pontos', 'eliminacoes', 'vitorias', 'partidas', 'taxa_vitoria_%', 'presentes', 'presentes_reais', 'moedas', 'pontos_semana', 'pontos_mes', 'ultima_atividade'];
    const q = (v) => { v = String(v); return /[",\n;]/.test(v) ? '"' + v.replace(/"/g, '""') + '"' : v; };
    const lines = [head.join(',')];
    for (const r of this.board({ period: 'all' })) {
      const p = this.state.profiles[r.key];
      lines.push([r.rank, r.name, p.real ? 'tiktok' : 'simulado', r.level.name, r.points, r.kills, r.wins, r.matches, r.matches ? Math.round((r.wins / r.matches) * 1000) / 10 : 0, r.gifts, r.giftsReal, r.coins,
        this.block(p, 'week', keys).points, this.block(p, 'month', keys).points, new Date(p.lastSeen).toISOString()].map(q).join(','));
    }
    return lines.join('\n');
  }
}

// ---------- fábrica de ops (usa a configuração atual) ----------
export const ops = {
  join: (id, user, real = false) => ({ id, t: 'join', user, real, ts: Date.now(), ...periodKeys() }),
  kill: (id, user, rid, cfg, real = false) => ({ id, t: 'kill', user, rid, pts: cfg.elimination, real, ts: Date.now(), ...periodKeys() }),
  match: (id, user, m, cfg, real = false) => ({
    id, t: 'match', user, rid: m.rid, round: m.round, won: !!m.won, place: m.place || 0, kills: m.kills || 0,
    pts: cfg.participation + (m.won ? cfg.victory : 0), real, ts: Date.now(), ...periodKeys(),
  }),
  gift: (id, user, g, cfg, real = false) => {
    const { pts, n } = giftPoints(g.gift, g.coins, g.count, cfg);
    return { id, t: 'gift', user, gift: String(g.gift || '').slice(0, 40), count: n, coins: g.coins || 0, pts, real, ts: Date.now(), ...periodKeys() };
  },
  adjust: (id, user, delta, reason = '') => ({ id, t: 'adjust', user, delta, reason: String(reason).slice(0, 80), ts: Date.now(), ...periodKeys() }),
  reset: (id, scope) => ({ id, t: 'reset', scope, ts: Date.now(), ...periodKeys() }),
  config: (id, config) => ({ id, t: 'config', config, ts: Date.now(), ...periodKeys() }),
  purge: (id) => ({ id, t: 'purge', ts: Date.now(), ...periodKeys() }),
};
