// Integração do ranking de espectadores: liga o jogo, o painel, o armazenamento local e o servidor.
//  - Eventos do jogo (entrar, eliminar, vencer, presentes) viram "ops" com id único (ver viewers.js).
//  - Cada op é aplicada localmente (salva em localStorage) e enviada ao servidor, que grava em arquivo.
//  - Ao conectar, a página busca o estado do servidor e reaplica o que ainda não foi confirmado.
import { ViewerStore, ops, keyOf, LEVELS } from './viewers.js';

const KEY = 'survivalLive.viewers.v1';
const PKEY = 'survivalLive.viewersPending.v1.';
const PENDING_MAX = 1500;
const isRealSrc = (s) => s === 'tiktok' || s === 'api'; // 'sim' (painel/demonstração) nunca é "real"

export class RankingSystem {
  constructor({ link = null, role = 'game', storage, fetchFn, base } = {}) {
    this.link = link; this.role = role;
    this.storage = storage !== undefined ? storage : (globalThis.localStorage || null);
    this.fetchFn = fetchFn !== undefined ? fetchFn : (globalThis.fetch ? globalThis.fetch.bind(globalThis) : null);
    this.base = base !== undefined ? base : (globalThis.location && /^https?:/.test(globalThis.location.protocol) ? globalThis.location.origin : '');
    this.sid = Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
    this.seq = 0; this.hint = null; this.game = null;
    this.serverOk = false; this.lastSync = 0;
    this.listeners = {};
    this.lvCache = new Map();
    this.saveT = null;
    this.pending = this._read(PKEY + role, []);
    this.store = new ViewerStore(this._read(KEY, null));
    this.store.on('change', () => { this.lvCache.clear(); this._schedule(); this.emit('change'); });
    this.store.on('levelup', (e) => this.emit('levelup', e));
    if (link) {
      link.onMessage((m) => this._onLink(m));
      link.onStatus((s) => { if (s === 'connected') this.sync(); else this.serverOk = false; this.emit('status'); });
    }
    if (typeof addEventListener === 'function') { addEventListener('pagehide', () => this.flush()); addEventListener('beforeunload', () => this.flush()); }
  }
  on(evt, fn) { (this.listeners[evt] ||= []).push(fn); }
  emit(evt, d) { const l = this.listeners[evt]; if (l) for (const fn of l) { try { fn(d); } catch (e) { console.error('[ranking]', e); } } }

  // ----- armazenamento local -----
  _read(k, def) { try { const r = this.storage && this.storage.getItem(k); return r ? JSON.parse(r) : def; } catch { return def; } }
  _write(k, v) { try { this.storage && this.storage.setItem(k, JSON.stringify(v)); } catch { /* cota cheia / bloqueado */ } }
  _schedule() { if (this.saveT) return; this.saveT = setTimeout(() => this.flush(), 400); }
  flush() {
    clearTimeout(this.saveT); this.saveT = null;
    this._write(KEY, this.store.snapshot());
    this._write(PKEY + this.role, this.pending);
  }
  get mode() { return this.serverOk ? 'server' : 'local'; }

  // ----- ops -----
  /** aplica localmente e propaga (servidor + outras janelas) */
  submit(op) {
    const r = this.store.apply(op);
    if (r !== 'applied') return r;
    this.pending.push(op);
    if (this.pending.length > PENDING_MAX) this.pending.splice(0, this.pending.length - PENDING_MAX);
    if (this.link) this.link.send({ type: 'rank.op', op });
    return r;
  }
  _onLink(m) {
    if (m.type === 'rank.op') this.store.apply(m.op);
    else if (m.type === 'rank.ack' && Array.isArray(m.ids)) {
      const done = new Set(m.ids);
      this.pending = this.pending.filter((o) => !done.has(o.id));
      this._schedule();
    }
  }
  newId(p) { return `${p}:${this.sid}:${++this.seq}`; }

  // ----- sincronização com o servidor -----
  async sync() {
    if (!this.fetchFn || !this.base) return false;
    try {
      const r = await this.fetchFn(this.base + '/api/ranking');
      if (!r.ok) throw new Error('http ' + r.status);
      const { state } = await r.json();
      if (state && state.rev > 0) {
        this.store.load(state);
        for (const op of this.pending) this.store.apply(op); // o que o servidor ainda não tinha
        this.lvCache.clear();
      } else if (this.store.rev > 0) {
        // servidor vazio e já existe ranking local: envia o local como ponto de partida
        await this.fetchFn(this.base + '/api/ranking', { method: 'PUT', headers: { 'content-type': 'application/json', 'x-token': this._token() }, body: JSON.stringify({ state: this.store.snapshot() }) }).catch(() => {});
      }
      if (this.link) for (const op of this.pending) this.link.send({ type: 'rank.op', op });
      this.serverOk = true; this.lastSync = Date.now();
      this._schedule(); this.emit('change'); this.emit('status');
      return true;
    } catch { this.serverOk = false; this.emit('status'); return false; }
  }
  _token() { try { return (this.storage && this.storage.getItem('survivalLive.token')) || ''; } catch { return ''; } }

  // ----- níveis / emblemas -----
  levelOfKey(key) {
    let v = this.lvCache.get(key);
    if (v === undefined) { const p = this.store.state.profiles[key]; v = p ? this.store.levelOfProfile(p) : null; this.lvCache.set(key, v); }
    return v;
  }
  /** emblema mostrado ao lado do nome na arena (Prata ou acima) */
  badgeOf(key) { const l = this.levelOfKey(key); return l && l.index >= 1 ? l : null; }

  // ----- ligação com o jogo -----
  isReal(key) {
    if (this.hint && this.hint.key === key) return this.hint.real;
    const p = this.store.state.profiles[key]; return !!(p && p.real);
  }
  attachGame(game) {
    this.game = game; game.ranking = this;
    const rid = () => `${this.sid}.${game.round}`;
    const touch = (name) => { const k = keyOf(name); if (k) this.submit(ops.join(`j:${rid()}:${k}`, name, this.isReal(k))); };
    game.on('join', (j) => { if (!j.bot) touch(j.name); });
    game.on('queued', (q) => touch(q.name));
    game.on('phase', (p) => { if (p.phase === 'lobby') for (const f of game.fighters) if (!f.bot) touch(f.name); });
    game.on('kill', (k) => {
      if (!k.killer) return;
      const killer = game.findFighter(k.killer), victim = game.findFighter(k.victim);
      if (!killer || killer.bot || !victim) return;
      if (victim.bot && !this.store.config.botKills) return;
      this.submit(ops.kill(`k:${rid()}:${victim.id}`, killer.name, rid(), this.store.config, this.isReal(killer.id)));
    });
    game.on('winner', () => {
      const w = game.winner, r = rid();
      for (const f of game.fighters) {
        if (f.bot || f.deathCause === 'removed') continue; // removido pelo streamer não conta como partida concluída
        this.submit(ops.match(`m:${r}:${f.id}`, f.name, { rid: r, round: game.round, won: f === w, place: f === w ? 1 : f.placement, kills: f.kills }, this.store.config, this.isReal(f.id)));
      }
    });
  }
  /** chamado pela ponte ANTES de repassar o comentário ao jogo, para saber se a origem é real */
  withChat(m, run) {
    this.hint = { key: keyOf(m.user), real: isRealSrc(m.src) };
    try { return run(); } finally { this.hint = null; }
  }
  /** presente recebido (a pontuação vai para quem enviou) */
  onGift(m) {
    if (!keyOf(m.user)) return;
    const id = m.eid || m._id || this.newId('g');
    // só conta como presente "real" se veio do servidor/TikTok (nunca de simulação do painel)
    this.submit(ops.gift(`g:${id}`, m.user, { gift: m.gift, count: m.count || 1, coins: m.coins || 0 }, this.store.config, isRealSrc(m.src)));
  }

  // ----- ações do painel -----
  adjust(user, delta, reason) { return this.submit(ops.adjust(this.newId('a'), user, delta, reason)); }
  reset(scope) { return this.submit(ops.reset(this.newId('r'), scope)); }
  setConfig(cfg) { return this.submit(ops.config(this.newId('c'), cfg)); }
  purgeSim() { return this.submit(ops.purge(this.newId('p'))); }
}

export { LEVELS, keyOf };
