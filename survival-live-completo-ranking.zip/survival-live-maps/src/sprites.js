// Sprites pré-renderizados (árvores, pedras, casas, montanhas) e chão do mapa.
// Tudo é parametrizado pelo tema do mapa (src/maps.js); sem tema = Floresta (visual original).
import { mulberry32, TAU } from './utils.js';
import { PLAZA, MAP_W, MAP_H } from './map.js';
import { MAPS } from './maps.js';

const mk = (w, h, fn) => {
  const c = document.createElement('canvas');
  c.width = Math.ceil(w); c.height = Math.ceil(h);
  fn(c.getContext('2d'), c.width, c.height);
  return c;
};
const radial = (x, cx, cy, r, c0, c1) => { const g = x.createRadialGradient(cx - r * 0.3, cy - r * 0.3, r * 0.1, cx, cy, r); g.addColorStop(0, c0); g.addColorStop(1, c1); return g; };
const clear = (c) => c.replace(/[\d.]+\)$/, '0)'); // mesma cor, alfa 0
const V = (theme) => (theme || MAPS.forest).visual;
const shadow = (x, cx, cy, rx, ry) => { x.fillStyle = 'rgba(0,0,0,0.28)'; x.beginPath(); x.ellipse(cx, cy, rx, ry, 0, 0, TAU); x.fill(); };

// ---------------------------------------------------------------- árvores
function forestTrees() {
  const oak = (hi, lo, hi2) => mk(128, 150, (x) => {
    shadow(x, 76, 128, 40, 13);
    x.fillStyle = '#5b3a1e'; x.fillRect(57, 92, 14, 38); x.fillStyle = '#7a5230'; x.fillRect(57, 92, 5, 38);
    for (const [cx, cy, r] of [[64, 58, 40], [38, 78, 28], [90, 78, 28], [64, 86, 30]]) {
      x.fillStyle = radial(x, cx, cy, r, hi, lo); x.beginPath(); x.arc(cx, cy, r, 0, TAU); x.fill();
    }
    x.fillStyle = hi2;
    for (const [cx, cy, r] of [[52, 46, 12], [76, 54, 9], [34, 70, 8], [60, 76, 7]]) { x.beginPath(); x.arc(cx, cy, r, 0, TAU); x.fill(); }
  });
  const pine = mk(128, 150, (x) => {
    shadow(x, 76, 128, 36, 12);
    x.fillStyle = '#5b3a1e'; x.fillRect(59, 108, 10, 22);
    for (let i = 0; i < 4; i++) {
      const by = 118 - i * 26, hw = 44 - i * 9;
      x.fillStyle = '#1f6b3a'; x.beginPath(); x.moveTo(64 - hw, by); x.lineTo(64 + hw, by); x.lineTo(64, by - 46); x.closePath(); x.fill();
      x.fillStyle = '#2f8f4c'; x.beginPath(); x.moveTo(64 - hw, by); x.lineTo(64, by - 46); x.lineTo(64 - hw * 0.1, by); x.closePath(); x.fill();
    }
  });
  return [oak('#6fc258', '#2f7a34', '#8fe070'), pine, oak('#f0b24a', '#c0561f', '#ffd98a')];
}

function desertTrees() {
  const green = (x, x0, x1) => { const g = x.createLinearGradient(x0, 0, x1, 0); g.addColorStop(0, '#2f7a3a'); g.addColorStop(0.45, '#5cb04a'); g.addColorStop(1, '#2a6a34'); return g; };
  const saguaro = (flip) => mk(128, 150, (x) => {
    shadow(x, 76, 128, 30, 10);
    // braços (em "L")
    x.fillStyle = green(x, 36, 52);
    const arm = (sx, sy, h) => { x.beginPath(); x.roundRect(sx, sy, 12, 16, 6); x.fill(); x.beginPath(); x.roundRect(sx, sy - h, 12, h + 8, 6); x.fill(); };
    x.fillStyle = green(x, 36, 52); x.beginPath(); x.roundRect(flip ? 80 : 36, 78, 14, 14, 6); x.fill();
    if (flip) { x.beginPath(); x.roundRect(46, 70, 40, 14, 7); x.fill(); } else { x.beginPath(); x.roundRect(36, 70, 40, 14, 7); x.fill(); }
    x.beginPath(); x.roundRect(flip ? 80 : 36, 44, 14, 44, 7); x.fill();
    x.fillStyle = green(x, 54, 76); x.beginPath(); x.roundRect(54, 24, 22, 108, 11); x.fill();
    x.fillStyle = flip ? green(x, 90, 104) : green(x, 24, 36); x.beginPath(); x.roundRect(flip ? 84 : 26, 52, 14, 34, 7); x.fill();
    x.strokeStyle = 'rgba(20,60,25,0.55)'; x.lineWidth = 1.5;
    for (const dx of [60, 65, 70]) { x.beginPath(); x.moveTo(dx, 32); x.lineTo(dx, 124); x.stroke(); }
    x.fillStyle = '#ff8fb3'; x.beginPath(); x.arc(65, 24, 4, 0, TAU); x.fill();
    x.fillStyle = '#ffe36a'; x.beginPath(); x.arc(65, 24, 1.8, 0, TAU); x.fill();
  });
  const palm = mk(128, 150, (x) => {
    shadow(x, 78, 130, 36, 11);
    x.strokeStyle = '#7a5230'; x.lineWidth = 9; x.lineCap = 'round';
    x.beginPath(); x.moveTo(62, 130); x.quadraticCurveTo(70, 90, 64, 52); x.stroke();
    x.strokeStyle = '#5b3a1e'; x.lineWidth = 2;
    for (let y = 120; y > 60; y -= 10) { x.beginPath(); x.moveTo(58, y); x.lineTo(70, y - 3); x.stroke(); }
    const frond = (a, len, col) => {
      x.save(); x.translate(64, 52); x.rotate(a);
      x.fillStyle = col; x.beginPath(); x.moveTo(0, 0); x.quadraticCurveTo(len * 0.5, -len * 0.38, len, len * 0.18); x.quadraticCurveTo(len * 0.5, -len * 0.08, 0, 0); x.fill();
      x.restore();
    };
    for (let i = 0; i < 8; i++) frond((i / 8) * TAU + 0.2, 46 + (i % 2) * 8, i % 2 ? '#3f9a4a' : '#5cb85a');
    x.fillStyle = '#8a5a2a'; x.beginPath(); x.arc(61, 56, 3.4, 0, TAU); x.arc(68, 57, 3.4, 0, TAU); x.fill();
  });
  return [saguaro(false), saguaro(true), palm];
}

function snowTrees() {
  const pine = (cols, w, tiers) => mk(128, 150, (x) => {
    shadow(x, 76, 128, 36, 12);
    x.fillStyle = '#4a3322'; x.fillRect(59, 108, 10, 22);
    for (let i = 0; i < tiers; i++) {
      const by = 120 - i * (96 / tiers), hw = w - i * (w / (tiers + 0.6)), th = 40 + 4;
      x.fillStyle = cols[0]; x.beginPath(); x.moveTo(64 - hw, by); x.lineTo(64 + hw, by); x.lineTo(64, by - th); x.closePath(); x.fill();
      x.fillStyle = cols[1]; x.beginPath(); x.moveTo(64 - hw, by); x.lineTo(64, by - th); x.lineTo(64 - hw * 0.1, by); x.closePath(); x.fill();
      // neve acumulada
      x.fillStyle = '#f4f9ff'; x.beginPath(); x.moveTo(64 - hw * 0.62, by - th * 0.38); x.lineTo(64, by - th); x.lineTo(64 + hw * 0.62, by - th * 0.38);
      x.quadraticCurveTo(64 + hw * 0.3, by - th * 0.22, 64 + hw * 0.12, by - th * 0.42); x.quadraticCurveTo(64 - hw * 0.1, by - th * 0.2, 64 - hw * 0.35, by - th * 0.4); x.quadraticCurveTo(64 - hw * 0.5, by - th * 0.3, 64 - hw * 0.62, by - th * 0.38); x.fill();
      x.fillStyle = 'rgba(160,190,225,0.5)'; x.beginPath(); x.ellipse(64 + hw * 0.1, by - th * 0.36, hw * 0.28, 3, 0, 0, TAU); x.fill();
    }
  });
  const bare = mk(128, 150, (x) => {
    shadow(x, 76, 128, 34, 11);
    x.strokeStyle = '#4a3a30'; x.lineCap = 'round'; x.lineWidth = 9; x.beginPath(); x.moveTo(64, 130); x.lineTo(64, 70); x.stroke();
    x.lineWidth = 5;
    for (const [a, l, y] of [[-0.9, 40, 94], [0.9, 42, 86], [-0.6, 34, 70], [0.6, 36, 62], [-0.2, 28, 48], [0.25, 26, 42]]) {
      x.beginPath(); x.moveTo(64, y); x.lineTo(64 + Math.sin(a) * l, y - Math.cos(a) * l * 0.9); x.stroke();
    }
    x.fillStyle = '#f4f9ff';
    for (const [px, py, w] of [[28, 60, 16], [100, 52, 16], [38, 36, 12], [92, 32, 12], [64, 24, 14], [56, 92, 10], [76, 86, 10]]) { x.beginPath(); x.ellipse(px, py, w / 2, 4.5, 0, 0, TAU); x.fill(); }
  });
  return [pine(['#2a5d4a', '#3f7a63'], 40, 4), pine(['#24524a', '#37705f'], 46, 3), bare];
}

export function makeTrees(theme) {
  const k = V(theme).trees;
  return k === 'desert' ? desertTrees() : k === 'snow' ? snowTrees() : forestTrees();
}

// ---------------------------------------------------------------- pedras
export function makeRocks(theme) {
  const R = V(theme).rock;
  return [0, 1, 2].map((v) => mk(96, 84, (x) => {
    const rng = mulberry32(v * 77 + 3);
    x.fillStyle = 'rgba(0,0,0,0.3)'; x.beginPath(); x.ellipse(52, 66, 38, 12, 0, 0, TAU); x.fill();
    const pts = []; const n = 9;
    for (let i = 0; i < n; i++) { const a = (i / n) * TAU, r = 28 + rng() * 14; pts.push([48 + Math.cos(a) * r, 46 + Math.sin(a) * r * 0.78]); }
    x.beginPath(); pts.forEach(([px, py], i) => (i ? x.lineTo(px, py) : x.moveTo(px, py))); x.closePath();
    const g = x.createLinearGradient(20, 10, 76, 78); g.addColorStop(0, R.c0); g.addColorStop(1, R.c1);
    x.fillStyle = g; x.fill(); x.strokeStyle = R.line; x.lineWidth = 2; x.stroke();
    x.fillStyle = 'rgba(255,255,255,0.28)'; x.beginPath(); x.moveTo(pts[0][0], pts[0][1]); x.lineTo(pts[1][0], pts[1][1]); x.lineTo(48, 40); x.lineTo(pts[8][0], pts[8][1]); x.closePath(); x.fill();
    x.strokeStyle = 'rgba(40,40,50,0.5)'; x.beginPath(); x.moveTo(40, 36); x.lineTo(52, 50); x.lineTo(48, 64); x.stroke();
    if (R.cap) { x.fillStyle = '#f7fbff'; x.beginPath(); x.ellipse(46, 34, 24, 11, -0.1, 0, TAU); x.fill(); x.fillStyle = 'rgba(160,190,225,0.55)'; x.beginPath(); x.ellipse(52, 37, 14, 5, -0.1, 0, TAU); x.fill(); }
  }));
}

// ---------------------------------------------------------------- casas
export function makeHouse(w, h, v, theme) {
  const H = V(theme).house;
  return mk(w + 34, h + 50, (x) => {
    const ox = 17, oy = 30;
    x.fillStyle = 'rgba(0,0,0,0.28)'; x.fillRect(ox + 8, oy + 12, w, h);
    // parede frontal
    const wh = 28;
    x.fillStyle = H.wall; x.fillRect(ox, oy + h - wh, w, wh);
    x.strokeStyle = 'rgba(0,0,0,0.25)'; x.lineWidth = 1;
    for (let i = ox + 8; i < ox + w; i += 9) { x.beginPath(); x.moveTo(i, oy + h - wh); x.lineTo(i, oy + h); x.stroke(); }
    x.fillStyle = '#2c2016'; x.fillRect(ox + w / 2 - 11, oy + h - 22, 22, 22);
    x.fillStyle = '#d9b45a'; x.fillRect(ox + 12, oy + h - 20, 14, 11); x.fillRect(ox + w - 26, oy + h - 20, 14, 11);
    x.strokeStyle = '#2c2016'; x.lineWidth = 2; x.strokeRect(ox + 12, oy + h - 20, 14, 11); x.strokeRect(ox + w - 26, oy + h - 20, 14, 11);
    // telhado
    const [c0, c1, c2] = H.roofs[v % 3];
    x.fillStyle = c0; x.beginPath(); x.moveTo(ox - 9, oy + h - wh + 4); x.lineTo(ox + w + 9, oy + h - wh + 4); x.lineTo(ox + w - 6, oy - 12); x.lineTo(ox + 6, oy - 12); x.closePath(); x.fill();
    x.save(); x.clip();
    x.strokeStyle = c2; x.lineWidth = 1.5;
    for (let yy = oy - 8; yy < oy + h; yy += 9) { x.beginPath(); x.moveTo(ox - 10, yy); x.lineTo(ox + w + 10, yy); x.stroke(); }
    x.fillStyle = c1; x.fillRect(ox + w / 2 - 3, oy - 14, 6, h);
    const rng = mulberry32(w * 13 + h * 7 + v);
    x.fillStyle = '#1b130e';
    for (let i = 0; i < H.holes; i++) { const px = ox + 14 + rng() * (w - 40), py = oy + rng() * (h - 50); x.beginPath(); x.moveTo(px, py); x.lineTo(px + 14, py + 3); x.lineTo(px + 10, py + 15); x.lineTo(px - 2, py + 9); x.closePath(); x.fill(); }
    if (H.moss) { x.fillStyle = H.moss; x.beginPath(); x.ellipse(ox + w * 0.25, oy + h * 0.3, 14, 8, 0.3, 0, TAU); x.fill(); }
    if (H.snow) { // manta de neve no telhado
      x.fillStyle = 'rgba(255,255,255,0.92)'; x.beginPath(); x.moveTo(ox - 12, oy + h * 0.55); x.quadraticCurveTo(ox + w * 0.25, oy + h * 0.42, ox + w * 0.5, oy + h * 0.5); x.quadraticCurveTo(ox + w * 0.78, oy + h * 0.38, ox + w + 12, oy + h * 0.52);
      x.lineTo(ox + w + 12, oy - 14); x.lineTo(ox - 12, oy - 14); x.closePath(); x.fill();
      x.fillStyle = 'rgba(160,190,225,0.5)'; x.beginPath(); x.ellipse(ox + w * 0.5, oy + h * 0.2, w * 0.3, 5, 0, 0, TAU); x.fill();
    } else { x.fillStyle = '#7a5a36'; x.fillRect(ox + w * 0.55, oy + 8, 40, 5); x.fillRect(ox + w * 0.58, oy + 20, 36, 5); }
    x.restore();
    x.fillStyle = '#6b6f76'; x.fillRect(ox + w * 0.72, oy - 22, 14, 14); x.fillStyle = '#26282c'; x.fillRect(ox + w * 0.72 + 3, oy - 20, 8, 6);
    if (H.snow) { x.fillStyle = '#fff'; x.fillRect(ox + w * 0.72 - 1, oy - 25, 16, 5); }
  });
}

// ---------------------------------------------------------------- montanhas
export function makeMountain(vr, v, theme) {
  const M = V(theme).mountain;
  const S = Math.ceil(vr * 2.5);
  return mk(S, S, (x) => {
    const rng = mulberry32(Math.floor(vr) * 31 + v * 7);
    const cx = S / 2, cy = S / 2;
    x.fillStyle = 'rgba(0,0,0,0.28)'; x.beginPath(); x.ellipse(cx + 14, cy + 18, vr * 1.05, vr * 0.95, 0, 0, TAU); x.fill();
    const n = 20, pts = [];
    for (let i = 0; i < n; i++) { const a = (i / n) * TAU, r = vr * (0.88 + rng() * 0.2); pts.push([cx + Math.cos(a) * r, cy + Math.sin(a) * r * 0.92]); }
    x.beginPath(); pts.forEach(([px, py], i) => (i ? x.lineTo(px, py) : x.moveTo(px, py))); x.closePath();
    const g = x.createRadialGradient(cx - vr * 0.25, cy - vr * 0.3, vr * 0.1, cx, cy, vr * 1.05); g.addColorStop(0, M.g0); g.addColorStop(0.6, M.g1); g.addColorStop(1, M.g2);
    x.fillStyle = g; x.fill(); x.strokeStyle = M.stroke; x.lineWidth = 3; x.stroke();
    // cristas
    x.lineWidth = 2.5; x.strokeStyle = M.ridge;
    for (let i = 0; i < 9; i++) { const a = rng() * TAU, r1 = vr * 0.2, r2 = vr * (0.65 + rng() * 0.25); x.beginPath(); x.moveTo(cx + Math.cos(a) * r1, cy + Math.sin(a) * r1); x.lineTo(cx + Math.cos(a + 0.15) * (r1 + r2) / 2, cy + Math.sin(a + 0.15) * (r1 + r2) / 2); x.lineTo(cx + Math.cos(a) * r2, cy + Math.sin(a) * r2); x.stroke(); }
    x.fillStyle = 'rgba(255,255,255,0.12)';
    for (let i = 0; i < 6; i++) { const a = -2.3 + rng() * 1.3; x.beginPath(); x.moveTo(cx, cy); x.lineTo(cx + Math.cos(a) * vr * 0.85, cy + Math.sin(a) * vr * 0.85); x.lineTo(cx + Math.cos(a + 0.35) * vr * 0.8, cy + Math.sin(a + 0.35) * vr * 0.8); x.closePath(); x.fill(); }
    // topo (neve / arenito claro)
    const k = M.capScale;
    x.fillStyle = M.cap; x.beginPath();
    for (let i = 0; i < 12; i++) { const a = (i / 12) * TAU, r = vr * (0.26 + (i % 2) * 0.07 + rng() * 0.05) * k; const px = cx - vr * 0.05 + Math.cos(a) * r, py = cy - vr * 0.08 + Math.sin(a) * r * 0.9; i ? x.lineTo(px, py) : x.moveTo(px, py); }
    x.closePath(); x.fill();
    x.fillStyle = 'rgba(150,180,220,0.45)'; x.beginPath(); x.ellipse(cx + vr * 0.06, cy + vr * 0.02, vr * 0.12 * k, vr * 0.16 * k, 0.5, 0, TAU); x.fill();
  });
}

// ---------------------------------------------------------------- chão (escala 0.5)
export function makeGround(map) {
  const S = 0.5;
  const T = map.theme || MAPS.forest, Gd = T.visual.ground;
  const rng = mulberry32(map.seed ^ 0x9e3779b9);
  const R = (a, b) => a + rng() * (b - a);
  return mk(MAP_W * S, MAP_H * S, (x) => {
    x.scale(S, S);
    x.fillStyle = Gd.base; x.fillRect(0, 0, MAP_W, MAP_H);
    // manchas
    for (let i = 0; i < 650; i++) {
      const px = R(0, MAP_W), py = R(0, MAP_H), r = R(60, 220);
      const light = rng() < 0.5;
      const g = x.createRadialGradient(px, py, 0, px, py, r);
      g.addColorStop(0, light ? Gd.blotchLight : Gd.blotchDark); g.addColorStop(1, 'rgba(0,0,0,0)');
      x.fillStyle = g; x.fillRect(px - r, py - r, r * 2, r * 2);
    }
    // detalhes do solo: tufos de grama / ondulações de dunas / brilhos de neve
    x.lineWidth = 2; x.lineCap = 'round';
    for (let i = 0; i < 5000; i++) {
      const px = R(0, MAP_W), py = R(0, MAP_H);
      x.strokeStyle = rng() < 0.5 ? Gd.tuftA : Gd.tuftB;
      x.beginPath();
      if (Gd.tuft === 'ripple') { const l = R(10, 26); x.moveTo(px, py); x.quadraticCurveTo(px + l / 2, py - R(2, 5), px + l, py); }
      else if (Gd.tuft === 'sparkle') { const l = R(1.5, 3.2); x.moveTo(px - l, py); x.lineTo(px + l, py); x.moveTo(px, py - l); x.lineTo(px, py + l); }
      else { x.moveTo(px, py); x.lineTo(px + R(-3, 3), py - R(5, 11)); }
      x.stroke();
    }
    // trilhas
    x.lineCap = 'round'; x.lineJoin = 'round';
    for (const path of map.paths) {
      x.strokeStyle = Gd.path[0]; x.lineWidth = 54; x.beginPath(); path.forEach((p, i) => (i ? x.lineTo(p.x, p.y) : x.moveTo(p.x, p.y))); x.stroke();
      x.strokeStyle = Gd.path[1]; x.lineWidth = 38; x.beginPath(); path.forEach((p, i) => (i ? x.lineTo(p.x, p.y) : x.moveTo(p.x, p.y))); x.stroke();
    }
    // pátio das vilas
    for (const v of map.villages) {
      const g = x.createRadialGradient(v.x, v.y, 20, v.x, v.y, v.r + 40); g.addColorStop(0, Gd.yard); g.addColorStop(1, clear(Gd.yard));
      x.fillStyle = g; x.beginPath(); x.arc(v.x, v.y, v.r + 40, 0, TAU); x.fill();
    }
    // rio
    const rp = map.riverPath;
    if (rp.length) {
      [[Gd.river[0], 150], [Gd.river[1], 112], [Gd.river[2], 86]].forEach(([col, w]) => {
        x.strokeStyle = col; x.lineWidth = w; x.beginPath(); rp.forEach((p, i) => (i ? x.lineTo(p.x, p.y) : x.moveTo(p.x, p.y))); x.stroke();
      });
      x.strokeStyle = Gd.riverHl; x.lineWidth = 3; x.setLineDash([20, 40]);
      x.beginPath(); rp.forEach((p, i) => (i ? x.lineTo(p.x + 12, p.y) : x.moveTo(p.x + 12, p.y))); x.stroke(); x.setLineDash([]);
    }
    // lagos
    for (const l of map.lakes) {
      x.fillStyle = Gd.lake.rim; x.beginPath(); x.ellipse(l.x, l.y, l.rx + 22, l.ry + 22, 0, 0, TAU); x.fill();
      const g = x.createRadialGradient(l.x - l.rx * 0.2, l.y - l.ry * 0.2, 10, l.x, l.y, Math.max(l.rx, l.ry));
      g.addColorStop(0, Gd.lake.g[0]); g.addColorStop(0.7, Gd.lake.g[1]); g.addColorStop(1, Gd.lake.g[2]);
      x.fillStyle = g; x.beginPath(); x.ellipse(l.x, l.y, l.rx, l.ry, 0, 0, TAU); x.fill();
      x.strokeStyle = Gd.lake.arcs; x.lineWidth = 3;
      for (let i = 0; i < 6; i++) { const a = R(0, TAU), d = R(0.2, 0.7); x.beginPath(); x.arc(l.x + Math.cos(a) * l.rx * d, l.y + Math.sin(a) * l.ry * d, R(14, 34), 0.2, 1.6); x.stroke(); }
    }
    // áreas perigosas (pântano / areia movediça / fenda de gelo)
    for (const s of map.swamps) {
      const g = x.createRadialGradient(s.x, s.y, s.r * 0.2, s.x, s.y, s.r * 1.1);
      g.addColorStop(0, Gd.swamp.g[0]); g.addColorStop(0.6, Gd.swamp.g[1]); g.addColorStop(1, Gd.swamp.g[2]);
      x.fillStyle = g; x.beginPath(); x.arc(s.x, s.y, s.r * 1.1, 0, TAU); x.fill();
      for (let i = 0; i < 26; i++) { const a = R(0, TAU), d = Math.sqrt(rng()) * s.r * 0.9; x.fillStyle = rng() < 0.5 ? Gd.swamp.dots[0] : Gd.swamp.dots[1]; x.beginPath(); x.arc(s.x + Math.cos(a) * d, s.y + Math.sin(a) * d, R(3, 9), 0, TAU); x.fill(); }
    }
    // praça central
    const pg = x.createRadialGradient(PLAZA.x, PLAZA.y, 20, PLAZA.x, PLAZA.y, PLAZA.r);
    pg.addColorStop(0, Gd.plaza.g[0]); pg.addColorStop(0.8, Gd.plaza.g[1]); pg.addColorStop(1, Gd.plaza.g[2]);
    x.fillStyle = pg; x.beginPath(); x.arc(PLAZA.x, PLAZA.y, PLAZA.r, 0, TAU); x.fill();
    x.strokeStyle = Gd.plaza.line; x.lineWidth = 6;
    x.beginPath(); x.arc(PLAZA.x, PLAZA.y, 120, 0, TAU); x.stroke(); x.beginPath(); x.arc(PLAZA.x, PLAZA.y, 250, 0, TAU); x.stroke();
    // flores / pedrinhas / cristais de gelo
    for (let i = 0; i < Gd.decoN; i++) {
      const px = R(60, MAP_W - 60), py = R(60, MAP_H - 60);
      x.fillStyle = Gd.deco[(rng() * Gd.deco.length) | 0];
      x.beginPath(); x.arc(px, py, R(2, 3.6), 0, TAU); x.fill();
    }
    // borda do mundo
    const e = Gd.edge;
    const eg = (x0, y0, x1, y1) => { const g = x.createLinearGradient(x0, y0, x1, y1); g.addColorStop(0, e); g.addColorStop(1, clear(e)); return g; };
    x.fillStyle = eg(0, 0, 120, 0); x.fillRect(0, 0, 120, MAP_H);
    x.fillStyle = eg(MAP_W, 0, MAP_W - 120, 0); x.fillRect(MAP_W - 120, 0, 120, MAP_H);
    x.fillStyle = eg(0, 0, 0, 120); x.fillRect(0, 0, MAP_W, 120);
    x.fillStyle = eg(0, MAP_H, 0, MAP_H - 120); x.fillRect(0, MAP_H - 120, MAP_W, 120);
  });
}
