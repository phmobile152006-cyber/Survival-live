// Itens de cura/escudo/energia, armas no chão e caixas de suprimentos (sem DOM)
import { rand, pick, TAU } from './utils.js';
import { WEAPONS, BASIC_WEAPONS, SPECIAL_WEAPONS } from './combat.js';

export const ITEM_TYPES = {
  medkit: { label: 'Kit Médico', color: '#ff4d6d', heal: 45, weight: 3 },
  bandage: { label: 'Bandagem', color: '#f2f2f2', heal: 18, weight: 6 },
  energy: { label: 'Energético', color: '#4dd2ff', energy: 60, weight: 5 },
  shield: { label: 'Escudo', color: '#6aa8ff', shield: 35, weight: 3 },
  weapon: { label: 'Arma', color: '#ffd166', weight: 4 },
};

let nextId = 1;

export class Items {
  constructor(game) { this.game = game; this.list = []; this.crates = []; this.spawnT = 0; }
  clear() { this.list.length = 0; this.crates.length = 0; this.spawnT = 8; }

  add(type, x, y, extra = {}) {
    const it = { id: nextId++, type, x, y, r: 12, t: 0, bob: rand(TAU), weapon: extra.weapon || null, cd: extra.cd || 0 };
    this.list.push(it);
    return it;
  }
  addRandom(x, y) {
    const types = Object.keys(ITEM_TYPES);
    const total = types.reduce((s, k) => s + ITEM_TYPES[k].weight, 0);
    let r = rand(total), type = 'bandage';
    for (const k of types) { r -= ITEM_TYPES[k].weight; if (r <= 0) { type = k; break; } }
    if (type === 'weapon') return this.add('weapon', x, y, { weapon: Math.random() < 0.18 ? pick(SPECIAL_WEAPONS) : pick(BASIC_WEAPONS) });
    return this.add(type, x, y);
  }
  spawnInitial() {
    const g = this.game, m = g.map;
    const n = Math.round(g.settings.get('maxPlayers') * 1.6 + 14);
    for (let i = 0; i < n; i++) {
      const spot = m.lootSpots[(Math.random() * m.lootSpots.length) | 0] || m.randomFree(Math.random, null, 30);
      const p = m.solidAt(spot.x, spot.y, 14) ? m.randomFree(Math.random, null, 30) : { x: spot.x + rand(-30, 30), y: spot.y + rand(-20, 20) };
      this.addRandom(p.x, p.y);
    }
    const nc = 3 + Math.floor(g.settings.get('maxPlayers') / 10);
    for (let i = 0; i < nc; i++) this.spawnCrate();
  }
  spawnCrate(region, golden = false) {
    const g = this.game;
    const rr = region || { x: g.zone.cx, y: g.zone.cy, r: Math.max(100, g.zone.r * 0.85) };
    const p = g.map.randomFree(Math.random, rr, 40);
    const c = { x: p.x, y: p.y, r: 22, golden, t: 0, opened: false };
    this.crates.push(c);
    return c;
  }
  openCrate(c, by) {
    const g = this.game;
    c.opened = true;
    g.fx.burst(c.x, c.y, 18, { speed: 160, life: 0.7, size: 4, color: ['#ffd166', '#fff3b0', '#c98b3a'] });
    g.fx.ring(c.x, c.y, 8, 60, 0.4, '#ffd166', 4);
    g.audio?.('crate', c);
    const n = c.golden ? 5 : 3;
    for (let i = 0; i < n; i++) {
      const a = (i / n) * TAU + rand(0.4), d = rand(26, 52);
      const x = c.x + Math.cos(a) * d, y = c.y + Math.sin(a) * d;
      if (i === 0 && (c.golden || Math.random() < 0.75)) this.add('weapon', x, y, { weapon: pick(SPECIAL_WEAPONS) });
      else if (i === 1) this.add('medkit', x, y);
      else if (i === 2) this.add('shield', x, y);
      else this.addRandom(x, y);
    }
    g.emit('crate', { by });
  }
  update(dt) {
    const g = this.game;
    for (const it of this.list) { it.t += dt; if (it.cd > 0) it.cd -= dt; }
    for (const c of this.crates) c.t += dt;
    // reposição lenta de itens
    this.spawnT -= dt;
    if (this.spawnT <= 0 && this.list.length < 70) {
      this.spawnT = rand(5, 9);
      const p = g.map.randomFree(Math.random, { x: g.zone.cx, y: g.zone.cy, r: Math.max(80, g.zone.r * 0.9) }, 30);
      this.addRandom(p.x, p.y);
    }
    // coleta
    for (const f of g.fighters) {
      if (!f.alive) continue;
      for (let i = this.list.length - 1; i >= 0; i--) {
        const it = this.list[i];
        if (it.cd > 0) continue;
        if ((it.x - f.x) ** 2 + (it.y - f.y) ** 2 > (f.r + it.r + 4) ** 2) continue;
        if (this.tryPickup(f, it)) this.list.splice(i, 1);
      }
      for (const c of this.crates) {
        if (!c.opened && (c.x - f.x) ** 2 + (c.y - f.y) ** 2 < (f.r + c.r + 4) ** 2) this.openCrate(c, f);
      }
    }
    for (let i = this.crates.length - 1; i >= 0; i--) if (this.crates[i].opened) this.crates.splice(i, 1);
    // itens fora da zona viram pó (evita lixo infinito)
    if (this.list.length > 90) this.list.splice(0, this.list.length - 90);
  }
  tryPickup(f, it) {
    const g = this.game;
    const T = ITEM_TYPES[it.type];
    let used = false, text = '';
    if (T.heal) { if (f.hp < f.maxHp - 3) { f.heal(T.heal); used = true; text = `+${T.heal} ❤`; } }
    else if (T.energy) { if (f.energy < f.maxEnergy - 5) { f.energy = Math.min(f.maxEnergy, f.energy + T.energy); used = true; text = `+${T.energy} ⚡`; } }
    else if (T.shield) { if (f.shield < 60) { f.addShield(T.shield, 20); used = true; text = `+${T.shield} 🛡`; } }
    else if (it.type === 'weapon') {
      const nw = WEAPONS[it.weapon], ow = WEAPONS[f.weapon];
      if (nw.score > ow.score || (nw.special && !ow.special)) {
        if (f.weapon !== it.weapon) this.add('weapon', f.x, f.y, { weapon: f.weapon, cd: 3 });
        f.weapon = it.weapon; used = true; text = nw.name;
      }
    }
    if (used) {
      g.fx.text(f.x, f.y - f.r - 14, text, T.color, 14);
      g.fx.burst(f.x, f.y, 6, { speed: 90, life: 0.4, size: 3, color: T.color });
      g.audio?.('pickup', f);
    }
    return used;
  }
  /** item mais próximo que ajuda f */
  nearest(f, range, filter) {
    let best = null, bd = range * range;
    for (const it of this.list) {
      if (it.cd > 0) continue;
      if (filter && !filter(it)) continue;
      const d = (it.x - f.x) ** 2 + (it.y - f.y) ** 2;
      if (d < bd) { bd = d; best = it; }
    }
    return best;
  }
  nearestCrate(f, range) {
    let best = null, bd = range * range;
    for (const c of this.crates) {
      const d = (c.x - f.x) ** 2 + (c.y - f.y) ** 2;
      if (d < bd) { bd = d; best = c; }
    }
    return best;
  }
}
