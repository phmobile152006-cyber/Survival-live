// Sistema de partículas e efeitos visuais (sem DOM; o renderer desenha)
import { rand, TAU } from './utils.js';

export class Effects {
  constructor() {
    this.parts = [];
    this.rings = [];
    this.texts = [];
    this.scorches = [];
    this.enabled = true;
    this.shake = 0;
    this.flash = 0; // relâmpago
    this.max = 650;
  }
  clear() { this.parts.length = 0; this.rings.length = 0; this.texts.length = 0; this.scorches.length = 0; this.shake = 0; this.flash = 0; }
  particle(x, y, o = {}) {
    if (!this.enabled || this.parts.length >= this.max) return;
    const life = o.life ?? 0.6;
    this.parts.push({
      x, y, vx: o.vx ?? 0, vy: o.vy ?? 0, life, max: life, size: o.size ?? 3, color: o.color ?? '#fff',
      grav: o.grav ?? 0, drag: o.drag ?? 0, kind: o.kind ?? 'dot', grow: o.grow ?? 0, rot: o.rot ?? 0,
    });
  }
  burst(x, y, n, o = {}) {
    if (!this.enabled) return;
    const sp = o.speed ?? 120;
    for (let i = 0; i < n; i++) {
      const a = rand(TAU), s = rand(sp * 0.3, sp);
      this.particle(x, y, {
        vx: Math.cos(a) * s, vy: Math.sin(a) * s, life: rand((o.life ?? 0.6) * 0.6, o.life ?? 0.6),
        size: rand((o.size ?? 3) * 0.6, o.size ?? 3), color: Array.isArray(o.color) ? o.color[(Math.random() * o.color.length) | 0] : (o.color ?? '#fff'),
        grav: o.grav ?? 0, drag: o.drag ?? 2, kind: o.kind ?? 'dot', grow: o.grow ?? 0,
      });
    }
  }
  ring(x, y, r0, r1, life = 0.5, color = '#fff', width = 4) {
    if (!this.enabled || this.rings.length > 60) return;
    this.rings.push({ x, y, r0, r1, life, max: life, color, width });
  }
  text(x, y, str, color = '#fff', size = 16) {
    if (this.texts.length > 80) this.texts.shift();
    this.texts.push({ x: x + rand(-8, 8), y, str: String(str), color, size, life: 0.9, max: 0.9 });
  }
  explosion(x, y, r = 70) {
    if (this.enabled) {
      this.rings.length < 60 && this.rings.push({ x, y, r0: 5, r1: r * 1.2, life: 0.45, max: 0.45, color: '#ffd27a', width: 6 });
      this.parts.length < this.max && this.parts.push({ x, y, vx: 0, vy: 0, life: 0.5, max: 0.5, size: r, color: '#ff9a2e', grav: 0, drag: 0, kind: 'fire', grow: 0, rot: 0 });
      this.burst(x, y, 22, { speed: r * 3, life: 0.8, size: 4, color: ['#ffdd55', '#ff8a2a', '#ff4d1a'], drag: 3 });
      this.burst(x, y, 10, { speed: r * 1.2, life: 1.3, size: 10, color: 'rgba(60,50,45,0.6)', kind: 'smoke', grow: 14, drag: 1.5 });
      this.shake = Math.max(this.shake, Math.min(14, r / 6));
    }
    if (this.scorches.length > 40) this.scorches.shift();
    this.scorches.push({ x, y, r: r * 0.7, life: 25, max: 25 });
  }
  update(dt) {
    const P = this.parts;
    for (let i = P.length - 1; i >= 0; i--) {
      const p = P[i];
      p.life -= dt;
      if (p.life <= 0) { P[i] = P[P.length - 1]; P.pop(); continue; }
      p.vy += p.grav * dt;
      if (p.drag) { const d = Math.max(0, 1 - p.drag * dt); p.vx *= d; p.vy *= d; }
      p.x += p.vx * dt; p.y += p.vy * dt;
      p.size += p.grow * dt;
    }
    for (let i = this.rings.length - 1; i >= 0; i--) if ((this.rings[i].life -= dt) <= 0) this.rings.splice(i, 1);
    for (let i = this.texts.length - 1; i >= 0; i--) {
      const t = this.texts[i];
      t.life -= dt; t.y -= 34 * dt;
      if (t.life <= 0) this.texts.splice(i, 1);
    }
    for (let i = this.scorches.length - 1; i >= 0; i--) if ((this.scorches[i].life -= dt) <= 0) this.scorches.splice(i, 1);
    this.shake = Math.max(0, this.shake - dt * 30);
    this.flash = Math.max(0, this.flash - dt * 3);
  }
}
