// Ponte entre eventos externos (servidor/WebSocket/painel) e o jogo.
// Nenhuma conexão com o TikTok é feita aqui: eventos reais chegam do servidor
// intermediário (server/tiktok-adapter.js) já normalizados.
import { settings } from './settings.js';

export class TikTokBridge {
  constructor(game, link) {
    this.game = game;
    this.link = link;
    this.status = { state: 'idle', message: 'Sem conexão com o TikTok (modo demonstração)' };
    this.stats = { chats: 0, gifts: 0 };
    this.onStatus = null;
    this.ranking = null; // RankingSystem (opcional): recebe origem real/simulada dos eventos
    link.onMessage((m) => this.handle(m));
  }
  handle(m) {
    const g = this.game;
    switch (m.type) {
      case 'chat': this.stats.chats++; if (this.ranking) this.ranking.withChat(m, () => g.onChat(m.user, m.text)); else g.onChat(m.user, m.text); break;
      case 'gift': this.stats.gifts++; if (this.ranking) this.ranking.onGift(m); g.onGift({ user: m.user, gift: m.gift, count: m.count || 1, coins: m.coins || 0, target: m.target || null }); break;
      case 'cmd': g.command(m); break;
      case 'settings': settings.patch(m.patch || {}); break;
      case 'hello': if (m.role === 'admin') this.sendState(); break;
      case 'tiktok.status': this.status = { state: m.state, message: m.message }; this.onStatus && this.onStatus(this.status); break;
      default: break;
    }
  }
  sendState() { this.link.send({ type: 'state', state: this.game.snapshot() }); }
}
