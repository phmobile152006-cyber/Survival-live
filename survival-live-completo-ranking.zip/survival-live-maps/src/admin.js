// Lógica do painel do streamer (admin.html)
import { Link } from './websocket.js';
import { settings, DEFAULTS, DEFAULT_GIFTS, GIFT_ACTIONS } from './settings.js';
import { fmtTime, normGift } from './utils.js';
import { MAPS, MAP_IDS } from './maps.js';
import { GameMap } from './map.js';
import { makeGround } from './sprites.js';
import { RankingSystem } from './ranking.js';
import { RankingPanel, profileHTML, download, fmt as fmtN } from './ranking-ui.js';
import { DEFAULT_SCORING, DEFAULT_LEVEL_MINS } from './viewers.js';

const $ = (id) => document.getElementById(id);
const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const token = localStorage.getItem('survivalLive.token') || '';
$('token').value = token;
const link = new Link({ role: 'admin', token });

function log(msg) {
  const d = document.createElement('div'); d.innerHTML = `<b>${new Date().toLocaleTimeString()}</b> ${msg}`;
  $('log').prepend(d); while ($('log').children.length > 80) $('log').lastChild.remove();
}
const cmd = (c) => link.send({ type: 'cmd', ...c });

// ---------- status ----------
let lastState = 0, state = null;
link.onStatus((s, n) => {
  const el = $('wsStatus');
  el.className = 'pill ' + (s === 'connected' ? 'on' : s === 'disconnected' ? 'off' : 'try');
  el.textContent = s === 'connected' ? 'servidor: conectado' : s === 'reconnecting' ? `servidor: reconectando (${n})` : s === 'connecting' ? 'servidor: conectando…' : 'servidor: local';
});
link.onMessage((m) => {
  if (m.type === 'state') { state = m.state; lastState = Date.now(); renderState(); }
  else if (m.type === 'tiktok.status') {
    const el = $('ttStatus'); el.className = 'pill ' + (m.state === 'connected' ? 'on' : m.state === 'connecting' ? 'try' : 'off');
    el.textContent = 'TikTok: ' + ({ connected: 'conectado', connecting: 'conectando', error: 'erro', idle: 'inativo', disconnected: 'desconectado' }[m.state] || m.state);
    $('ttMsg').textContent = m.message; log(`TikTok: ${esc(m.message)}`);
  } else if (m.type === 'error') log(`<span style="color:#ff4d6d">${esc(m.message)}</span>`);
  else if (m.type === 'chat' && m._from !== 'admin') log(`💬 <b>${esc(m.user)}</b>: ${esc(m.text)}`);
  else if (m.type === 'gift' && m._from !== 'admin') log(`🎁 <b>${esc(m.user)}</b> → ${esc(m.gift)} x${m.count || 1}`);
});
link.connect();
link.send({ type: 'hello', role: 'admin' });
setInterval(() => {
  const ok = Date.now() - lastState < 3500;
  const el = $('gameStatus'); el.className = 'pill ' + (ok ? 'on' : 'off'); el.textContent = ok ? 'jogo: conectado' : 'jogo: desconectado (abra index.html)';
  if (!ok) link.send({ type: 'hello', role: 'admin' });
}, 1500);

const PH = { lobby: 'Sala de espera', playing: 'Partida em andamento', ending: 'Fim da rodada' };
const BH = { aggressive: 'Agressivo', defensive: 'Defensivo', explorer: 'Explorador', strategic: 'Estratégico' };
function renderState() {
  const s = state; if (!s) return;
  $('live').innerHTML = `${PH[s.phase] || s.phase}${s.paused ? ' · ⏸ PAUSADO' : ''} · Rodada #${s.round}` +
    `<small>${s.alive} vivos de ${s.total} · ${s.queue} na fila · ${s.monsters} monstros · ` +
    (s.phase === 'playing' ? `tempo ${fmtTime(s.time)} · zona estágio ${s.zoneStage + 1} (raio ${s.zoneR})` : s.countdown !== null ? `início em ${s.countdown}s` : 'aguardando jogadores') +
    (s.events.length ? ` · eventos: ${s.events.join(', ')}` : '') + '</small>';
  const box = $('plistBox');
  box.innerHTML = s.players.length ? s.players.map((p) => `<div class="p ${p.alive ? '' : 'dead'}"><span><b>${esc(p.name)}</b> ${p.bot ? '🤖' : ''}</span><span>${BH[p.behavior]}</span><span>${p.alive ? `❤ ${p.hp} · ⚔ ${p.kills}` : `☠ ${p.placement}º`}</span><button data-remove="${esc(p.name)}">✕</button></div>`).join('') : '<div class="empty">Sem jogadores</div>';
  $('plist').innerHTML = s.players.filter((p) => p.alive).map((p) => `<option value="${esc(p.name)}">`).join('');
  $('btnPause').textContent = s.paused ? '▶ Retomar' : '⏸ Pausar';
}

// ---------- botões ----------
document.addEventListener('click', (e) => {
  const b = e.target.closest('button'); if (!b) return;
  if (b.dataset.cmd) { if (b.dataset.confirm && !confirm(b.dataset.confirm)) return; cmd({ cmd: b.dataset.cmd }); log(`Comando: ${b.textContent.trim()}`); }
  else if (b.dataset.event) { cmd({ cmd: 'event', name: b.dataset.event }); log(`Evento: ${b.textContent.trim()}`); }
  else if (b.dataset.camera) cmd({ cmd: 'camera', mode: b.dataset.camera });
  else if (b.dataset.remove) cmd({ cmd: 'remove', name: b.dataset.remove });
});
$('btnFollow').onclick = () => { const n = $('followName').value.trim(); cmd({ cmd: 'follow', name: n || null }); };
$('btnAddPlayer').onclick = () => { const n = $('newName').value.trim(); if (!n) return; cmd({ cmd: 'addPlayer', name: n, behavior: $('newBehavior').value || undefined }); $('newName').value = ''; log(`Adicionar jogador: ${esc(n)}`); };
$('newName').addEventListener('keydown', (e) => { if (e.key === 'Enter') $('btnAddPlayer').click(); });
$('btnAddBots').onclick = () => cmd({ cmd: 'addBot', n: Number($('botN').value) || 1 });
$('btnSummon').onclick = () => { cmd({ cmd: 'summon', kind: $('monKind').value, n: Number($('monN').value) || 1 }); log('Monstros invocados'); };

// simulação
const NAMES = ['luna', 'pedro_gamer', 'ana.clara', 'zeca', 'maria', 'joao10', 'kaka', 'lucas', 'bia', 'gabi', 'thiago', 'rafa', 'duda', 'leo', 'vini', 'carla', 'nando', 'tati', 'bruno', 'isa'];
const rndName = () => NAMES[Math.floor(Math.random() * NAMES.length)] + Math.floor(Math.random() * 900 + 100);
const sendChat = (user, text) => { link.send({ type: 'chat', user, text, src: 'sim' }); log(`💬 <b>${esc(user)}</b>: ${esc(text)}`); };
const sendGift = (user, gift, count = 1, target = null) => { link.send({ type: 'gift', user, gift, count, target, src: 'sim' }); log(`🎁 <b>${esc(user)}</b> → ${esc(gift)} x${count}`); };
$('btnChat').onclick = () => sendChat($('simUser').value.trim() || 'viewer', $('simText').value);
$('simText').addEventListener('keydown', (e) => { if (e.key === 'Enter') $('btnChat').click(); });
$('btnJoinRandom').onclick = () => sendChat(rndName(), Math.random() < 0.5 ? '!entrar' : '!join');
$('btnJoin10').onclick = () => { for (let i = 0; i < 10; i++) setTimeout(() => sendChat(rndName(), '!entrar'), i * 120); };
$('btnGift').onclick = () => { const u = $('giftUser').value.trim(); sendGift(u || 'viewer', $('giftName').value, Number($('giftCount').value) || 1, null); };
let simTimer = null;
function autoSim() {
  clearInterval(simTimer);
  if (!$('autoSim').checked) return;
  simTimer = setInterval(() => {
    const r = Math.random();
    const alive = (state?.players || []).filter((p) => p.alive && !p.bot);
    if (r < 0.45) sendChat(rndName(), Math.random() < 0.6 ? '!entrar' : ['oi', 'vai!', '🔥🔥', 'quem vai ganhar?'][Math.floor(Math.random() * 4)]);
    else {
      const keys = Object.keys(settings.get('gifts'));
      const u = alive.length ? alive[Math.floor(Math.random() * alive.length)].name : rndName();
      sendGift(u, keys[Math.floor(Math.random() * Math.min(keys.length, r > 0.93 ? keys.length : 5))] || 'rose', 1);
    }
  }, Number($('autoRate').value));
}
$('autoSim').onchange = autoSim; $('autoRate').onchange = autoSim;

// ---------- configurações ----------
const NUM = ['maxPlayers', 'minPlayers', 'lobbyTime', 'matchDuration', 'fillBotsTo', 'timeScale'];
const BOOL = ['effects', 'sound', 'monsters', 'autoEvents', 'autoRestart', 'lateJoin', 'keepPlayers'];
function loadCfg() {
  for (const k of NUM) $('s_' + k).value = settings.get(k);
  $('s_difficulty').value = settings.get('difficulty');
  for (const k of BOOL) $('s_' + k).checked = !!settings.get(k);
}
function readCfg() {
  const p = { difficulty: $('s_difficulty').value };
  for (const k of NUM) p[k] = Number($('s_' + k).value);
  for (const k of BOOL) p[k] = $('s_' + k).checked;
  return p;
}
$('btnSave').onclick = () => { const p = readCfg(); settings.patch(p); link.send({ type: 'settings', patch: p }); loadCfg(); log('Configurações aplicadas (valem para a próxima rodada quando afetam o mapa/limites)'); };
$('btnResetCfg').onclick = () => { const { gifts, ...rest } = DEFAULTS; settings.patch(rest); link.send({ type: 'settings', patch: rest }); loadCfg(); log('Configurações restauradas'); };

// ---------- presentes ----------
let gifts = {};
function renderGifts() {
  const tb = $('giftTable').querySelector('tbody');
  tb.innerHTML = Object.entries(gifts).map(([k, g]) => `<tr data-k="${esc(k)}"><td><input class="gk" value="${esc(g.label || k)}"></td><td><select class="ga">${GIFT_ACTIONS.map((a) => `<option ${a === g.action ? 'selected' : ''}>${a}</option>`).join('')}</select></td><td><input class="gv" value="${esc(g.value)}"></td><td><button data-delgift="${esc(k)}">✕</button></td></tr>`).join('');
  $('giftName').innerHTML = Object.entries(gifts).map(([k, g]) => `<option value="${esc(g.label || k)}">${esc(g.label || k)} (${g.action})</option>`).join('');
}
function readGifts() {
  const out = {};
  $('giftTable').querySelectorAll('tbody tr').forEach((tr) => {
    const label = tr.querySelector('.gk').value.trim(); if (!label) return;
    const action = tr.querySelector('.ga').value; let value = tr.querySelector('.gv').value.trim();
    if (value !== '' && !isNaN(Number(value))) value = Number(value);
    out[normGift(label) || label] = { label, action, value };
  });
  return out;
}
$('giftTable').addEventListener('click', (e) => { const b = e.target.closest('[data-delgift]'); if (b) { gifts = readGifts(); delete gifts[b.dataset.delgift]; renderGifts(); } });
$('btnAddGift').onclick = () => { gifts = readGifts(); gifts['novo' + Object.keys(gifts).length] = { label: 'Novo Presente', action: 'heal', value: 20 }; renderGifts(); };
$('btnSaveGifts').onclick = () => { gifts = readGifts(); settings.patch({ gifts }); link.send({ type: 'settings', patch: { gifts } }); renderGifts(); log('Presentes salvos'); };
$('btnResetGifts').onclick = () => { gifts = structuredClone(DEFAULT_GIFTS); settings.patch({ gifts }); link.send({ type: 'settings', patch: { gifts } }); renderGifts(); log('Presentes restaurados'); };

// ---------- TikTok ----------
$('ttUser').value = localStorage.getItem('survivalLive.ttUser') || '';
$('btnTTConnect').onclick = () => { const u = $('ttUser').value.trim(); if (!u) return; localStorage.setItem('survivalLive.ttUser', u); link.send({ type: 'tiktok.connect', username: u }); log(`Conectando ao TikTok: ${esc(u)}…`); if (link.status !== 'connected') log('⚠ servidor não conectado: rode "npm run dev"'); };
$('btnTTDisconnect').onclick = () => link.send({ type: 'tiktok.disconnect' });
$('btnToken').onclick = () => { localStorage.setItem('survivalLive.token', $('token').value); log('Token salvo — recarregando…'); setTimeout(() => location.reload(), 500); };

loadCfg(); gifts = structuredClone(settings.get('gifts')); renderGifts();
log('Painel pronto. Abra o jogo (index.html) em outra aba/janela do mesmo navegador ou conecte via servidor.');

// ---------- mapas ----------
const RANDOM_CARD = { id: 'random', icon: '🎲', name: 'Aleatório', desc: 'Sorteia um mapa diferente a cada rodada.' };
let pickedMap = settings.get('mapId');
function renderMapPick() {
  const box = $('mapPick');
  box.innerHTML = [...MAP_IDS.map((id) => MAPS[id]), RANDOM_CARD].map((m) => `<div class="mapcard ${m.id === pickedMap ? 'sel' : ''}" data-map="${m.id}"><div class="ph" id="mp_${m.id}">${m.icon}</div><b>${m.icon} ${esc(m.name)}</b><span>${esc(m.desc)}</span>${m.hazard ? `<em>Perigo: ${esc(m.hazard)}</em>` : ''}</div>`).join('');
  $('mapInfo').textContent = `Mapa ativo nas configurações: ${pickedMap === 'random' ? 'Aleatório' : MAPS[pickedMap].name}. A troca vale na próxima rodada (ou na hora, se reiniciar a sala).`;
  drawMapPreviews();
}
const previewDone = new Set();
function drawMapPreviews() {
  // gera as miniaturas aos poucos para não travar a página
  MAP_IDS.filter((id) => !previewDone.has(id)).forEach((id, i) => setTimeout(() => {
    const host = document.getElementById('mp_' + id);
    if (!host || previewDone.has(id)) return;
    try {
      const map = new GameMap(20260101, id), g = makeGround(map), S = 0.5;
      const c = document.createElement('canvas'); c.width = c.height = 220; const x = c.getContext('2d'), k = 220 / map.w;
      x.drawImage(g, 0, 0, 220, 220);
      x.fillStyle = id === 'snow' ? '#2f5f4c' : id === 'desert' ? '#3f8a3f' : '#1f6b34';
      for (const t of map.trees) x.fillRect(t.x * k - 1, t.y * k - 1, 2.2, 2.2);
      x.fillStyle = id === 'desert' ? '#c98a4a' : '#7f8794';
      for (const m of map.mountains) { x.beginPath(); x.arc(m.x * k, m.y * k, m.vr * k, 0, 6.3); x.fill(); }
      x.fillStyle = '#8a4a2a';
      for (const h of map.houses) x.fillRect(h.x * k, h.y * k, Math.max(3, h.w * k), Math.max(3, h.h * k));
      host.replaceWith(Object.assign(c, { id: 'mp_' + id }));
      previewDone.add(id);
    } catch (e) { log('Não foi possível gerar a miniatura de ' + id); }
  }, 150 + i * 350));
}
$('mapPick').addEventListener('click', (e) => { const c = e.target.closest('[data-map]'); if (!c) return; pickedMap = c.dataset.map; document.querySelectorAll('.mapcard').forEach((el) => el.classList.toggle('sel', el.dataset.map === pickedMap)); });
function applyMap(restart) {
  settings.patch({ mapId: pickedMap }); link.send({ type: 'settings', patch: { mapId: pickedMap } });
  const nm = pickedMap === 'random' ? 'Aleatório' : MAPS[pickedMap].name;
  $('mapInfo').textContent = `Mapa ativo nas configurações: ${nm}. A troca vale na próxima rodada (ou na hora, se reiniciar a sala).`;
  if (restart) { cmd({ cmd: 'restart' }); log(`Mapa "${esc(nm)}" aplicado — sala reiniciada`); } else log(`Mapa "${esc(nm)}" será usado na próxima rodada`);
}
$('btnMapApply').onclick = () => { if (state && state.phase === 'playing' && !confirm('Isso encerra a partida em andamento e volta para a sala de espera. Continuar?')) return; applyMap(true); };
$('btnMapNext').onclick = () => applyMap(false);
renderMapPick();

// ---------- ranking dos espectadores ----------
const ranking = new RankingSystem({ link, role: 'admin' });
const rkPanel = new RankingPanel({ root: $('rkAdminPanel'), ranking, mode: 'admin', onOpen: (k) => openProfile(k) });
let openedProfile = null;
function openProfile(key) { openedProfile = key; $('rkProfileBody').innerHTML = profileHTML(ranking, key, { admin: true }); $('rkProfile').classList.remove('hidden'); }
$('rkProfileClose').onclick = () => $('rkProfile').classList.add('hidden');
$('rkProfile').addEventListener('pointerdown', (e) => { if (e.target === $('rkProfile')) $('rkProfile').classList.add('hidden'); });
document.addEventListener('keydown', (e) => { if (e.key === 'Escape') $('rkProfile').classList.add('hidden'); });

function adjust(user, delta, reason) {
  user = String(user || '').trim();
  if (!user) { log('Informe o usuário do espectador'); return; }
  if (!Number.isFinite(delta) || delta === 0) { log('Informe uma quantidade de pontos diferente de zero'); return; }
  if (ranking.adjust(user, delta, reason) === 'applied') log(`${delta > 0 ? '＋' : '−'}${fmtN(Math.abs(delta))} pontos para <b>${esc(user)}</b>${reason ? ' — ' + esc(reason) : ''}`);
  else log('Não foi possível ajustar (nome inválido?)');
  if (openedProfile && !$('rkProfile').classList.contains('hidden')) openProfile(openedProfile);
  rkPanel.render(); renderRkStats();
}
$('btnAdjAdd').onclick = () => adjust($('adjUser').value, Math.abs(Number($('adjDelta').value)), $('adjReason').value);
$('btnAdjSub').onclick = () => adjust($('adjUser').value, -Math.abs(Number($('adjDelta').value)), $('adjReason').value);
$('rkProfileBody').addEventListener('click', (e) => {
  const b = e.target.closest('[data-adj]'); if (!b) return;
  const box = b.closest('.rk-adj');
  adjust(box.dataset.user, Number(b.dataset.adj) * Math.abs(Number(box.querySelector('.rk-delta').value)), box.querySelector('.rk-reason').value);
});

const SC = Object.keys(DEFAULT_SCORING).filter((k) => typeof DEFAULT_SCORING[k] === 'number');
function loadScoring() {
  const c = ranking.store.config;
  for (const k of SC) $('sc_' + k).value = c[k];
  $('sc_botKills').checked = !!c.botKills;
  for (let i = 1; i < 6; i++) $('lv_' + i).value = c.levelMins[i];
}
function readScoring() {
  const c = { botKills: $('sc_botKills').checked, levelMins: [0] };
  for (const k of SC) c[k] = Number($('sc_' + k).value);
  for (let i = 1; i < 6; i++) c.levelMins.push(Number($('lv_' + i).value));
  return c;
}
$('btnScSave').onclick = () => { ranking.setConfig(readScoring()); loadScoring(); log('Pontuação e níveis salvos'); rkPanel.render(); };
$('btnScReset').onclick = () => { ranking.setConfig({ ...DEFAULT_SCORING, levelMins: DEFAULT_LEVEL_MINS }); loadScoring(); log('Pontuação restaurada para o padrão'); rkPanel.render(); };

$('btnResetWeek').onclick = () => { if (confirm('Zerar o ranking SEMANAL de todos os espectadores? (o ranking geral não muda)')) { ranking.reset('week'); log('Ranking semanal zerado'); rkPanel.render(); renderRkStats(); } };
$('btnResetMonth').onclick = () => { if (confirm('Zerar o ranking MENSAL de todos os espectadores? (o ranking geral não muda)')) { ranking.reset('month'); log('Ranking mensal zerado'); rkPanel.render(); renderRkStats(); } };
$('btnPurgeSim').onclick = () => { if (confirm('Apagar TODOS os perfis simulados/de demonstração? Perfis vindos do TikTok são mantidos.')) { ranking.purgeSim(); log('Perfis simulados apagados'); rkPanel.render(); renderRkStats(); } };
const stamp = () => new Date().toISOString().slice(0, 10);
$('btnExportCsv').onclick = () => { download(`ranking-survival-live-${stamp()}.csv`, '\ufeff' + ranking.store.exportCSV(), 'text/csv'); log('Ranking exportado (CSV)'); };
$('btnExportJson').onclick = () => { download(`ranking-survival-live-${stamp()}.json`, ranking.store.exportJSON(), 'application/json'); log('Ranking exportado (JSON)'); };

function renderRkStats() {
  const s = ranking.store.stats(), srv = ranking.mode === 'server';
  $('rkStats').innerHTML = `${fmtN(s.profiles)} perfis (${fmtN(s.real)} do TikTok · ${fmtN(s.sim)} simulados) · ${fmtN(s.points)} pontos distribuídos. Clique em um espectador para ver o perfil completo.`;
  const m = $('rkMode'); m.className = 'pill ' + (srv ? 'on' : 'try'); m.textContent = srv ? '💾 salvo no servidor' : '💾 só neste navegador';
  $('rkNote').textContent = srv ? 'O ranking é gravado em data/ranking.json no servidor e sincronizado com o jogo.' : 'Servidor indisponível: o ranking fica salvo neste navegador e será enviado ao servidor quando ele conectar.';
  $('rkUsers').innerHTML = ranking.store.board({ limit: 300 }).map((r) => `<option value="${esc(r.name)}">`).join('');
}
ranking.on('status', () => { loadScoring(); renderRkStats(); });
ranking.on('change', (() => { let t = 0; return () => { if (!t) t = setTimeout(() => { t = 0; renderRkStats(); }, 800); }; })());
loadScoring(); renderRkStats();
