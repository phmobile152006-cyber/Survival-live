// Armas, ataques, projéteis e dano (sem DOM)
import { angleTo, angleDiff, rand, TAU } from './utils.js';

export const WEAPONS = {
  sword: { name: 'Espada', type: 'melee', dmg: 11, range: 46, cd: 0.5, arc: 1.7, score: 22, color: '#d7e0ea' },
  axe: { name: 'Machado', type: 'melee', dmg: 20, range: 48, cd: 0.95, arc: 2.6, score: 22, color: '#b9c0c9' },
  spear: { name: 'Lança', type: 'melee', dmg: 13, range: 76, cd: 0.65, arc: 0.55, score: 21, color: '#e0c28a' },
  bow: { name: 'Arco', type: 'ranged', dmg: 15, range: 380, cd: 0.85, speed: 560, proj: 'arrow', score: 19, color: '#c58a4a' },
  gun: { name: 'Blaster', type: 'ranged', dmg: 5, range: 310, cd: 0.22, speed: 820, proj: 'bullet', spread: 0.07, score: 22, color: '#8fd3ff' },
  staff: { name: 'Cajado Arcano', type: 'ranged', dmg: 20, range: 290, cd: 1.2, speed: 380, proj: 'orb', splash: 60, special: true, score: 30, color: '#c58cff' },
  hammer: { name: 'Martelo do Trovão', type: 'melee', dmg: 30, range: 64, cd: 1.5, arc: TAU, aoe: 84, special: true, score: 32, color: '#ffd84a' },
  flame: { name: 'Lança-chamas', type: 'ranged', dmg: 2.4, range: 170, cd: 0.07, speed: 430, proj: 'flame', pierce: true, special: true, score: 34, color: '#ff7a2e' },
};
export const BASIC_WEAPONS = ['sword', 'axe', 'spear', 'bow', 'gun'];
export const SPECIAL_WEAPONS = ['staff', 'hammer', 'flame'];

export class Combat {
  constructor(game) {
    this.game = game;
    this.projectiles = [];
  }
  clear() { this.projectiles.length = 0; }

  /** inimigos possíveis de um atacante */
  *enemiesOf(att) {
    const g = this.game;
    if (att.isMonster) { for (const f of g.fighters) if (f.alive) yield f; return; }
    for (const f of g.fighters) if (f.alive && f !== att) yield f;
    for (const m of g.monsters) if (m.alive) yield m;
  }

  attack(att, target) {
    if (att.attackCd > 0) return false;
    const w = WEAPONS[att.weapon];
    const rage = att.rageT > 0 ? 1.35 : 1;
    att.attackCd = (w.cd / rage) * rand(0.95, 1.08);
    att.swingT = att.swingMax = Math.min(0.28, w.cd * 0.7);
    att.attackedT = 0;
    let ang = angleTo(att, target);
    att.facing = ang;
    const g = this.game;
    if (w.type === 'melee') {
      g.audio?.('swing', att);
      this.meleeHit(att, w, ang);
    } else {
      // mira antecipada
      const d = Math.hypot(target.x - att.x, target.y - att.y);
      const t = d / w.speed;
      const lead = Math.atan2(target.y + (target.vy || 0) * t * 0.8 - att.y, target.x + (target.vx || 0) * t * 0.8 - att.x);
      ang = lead + (w.spread ? rand(-w.spread, w.spread) : 0);
      this.fire(att, w, ang);
      g.audio?.(w.proj === 'bullet' ? 'shoot' : w.proj === 'flame' ? 'flame' : 'bow', att);
    }
    return true;
  }

  meleeHit(att, w, ang) {
    const g = this.game;
    const mult = (att.rageT > 0 ? 1.8 : 1);
    const px = att.x + Math.cos(ang) * att.r, py = att.y + Math.sin(ang) * att.r;
    if (w.aoe) {
      g.fx.ring(att.x, att.y, 10, w.aoe, 0.35, '#ffe27a', 5);
      g.fx.burst(att.x, att.y, 10, { speed: 160, color: ['#fff6a0', '#ffd84a'], life: 0.4 });
      g.fx.shake = Math.max(g.fx.shake, 5);
      for (const e of this.enemiesOf(att)) {
        if (Math.hypot(e.x - att.x, e.y - att.y) - e.r <= w.aoe) this.damage(e, w.dmg * mult * (att.dmgMul || 1), att, { weapon: w.name });
      }
      return;
    }
    for (const e of this.enemiesOf(att)) {
      const d = Math.hypot(e.x - att.x, e.y - att.y) - e.r;
      if (d > w.range) continue;
      const a = angleTo(att, e);
      if (Math.abs(angleDiff(ang, a)) <= w.arc / 2 + Math.atan2(e.r, Math.max(10, d + e.r))) {
        this.damage(e, w.dmg * mult * (att.dmgMul || 1), att, { weapon: w.name });
        g.fx.burst(px + Math.cos(a) * d * 0.5, py + Math.sin(a) * d * 0.5, 4, { speed: 110, color: ['#fff', '#ffd2a0'], life: 0.25, size: 2.5 });
      }
    }
  }

  fire(att, w, ang) {
    const mult = att.rageT > 0 ? 1.8 : 1;
    const sp = w.speed * (w.proj === 'flame' ? rand(0.8, 1.1) : 1);
    this.projectiles.push({
      x: att.x + Math.cos(ang) * (att.r + 4), y: att.y + Math.sin(ang) * (att.r + 4),
      vx: Math.cos(ang) * sp, vy: Math.sin(ang) * sp, ang,
      life: w.range / w.speed, kind: w.proj, dmg: w.dmg * mult * (att.dmgMul || 1), owner: att, splash: w.splash || 0,
      pierce: !!w.pierce, hit: null, weapon: w.name, r: w.proj === 'flame' ? 9 : w.proj === 'orb' ? 8 : 4,
    });
  }

  update(dt) {
    const g = this.game, P = this.projectiles;
    for (let i = P.length - 1; i >= 0; i--) {
      const p = P[i];
      p.x += p.vx * dt; p.y += p.vy * dt;
      p.life -= dt;
      let dead = p.life <= 0;
      if (p.kind === 'flame') g.fx.particle(p.x, p.y, { vx: rand(-20, 20), vy: rand(-20, 20), life: 0.3, size: rand(4, 8), color: Math.random() < 0.5 ? '#ff8a2e' : '#ffd24a', grow: 8, kind: 'dot' });
      else if (p.kind === 'orb') g.fx.particle(p.x, p.y, { life: 0.3, size: 5, color: '#d9b0ff', grow: -10 });
      if (!dead && g.map.solidAt(p.x, p.y, 1)) {
        const l = g.map._cell(g.map.grid, p.x, p.y);
        // árvores bloqueiam projéteis; água profunda não
        let hitSolid = false;
        if (l) for (const s of l) {
          if (s.type === 'lake') continue;
          if (s.kind === 'circle' && (p.x - s.x) ** 2 + (p.y - s.y) ** 2 < s.r * s.r) hitSolid = true;
          else if (s.kind === 'rect' && p.x > s.x && p.x < s.x + s.w && p.y > s.y && p.y < s.y + s.h) hitSolid = true;
        }
        if (hitSolid) { dead = true; g.fx.burst(p.x, p.y, 3, { speed: 60, life: 0.2, size: 2 }); }
      }
      if (!dead) {
        for (const e of this.enemiesOf(p.owner)) {
          if (p.hit && p.hit.includes(e)) continue;
          if ((e.x - p.x) ** 2 + (e.y - p.y) ** 2 <= (e.r + p.r) ** 2) {
            this.damage(e, p.dmg, p.owner, { weapon: p.weapon });
            g.fx.burst(p.x, p.y, 4, { speed: 100, life: 0.25, size: 2.5, color: ['#fff', '#ffd27a'] });
            if (p.pierce) (p.hit || (p.hit = [])).push(e);
            else { dead = true; break; }
          }
        }
      }
      if (dead) {
        if (p.splash) this.explode(p.x, p.y, p.splash, p.dmg * 0.7, p.owner, p.weapon);
        P[i] = P[P.length - 1]; P.pop();
      }
    }
  }

  explode(x, y, r, dmg, owner, weapon) {
    const g = this.game;
    g.fx.explosion(x, y, r);
    g.audio?.('explosion', { x, y });
    const all = owner ? this.enemiesOf(owner) : null;
    const hit = (e) => {
      const d = Math.hypot(e.x - x, e.y - y) - e.r;
      if (d < r) this.damage(e, dmg * (1 - Math.max(0, d) / r * 0.5), owner, { weapon });
    };
    if (all) for (const e of all) hit(e);
  }

  /** aplica dano; retorna dano efetivo */
  damage(t, amt, src, o = {}) {
    const g = this.game;
    if (!t.alive || amt <= 0) return 0;
    if (t.isFighter && (g.phase !== 'playing' || t.invuln > 0)) return 0;
    if (t.isMonster && t.invuln > 0) return 0;
    if (t.shield > 0) {
      const a = Math.min(t.shield, amt);
      t.shield -= a; amt -= a;
      g.fx.burst(t.x, t.y, 3, { speed: 80, life: 0.25, size: 2.5, color: '#7ad7ff' });
      if (amt <= 0) { g.fx.text(t.x, t.y - t.r - 10, 'BLOQUEOU', '#7ad7ff', 12); return 0; }
    }
    t.hp -= amt;
    t.hitFlash = 0.12;
    t.lastHitBy = src || null;
    t.lastHitCause = o.cause || null;
    t.lastHitWeapon = o.weapon || null;
    t.lastHitT = g.time;
    g.fx.text(t.x, t.y - t.r - 10, Math.max(1, Math.round(amt)), t.isFighter ? '#ff6b6b' : '#ffd166', amt > 25 ? 20 : 14);
    g.fx.burst(t.x, t.y, 3, { speed: 90, life: 0.35, size: 3, color: t.isMonster && t.type === 'zombie' ? '#7bd14a' : '#d62d3a', drag: 4 });
    if (!o.quiet) g.audio?.('hit', t);
    if (t.onHurt) t.onHurt(src, g);
    if (t.hp <= 0) g.kill(t, src, o);
    return amt;
  }
}
