// Renderização Canvas 2D do jogo (mundo, personagens, efeitos, zona)
import { TAU, clamp, lerp } from './utils.js';
import { WEAPONS } from './combat.js';
import { ITEM_TYPES } from './items.js';
import { PLAZA, MAP_W, MAP_H } from './map.js';
import { BEHAVIORS } from './player.js';
import { computeRanking } from './leaderboard.js';
import { makeTrees, makeRocks, makeHouse, makeMountain, makeGround } from './sprites.js';

export class Renderer {
  constructor(canvas, game, camera) {
    this.c = canvas; this.ctx = canvas.getContext('2d');
    this.game = game; this.cam = camera;
    this.trees = makeTrees(); this.rocks = makeRocks();
    this.houseCache = new Map(); this.mtnCache = new Map();
    this.ground = null; this.mini = null; this.t = 0;
    this.rank = new Map(); this.rankT = 0;
    this.rain = Array.from({ length: 140 }, () => ({ x: Math.random(), y: Math.random(), s: 0.6 + Math.random() }));
    this.list = [];
    this.resize();
    this.setMap(game.map);
    game.on('map', (m) => this.setMap(m));
  }
  resize() {
    const w = window.innerWidth, h = window.innerHeight;
    const s = Math.min(1, 1920 / w, 1080 / h * (w / h) / (w / h));
    this.scale = Math.min(1, 1920 / w);
    this.vw = Math.max(320, Math.round(w * this.scale)); this.vh = Math.max(240, Math.round(h * this.scale));
    this.c.width = this.vw; this.c.height = this.vh;
    this.vignette = null;
  }
  setMap(map) {
    this.map = map;
    this.trees = makeTrees(map.theme); this.rocks = makeRocks(map.theme);
    this.flakes = null;
    this.ground = makeGround(map);
    this.mini = document.createElement('canvas'); this.mini.width = this.mini.height = 220;
    this.mini.getContext('2d').drawImage(this.ground, 0, 0, 220, 220);
    this.houseCache.clear(); this.mtnCache.clear();
  }
  houseSprite(h) { const k = `${h.w | 0}_${h.h | 0}_${h.v}`; let s = this.houseCache.get(k); if (!s) { s = makeHouse(Math.round(h.w), Math.round(h.h), h.v, this.map.theme); this.houseCache.set(k, s); } return s; }
  mtnSprite(m) { const k = `${m.vr | 0}_${m.v}`; let s = this.mtnCache.get(k); if (!s) { s = makeMountain(m.vr, m.v, this.map.theme); this.mtnCache.set(k, s); } return s; }

  // ======================= quadro =======================
  render(dt) {
    const g = this.game, ctx = this.ctx, cam = this.cam, map = this.map;
    this.t += dt;
    const vw = this.vw, vh = this.vh, z = cam.zoom;
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.fillStyle = '#0b1a0d'; ctx.fillRect(0, 0, vw, vh);
    const sh = g.fx.shake, sx = sh ? (Math.random() - 0.5) * sh : 0, sy = sh ? (Math.random() - 0.5) * sh : 0;
    ctx.setTransform(z, 0, 0, z, vw / 2 - cam.x * z + sx, vh / 2 - cam.y * z + sy);
    const x0 = cam.x - vw / 2 / z - 160, x1 = cam.x + vw / 2 / z + 160, y0 = cam.y - vh / 2 / z - 200, y1 = cam.y + vh / 2 / z + 160;
    this.view = { x0, y0, x1, y1 };

    // chão
    const gx0 = clamp(x0, 0, MAP_W), gy0 = clamp(y0, 0, MAP_H), gx1 = clamp(x1, 0, MAP_W), gy1 = clamp(y1, 0, MAP_H);
    if (gx1 > gx0 && gy1 > gy0) ctx.drawImage(this.ground, gx0 * 0.5, gy0 * 0.5, (gx1 - gx0) * 0.5, (gy1 - gy0) * 0.5, gx0, gy0, gx1 - gx0, gy1 - gy0);
    // marcas de explosão
    for (const s of g.fx.scorches) { ctx.globalAlpha = Math.min(1, s.life / 6) * 0.5; ctx.fillStyle = '#1a120c'; ctx.beginPath(); ctx.ellipse(s.x, s.y, s.r, s.r * 0.8, 0, 0, TAU); ctx.fill(); }
    ctx.globalAlpha = 1;
    this.drawSwampBubbles(map);
    this.drawDangers(g);
    this.drawCampfire();
    this.drawItems(g);

    // lista com profundidade
    const L = this.list; L.length = 0;
    const inView = (x, y, r) => x > x0 - r && x < x1 + r && y > y0 - r && y < y1 + r;
    for (const t of map.trees) if (inView(t.x, t.y, 60)) L.push({ y: t.y, k: 0, o: t });
    for (const r of map.rocks) if (inView(r.x, r.y, 50)) L.push({ y: r.y, k: 1, o: r });
    for (const h of map.houses) if (inView(h.x + h.w / 2, h.y + h.h / 2, 150)) L.push({ y: h.y + h.h, k: 2, o: h });
    for (const m of map.mountains) if (inView(m.x, m.y, m.vr * 1.3)) L.push({ y: m.y + m.vr * 0.35, k: 3, o: m });
    for (const b of map.bushes) if (inView(b.x, b.y, 50)) L.push({ y: b.y + b.r * 0.4, k: 4, o: b });
    for (const f of g.fighters) if (inView(f.x, f.y, 80) && (f.alive || f.corpseT < 4)) L.push({ y: f.y, k: 5, o: f });
    for (const m of g.monsters) if (inView(m.x, m.y, 120) && (m.alive || m.deadT < 1.5)) L.push({ y: m.y, k: 6, o: m });
    L.sort((a, b) => a.y - b.y);
    for (const e of L) {
      switch (e.k) {
        case 0: this.drawTree(e.o); break;
        case 1: this.drawRock(e.o); break;
        case 2: this.drawHouse(e.o); break;
        case 3: this.drawMountain(e.o); break;
        case 4: this.drawBush(e.o); break;
        case 5: this.drawFighter(e.o); break;
        case 6: this.drawMonster(e.o); break;
      }
    }
    this.drawProjectiles(g);
    this.drawParticles(g);
    this.drawMeteors(g);

    // ======= espaço de tela =======
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    this.drawZone(g);
    this.drawAmbient(dt);
    this.drawWeather(g, dt);
    this.drawLabels(g);
    this.drawFloatTexts(g);
    this.drawVignette();
    if (g.fx.flash > 0) { ctx.fillStyle = `rgba(255,255,255,${Math.min(0.7, g.fx.flash)})`; ctx.fillRect(0, 0, vw, vh); }
  }

  // ======================= cenário =======================
  drawTree(t) {
    const s = t.s, sp = this.trees[t.v], g = this.game;
    // copa fica translúcida quando alguém está atrás dela
    let hide = false;
    for (const f of g.fighters) if (f.alive && f.y < t.y && f.y > t.y - 95 * s && Math.abs(f.x - t.x) < 48 * s) { hide = true; break; }
    if (!hide) for (const m of g.monsters) if (m.alive && m.y < t.y && m.y > t.y - 95 * s && Math.abs(m.x - t.x) < 48 * s) { hide = true; break; }
    if (hide) this.ctx.globalAlpha = 0.45;
    this.ctx.drawImage(sp, t.x - 64 * s, t.y - 128 * s, 128 * s, 150 * s);
    if (hide) this.ctx.globalAlpha = 1;
  }
  drawRock(r) { const s = r.r / 26; this.ctx.drawImage(this.rocks[r.v], r.x - 48 * s, r.y - 52 * s, 96 * s, 84 * s); }
  drawHouse(h) { const sp = this.houseSprite(h); this.ctx.drawImage(sp, h.x - 17, h.y - 30); }
  drawMountain(m) { const sp = this.mtnSprite(m); this.ctx.drawImage(sp, m.x - sp.width / 2, m.y - sp.height / 2); }
  drawBush(b) {
    const ctx = this.ctx;
    ctx.globalAlpha = 0.93;
    ctx.fillStyle = 'rgba(0,0,0,0.2)'; ctx.beginPath(); ctx.ellipse(b.x + 4, b.y + b.r * 0.55, b.r, b.r * 0.4, 0, 0, TAU); ctx.fill();
    const cols = this.map.theme.visual.bush;
    for (let i = 0; i < 3; i++) {
      ctx.fillStyle = cols[i]; ctx.beginPath();
      ctx.arc(b.x - b.r * 0.25 * (1 - i * 0.4), b.y - b.r * (0.1 + i * 0.12), b.r * (0.78 - i * 0.12), 0, TAU);
      ctx.arc(b.x + b.r * 0.3 * (1 - i * 0.4), b.y - b.r * (0.05 + i * 0.1), b.r * (0.7 - i * 0.12), 0, TAU); ctx.fill();
    }
    ctx.globalAlpha = 1;
  }
  drawSwampBubbles(map) {
    const ctx = this.ctx, v = this.view;
    for (const s of map.swamps) {
      if (s.x + s.r < v.x0 || s.x - s.r > v.x1 || s.y + s.r < v.y0 || s.y - s.r > v.y1) continue;
      for (let i = 0; i < 6; i++) {
        const p = (this.t * 0.5 + i / 6) % 1, a = i * 2.1 + s.x, d = (0.2 + ((i * 37) % 60) / 100) * s.r;
        ctx.globalAlpha = Math.sin(p * Math.PI) * 0.7; ctx.fillStyle = this.map.theme.visual.bubbles[i % 2];
        ctx.beginPath(); ctx.arc(s.x + Math.cos(a) * d, s.y + Math.sin(a) * d - p * 14, 3 + p * 5, 0, TAU); ctx.fill();
      }
    }
    ctx.globalAlpha = 1;
  }
  drawCampfire() {
    const ctx = this.ctx, x = PLAZA.x, y = PLAZA.y, t = this.t;
    ctx.fillStyle = 'rgba(0,0,0,0.25)'; ctx.beginPath(); ctx.ellipse(x, y + 14, 34, 12, 0, 0, TAU); ctx.fill();
    ctx.strokeStyle = '#5b3a1e'; ctx.lineWidth = 8; ctx.lineCap = 'round';
    for (let i = 0; i < 5; i++) { const a = (i / 5) * TAU + 0.3; ctx.beginPath(); ctx.moveTo(x + Math.cos(a) * 26, y + Math.sin(a) * 12); ctx.lineTo(x - Math.cos(a) * 8, y - Math.sin(a) * 4); ctx.stroke(); }
    const gl = ctx.createRadialGradient(x, y, 4, x, y, 150 + Math.sin(t * 8) * 8);
    gl.addColorStop(0, 'rgba(255,180,80,0.38)'); gl.addColorStop(1, 'rgba(255,140,40,0)');
    ctx.fillStyle = gl; ctx.beginPath(); ctx.arc(x, y, 160, 0, TAU); ctx.fill();
    for (let i = 0; i < 3; i++) {
      const h = 38 - i * 10 + Math.sin(t * 9 + i * 2) * 6, w = 15 - i * 3;
      ctx.fillStyle = ['#ff7a1f', '#ffb52e', '#fff0a0'][i];
      ctx.beginPath(); ctx.moveTo(x - w, y); ctx.quadraticCurveTo(x - w * 0.6, y - h * 0.6, x + Math.sin(t * 7 + i) * 3, y - h); ctx.quadraticCurveTo(x + w * 0.6, y - h * 0.6, x + w, y); ctx.closePath(); ctx.fill();
    }
  }
  drawDangers(g) {
    const ctx = this.ctx;
    for (const d of g.dangers) {
      const p = 1 - d.t / d.T, pulse = 0.5 + 0.5 * Math.sin(this.t * 14);
      const col = d.kind === 'lightning' ? '120,180,255' : d.kind === 'slam' ? '255,90,40' : '255,50,40';
      ctx.fillStyle = `rgba(${col},${0.12 + 0.18 * pulse})`; ctx.beginPath(); ctx.arc(d.x, d.y, d.r, 0, TAU); ctx.fill();
      ctx.strokeStyle = `rgba(${col},0.85)`; ctx.lineWidth = 3; ctx.setLineDash([12, 8]); ctx.beginPath(); ctx.arc(d.x, d.y, d.r, 0, TAU); ctx.stroke(); ctx.setLineDash([]);
      ctx.strokeStyle = `rgba(${col},0.6)`; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(d.x, d.y, d.r * p, 0, TAU); ctx.stroke();
    }
  }
  drawMeteors(g) {
    const ctx = this.ctx;
    for (const d of g.dangers) {
      if (d.kind === 'meteor') {
        const p = 1 - d.t / d.T;
        if (p < 0.2) continue;
        const k = 1 - (p - 0.2) / 0.8, mx = d.x + k * 260, my = d.y - k * 620;
        ctx.strokeStyle = 'rgba(255,170,60,0.7)'; ctx.lineWidth = 10; ctx.lineCap = 'round'; ctx.beginPath(); ctx.moveTo(mx, my); ctx.lineTo(mx + 150 * 0.39, my - 150 * 0.92); ctx.stroke();
        const gr = ctx.createRadialGradient(mx, my, 2, mx, my, 34); gr.addColorStop(0, '#fff6c0'); gr.addColorStop(0.4, '#ff9a2e'); gr.addColorStop(1, 'rgba(255,60,0,0)');
        ctx.fillStyle = gr; ctx.beginPath(); ctx.arc(mx, my, 34, 0, TAU); ctx.fill();
      } else if (d.kind === 'lightning' && d.t < 0.2) {
        ctx.strokeStyle = '#eaf4ff'; ctx.lineWidth = 5; ctx.beginPath(); let px = d.x + 30, py = d.y - 700; ctx.moveTo(px, py);
        for (let i = 0; i < 8; i++) { px += (Math.random() - 0.5) * 60 - 4; py += 90; ctx.lineTo(px, py); }
        ctx.lineTo(d.x, d.y); ctx.stroke();
      }
    }
  }
  drawItems(g) {
    const ctx = this.ctx, v = this.view, t = this.t;
    for (const c of g.items.crates) {
      if (c.x < v.x0 && !c.golden) continue;
      const pulse = 0.5 + 0.5 * Math.sin(t * 4 + c.x);
      if (c.golden || c.beacon) {
        const gr = ctx.createLinearGradient(0, c.y - 900, 0, c.y);
        gr.addColorStop(0, 'rgba(255,220,100,0)'); gr.addColorStop(1, `rgba(255,220,100,${0.35 + 0.2 * pulse})`);
        ctx.fillStyle = gr; ctx.fillRect(c.x - 22, c.y - 900, 44, 900);
      }
      ctx.fillStyle = 'rgba(0,0,0,0.3)'; ctx.beginPath(); ctx.ellipse(c.x + 4, c.y + 14, 26, 9, 0, 0, TAU); ctx.fill();
      ctx.fillStyle = c.golden ? '#e0a526' : '#a8703a'; ctx.fillRect(c.x - 20, c.y - 16, 40, 32);
      ctx.fillStyle = c.golden ? '#fff0a0' : '#c98b4a'; ctx.fillRect(c.x - 20, c.y - 16, 40, 9);
      ctx.fillStyle = c.golden ? '#8a5a10' : '#5b3a1e'; ctx.fillRect(c.x - 20, c.y - 2, 40, 4); ctx.fillRect(c.x - 3, c.y - 16, 6, 32);
      ctx.strokeStyle = '#3a2412'; ctx.lineWidth = 2; ctx.strokeRect(c.x - 20, c.y - 16, 40, 32);
      if (c.golden) { ctx.fillStyle = `rgba(255,240,150,${0.5 * pulse})`; ctx.beginPath(); ctx.arc(c.x, c.y, 34, 0, TAU); ctx.fill(); }
    }
    for (const it of g.items.list) {
      if (it.x < v.x0 || it.x > v.x1 || it.y < v.y0 || it.y > v.y1) continue;
      const T = ITEM_TYPES[it.type], by = Math.sin(t * 3 + it.bob) * 3;
      const special = it.type === 'weapon' && WEAPONS[it.weapon].special;
      const col = it.type === 'weapon' ? WEAPONS[it.weapon].color : T.color;
      const gr = ctx.createRadialGradient(it.x, it.y, 2, it.x, it.y, 22);
      gr.addColorStop(0, special ? 'rgba(200,140,255,0.55)' : 'rgba(255,255,255,0.28)'); gr.addColorStop(1, 'rgba(255,255,255,0)');
      ctx.fillStyle = gr; ctx.beginPath(); ctx.arc(it.x, it.y, 22, 0, TAU); ctx.fill();
      ctx.fillStyle = 'rgba(0,0,0,0.25)'; ctx.beginPath(); ctx.ellipse(it.x, it.y + 9, 9, 3.5, 0, 0, TAU); ctx.fill();
      ctx.save(); ctx.translate(it.x, it.y + by - 2);
      switch (it.type) {
        case 'medkit': ctx.fillStyle = '#fff'; ctx.fillRect(-9, -7, 18, 14); ctx.fillStyle = '#e8294c'; ctx.fillRect(-2.5, -5, 5, 10); ctx.fillRect(-5, -2.5, 10, 5); ctx.strokeStyle = '#b01f3a'; ctx.lineWidth = 1.5; ctx.strokeRect(-9, -7, 18, 14); break;
        case 'bandage': ctx.fillStyle = '#f4ead2'; ctx.beginPath(); ctx.arc(0, 0, 7, 0, TAU); ctx.fill(); ctx.strokeStyle = '#c9b88a'; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(0, 0, 4, 0, TAU); ctx.stroke(); ctx.fillStyle = '#e8294c'; ctx.fillRect(-1.2, -5, 2.4, 10); break;
        case 'energy': ctx.fillStyle = '#25b6ee'; ctx.fillRect(-5, -8, 10, 16); ctx.fillStyle = '#fff'; ctx.beginPath(); ctx.moveTo(1.5, -6); ctx.lineTo(-3, 1); ctx.lineTo(0, 1); ctx.lineTo(-1.5, 6); ctx.lineTo(3.5, -1.5); ctx.lineTo(0.5, -1.5); ctx.closePath(); ctx.fill(); break;
        case 'shield': ctx.fillStyle = '#4f86f7'; ctx.beginPath(); ctx.moveTo(0, -9); ctx.lineTo(8, -5); ctx.lineTo(6, 4); ctx.lineTo(0, 9); ctx.lineTo(-6, 4); ctx.lineTo(-8, -5); ctx.closePath(); ctx.fill(); ctx.strokeStyle = '#cfe0ff'; ctx.lineWidth = 1.5; ctx.stroke(); break;
        case 'weapon': ctx.rotate(-0.6); ctx.scale(0.72, 0.72); this.drawWeaponShape(it.weapon, 0); break;
        default: break;
      }
      ctx.restore();
      if (special) { ctx.strokeStyle = `rgba(210,150,255,${0.5 + 0.4 * Math.sin(t * 5)})`; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(it.x, it.y + by, 16, 0, TAU); ctx.stroke(); }
    }
  }

  // ======================= personagens =======================
  drawWeaponShape(key, swing) {
    const ctx = this.ctx, w = WEAPONS[key];
    ctx.lineCap = 'round';
    switch (key) {
      case 'sword': ctx.fillStyle = '#7a4a1e'; ctx.fillRect(-3, -2, 7, 4); ctx.fillStyle = '#c9a23a'; ctx.fillRect(3, -5, 3, 10); ctx.fillStyle = w.color; ctx.beginPath(); ctx.moveTo(6, -2.2); ctx.lineTo(30, -1); ctx.lineTo(34, 0); ctx.lineTo(30, 1); ctx.lineTo(6, 2.2); ctx.closePath(); ctx.fill(); ctx.strokeStyle = '#8c97a3'; ctx.lineWidth = 1; ctx.stroke(); break;
      case 'axe': ctx.strokeStyle = '#7a4a1e'; ctx.lineWidth = 4; ctx.beginPath(); ctx.moveTo(-4, 0); ctx.lineTo(28, 0); ctx.stroke(); ctx.fillStyle = w.color; ctx.beginPath(); ctx.moveTo(22, 0); ctx.quadraticCurveTo(24, -16, 34, -14); ctx.lineTo(36, 0); ctx.lineTo(34, 14); ctx.quadraticCurveTo(24, 16, 22, 0); ctx.fill(); ctx.strokeStyle = '#6b727c'; ctx.lineWidth = 1.2; ctx.stroke(); break;
      case 'spear': ctx.strokeStyle = '#a07a3a'; ctx.lineWidth = 3.5; ctx.beginPath(); ctx.moveTo(-10, 0); ctx.lineTo(56, 0); ctx.stroke(); ctx.fillStyle = '#e6ecf2'; ctx.beginPath(); ctx.moveTo(54, -4.5); ctx.lineTo(70, 0); ctx.lineTo(54, 4.5); ctx.closePath(); ctx.fill(); ctx.strokeStyle = '#8c97a3'; ctx.lineWidth = 1; ctx.stroke(); break;
      case 'bow': ctx.strokeStyle = '#8a5a2a'; ctx.lineWidth = 3.2; ctx.beginPath(); ctx.arc(2, 0, 16, -1.2, 1.2); ctx.stroke(); ctx.strokeStyle = '#f2ead8'; ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(2 + Math.cos(-1.2) * 16, Math.sin(-1.2) * 16); ctx.lineTo(swing > 0 ? -4 : 2 + Math.cos(1.2) * 16 - 2, 0); ctx.lineTo(2 + Math.cos(1.2) * 16, Math.sin(1.2) * 16); ctx.stroke(); break;
      case 'gun': ctx.fillStyle = '#2d3138'; ctx.fillRect(-2, -3.5, 14, 7); ctx.fillStyle = '#4a515c'; ctx.fillRect(10, -2, 14, 4); ctx.fillStyle = w.color; ctx.fillRect(4, -2, 5, 2); ctx.fillStyle = '#2d3138'; ctx.fillRect(0, 2, 5, 7); if (swing > 0) { ctx.fillStyle = '#ffe27a'; ctx.beginPath(); ctx.arc(28, 0, 6, 0, TAU); ctx.fill(); } break;
      case 'staff': ctx.strokeStyle = '#6a4a8a'; ctx.lineWidth = 3.5; ctx.beginPath(); ctx.moveTo(-8, 0); ctx.lineTo(34, 0); ctx.stroke(); { const gr = ctx.createRadialGradient(37, 0, 1, 37, 0, 12); gr.addColorStop(0, '#fff'); gr.addColorStop(0.4, '#d29bff'); gr.addColorStop(1, 'rgba(180,100,255,0)'); ctx.fillStyle = gr; ctx.beginPath(); ctx.arc(37, 0, 12, 0, TAU); ctx.fill(); } break;
      case 'hammer': ctx.strokeStyle = '#7a4a1e'; ctx.lineWidth = 4; ctx.beginPath(); ctx.moveTo(-6, 0); ctx.lineTo(30, 0); ctx.stroke(); ctx.fillStyle = '#4f5560'; ctx.fillRect(26, -11, 16, 22); ctx.fillStyle = w.color; ctx.fillRect(26, -11, 16, 6); ctx.strokeStyle = '#2c3037'; ctx.lineWidth = 1.5; ctx.strokeRect(26, -11, 16, 22); break;
      case 'flame': ctx.fillStyle = '#c4452a'; ctx.fillRect(-8, -5, 10, 10); ctx.fillStyle = '#3b3f47'; ctx.fillRect(2, -2.5, 20, 5); ctx.fillStyle = '#ff9a2e'; ctx.beginPath(); ctx.arc(24, 0, 3.5, 0, TAU); ctx.fill(); break;
      default: break;
    }
  }
  drawFighter(f) {
    const ctx = this.ctx, L = f.look, g = this.game;
    const drop = f.dropT > 0 ? f.dropT / 1.3 : 0;
    if (!f.alive) {
      const a = 1 - f.corpseT / 4; if (a <= 0) return;
      ctx.globalAlpha = a * 0.8; ctx.fillStyle = 'rgba(0,0,0,0.3)'; ctx.beginPath(); ctx.ellipse(f.x, f.y + 4, 16, 8, 0, 0, TAU); ctx.fill();
      ctx.fillStyle = L.shirtDark; ctx.beginPath(); ctx.ellipse(f.x, f.y, 12, 8, 0.3, 0, TAU); ctx.fill();
      ctx.fillStyle = L.skin; ctx.beginPath(); ctx.arc(f.x + 10, f.y - 2, 6, 0, TAU); ctx.fill();
      ctx.strokeStyle = '#222'; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(f.x + 7, f.y - 5); ctx.lineTo(f.x + 12, f.y); ctx.moveTo(f.x + 12, f.y - 5); ctx.lineTo(f.x + 7, f.y); ctx.stroke();
      ctx.globalAlpha = 1; return;
    }
    // sombra
    ctx.fillStyle = `rgba(0,0,0,${0.3 - drop * 0.15})`; ctx.beginPath(); ctx.ellipse(f.x, f.y + 8, 13 * (1 - drop * 0.4), 6, 0, 0, TAU); ctx.fill();
    const bob = Math.abs(Math.sin(f.animT)) * 2.2, yo = -drop * 520 - bob;
    const hiddenA = f.hidden ? 0.35 : 1;
    ctx.save(); ctx.translate(f.x, f.y + yo); ctx.globalAlpha = hiddenA;
    // aura de fúria
    if (f.rageT > 0) { const gr = ctx.createRadialGradient(0, 0, 4, 0, 0, 34); gr.addColorStop(0, 'rgba(255,60,40,0.55)'); gr.addColorStop(1, 'rgba(255,60,40,0)'); ctx.fillStyle = gr; ctx.beginPath(); ctx.arc(0, 0, 34 + Math.sin(this.t * 12) * 3, 0, TAU); ctx.fill(); }
    // rastro da investida
    if (f.dashT > 0) { ctx.fillStyle = 'rgba(255,255,255,0.18)'; ctx.beginPath(); ctx.ellipse(-Math.cos(f.dashAng) * 14, -Math.sin(f.dashAng) * 14, 14, 10, f.dashAng, 0, TAU); ctx.fill(); }
    ctx.rotate(f.facing);
    const step = Math.sin(f.animT) * 5, moving = Math.hypot(f.vx, f.vy) > 12;
    // pernas
    ctx.fillStyle = L.pants; ctx.beginPath(); ctx.ellipse(moving ? step : 0, -4.5, 5.5, 3.6, 0, 0, TAU); ctx.ellipse(moving ? -step : 0, 4.5, 5.5, 3.6, 0, 0, TAU); ctx.fill();
    // arma / braços (atrás do corpo na animação de golpe)
    const w = WEAPONS[f.weapon];
    let swingAng = 0;
    if (f.swingT > 0) {
      const p = 1 - f.swingT / f.swingMax;
      if (w.type === 'melee') {
        if (w.aoe) swingAng = -1.3 + p * 1.9;
        else { const arc = Math.min(w.arc, 2.4); swingAng = -arc / 2 + p * arc; if (f.weapon === 'spear') swingAng = 0; }
      }
    }
    const thrust = f.weapon === 'spear' && f.swingT > 0 ? Math.sin((1 - f.swingT / f.swingMax) * Math.PI) * 18 : 0;
    // arco de golpe
    if (f.swingT > 0 && w.type === 'melee' && !w.aoe && f.weapon !== 'spear') {
      const p = 1 - f.swingT / f.swingMax;
      ctx.strokeStyle = `rgba(255,255,255,${0.55 * (1 - p)})`; ctx.lineWidth = 6; ctx.beginPath(); ctx.arc(0, 0, w.range * 0.75, -w.arc / 2, -w.arc / 2 + p * w.arc); ctx.stroke();
    }
    ctx.save(); ctx.translate(9 + thrust, 7); ctx.rotate(swingAng);
    this.drawWeaponShape(f.weapon, f.swingT);
    ctx.restore();
    // corpo
    ctx.fillStyle = L.shirt; ctx.beginPath(); ctx.ellipse(0, 0, 8.5, 12.5, 0, 0, TAU); ctx.fill();
    ctx.fillStyle = L.shirtDark; ctx.beginPath(); ctx.ellipse(-3, 0, 4, 11, 0, 0, TAU); ctx.fill();
    ctx.strokeStyle = 'rgba(0,0,0,0.35)'; ctx.lineWidth = 1.2; ctx.beginPath(); ctx.ellipse(0, 0, 8.5, 12.5, 0, 0, TAU); ctx.stroke();
    // braços
    ctx.fillStyle = L.skin; ctx.beginPath(); ctx.arc(9 + thrust * 0.8, 7, 3.4, 0, TAU); ctx.arc(7, -8, 3.4, 0, TAU); ctx.fill();
    // cabeça
    ctx.fillStyle = L.skin; ctx.beginPath(); ctx.arc(1, 0, 8, 0, TAU); ctx.fill();
    ctx.fillStyle = L.hair; ctx.beginPath();
    if (L.style === 0) ctx.arc(-0.5, 0, 8.3, 1.25, TAU - 1.25); else if (L.style === 1) { ctx.arc(0, 0, 8.6, 0.9, TAU - 0.9); } else { ctx.arc(-0.5, 0, 8.3, 1.8, TAU - 1.8); ctx.rect(-8, -3, 6, 6); }
    ctx.fill();
    ctx.fillStyle = '#222'; ctx.beginPath(); ctx.arc(6.2, -2.8, 1.2, 0, TAU); ctx.arc(6.2, 2.8, 1.2, 0, TAU); ctx.fill();
    ctx.restore(); ctx.globalAlpha = 1;
    // escudo
    if (f.shield > 0) { const a = 0.25 + 0.15 * Math.sin(this.t * 6); ctx.fillStyle = `rgba(110,200,255,${a})`; ctx.strokeStyle = 'rgba(160,225,255,0.85)'; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(f.x, f.y + yo, 22, 0, TAU); ctx.fill(); ctx.stroke(); }
    if (f.invuln > 0 && f.invuln < 50 && f.dropT <= 0 && g.phase === 'playing') { ctx.strokeStyle = `rgba(255,255,255,${0.4 + 0.3 * Math.sin(this.t * 14)})`; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(f.x, f.y + yo, 20, 0, TAU); ctx.stroke(); }
    if (f.hitFlash > 0) { ctx.fillStyle = `rgba(255,255,255,${f.hitFlash * 5})`; ctx.beginPath(); ctx.arc(f.x, f.y + yo, 15, 0, TAU); ctx.fill(); }
    // coroa do vencedor
    if (g.winner === f) {
      const cy = f.y - 28 + Math.sin(this.t * 4) * 3;
      ctx.fillStyle = '#ffd34d'; ctx.strokeStyle = '#a77b0c'; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.moveTo(f.x - 11, cy); ctx.lineTo(f.x - 11, cy - 12); ctx.lineTo(f.x - 5, cy - 6); ctx.lineTo(f.x, cy - 15); ctx.lineTo(f.x + 5, cy - 6); ctx.lineTo(f.x + 11, cy - 12); ctx.lineTo(f.x + 11, cy); ctx.closePath(); ctx.fill(); ctx.stroke();
    }
  }
  drawMonster(m) {
    const ctx = this.ctx, T = m.type;
    if (!m.alive) { const a = 1 - m.deadT / 1.5; ctx.globalAlpha = Math.max(0, a); }
    const sp = Math.min(1, m.spawnT > 0 ? 1 - m.spawnT / 0.6 : 1);
    ctx.fillStyle = 'rgba(0,0,0,0.3)'; ctx.beginPath(); ctx.ellipse(m.x, m.y + m.r * 0.6, m.r * 1.0, m.r * 0.45, 0, 0, TAU); ctx.fill();
    ctx.save(); ctx.translate(m.x, m.y - Math.abs(Math.sin(m.animT)) * (T === 'giant' ? 3 : 2)); ctx.rotate(m.facing); ctx.scale(sp, sp);
    const flash = m.hitFlash > 0;
    if (T === 'zombie') {
      const w = Math.sin(m.animT) * 4;
      ctx.fillStyle = '#3f4a38'; ctx.beginPath(); ctx.ellipse(w, -4, 6, 3.5, 0, 0, TAU); ctx.ellipse(-w, 4, 6, 3.5, 0, 0, TAU); ctx.fill();
      ctx.fillStyle = flash ? '#fff' : '#5a6b3f'; ctx.beginPath(); ctx.ellipse(0, 0, 8.5, 12, 0, 0, TAU); ctx.fill();
      ctx.fillStyle = '#3a2f4a'; ctx.fillRect(-6, -9, 9, 5); ctx.fillRect(-4, 3, 8, 5);
      ctx.strokeStyle = '#7fa04f'; ctx.lineWidth = 4; ctx.lineCap = 'round'; const k = m.attackAnim > 0 ? 6 : 0;
      ctx.beginPath(); ctx.moveTo(4, -9); ctx.lineTo(18 + k, -7); ctx.moveTo(4, 9); ctx.lineTo(18 + k, 7); ctx.stroke();
      ctx.fillStyle = flash ? '#fff' : '#8fb85a'; ctx.beginPath(); ctx.arc(1, 0, 8, 0, TAU); ctx.fill();
      ctx.fillStyle = '#c33'; ctx.beginPath(); ctx.arc(6, -3, 1.8, 0, TAU); ctx.arc(6, 3, 1.8, 0, TAU); ctx.fill();
      ctx.fillStyle = '#2a3a20'; ctx.fillRect(7, -1, 3, 2);
    } else if (T === 'wolf') {
      const w = Math.sin(m.animT * 1.4) * 5;
      ctx.fillStyle = '#4b4f57'; ctx.beginPath(); ctx.ellipse(w, -6, 5, 2.5, 0, 0, TAU); ctx.ellipse(-w, 6, 5, 2.5, 0, 0, TAU); ctx.ellipse(-w - 8, -6, 5, 2.5, 0, 0, TAU); ctx.ellipse(w - 8, 6, 5, 2.5, 0, 0, TAU); ctx.fill();
      ctx.strokeStyle = '#6b7079'; ctx.lineWidth = 4; ctx.beginPath(); ctx.moveTo(-12, 0); ctx.quadraticCurveTo(-20, Math.sin(this.t * 10) * 5, -24, Math.sin(this.t * 10) * 7); ctx.stroke();
      ctx.fillStyle = flash ? '#fff' : '#7b8089'; ctx.beginPath(); ctx.ellipse(-2, 0, 14, 8, 0, 0, TAU); ctx.fill();
      ctx.fillStyle = flash ? '#fff' : '#8d939c'; ctx.beginPath(); ctx.ellipse(12, 0, 7, 6, 0, 0, TAU); ctx.fill();
      ctx.beginPath(); ctx.moveTo(14, -3); ctx.lineTo(22, 0); ctx.lineTo(14, 3); ctx.fill();
      ctx.fillStyle = '#6b7079'; ctx.beginPath(); ctx.moveTo(8, -5); ctx.lineTo(5, -11); ctx.lineTo(12, -6); ctx.moveTo(8, 5); ctx.lineTo(5, 11); ctx.lineTo(12, 6); ctx.fill();
      ctx.fillStyle = '#ff3b3b'; ctx.beginPath(); ctx.arc(13, -2.5, 1.5, 0, TAU); ctx.arc(13, 2.5, 1.5, 0, TAU); ctx.fill();
      ctx.fillStyle = '#111'; ctx.beginPath(); ctx.arc(22, 0, 1.8, 0, TAU); ctx.fill();
    } else {
      const wind = m.windup > 0 ? 1 - m.windup / 0.85 : 0;
      ctx.scale(2.4, 2.4);
      ctx.fillStyle = '#3a2a35'; ctx.beginPath(); ctx.ellipse(Math.sin(m.animT) * 4, -6, 7, 4.5, 0, 0, TAU); ctx.ellipse(-Math.sin(m.animT) * 4, 6, 7, 4.5, 0, 0, TAU); ctx.fill();
      ctx.fillStyle = flash ? '#fff' : '#6b3f55'; ctx.beginPath(); ctx.ellipse(0, 0, 10.5, 14, 0, 0, TAU); ctx.fill();
      ctx.fillStyle = '#8a5570'; ctx.beginPath(); ctx.ellipse(-2, 0, 5, 11, 0, 0, TAU); ctx.fill();
      // clava
      ctx.save(); ctx.translate(10, 10); ctx.rotate(-1.3 + wind * 2.2); ctx.fillStyle = '#6b4a2a'; ctx.fillRect(-2, -2.5, 28, 5); ctx.fillStyle = '#4a3320'; ctx.beginPath(); ctx.ellipse(28, 0, 7, 6, 0, 0, TAU); ctx.fill(); ctx.fillStyle = '#bbb'; for (let i = 0; i < 4; i++) { ctx.beginPath(); ctx.arc(28 + Math.cos(i * 1.6) * 6, Math.sin(i * 1.6) * 5, 1.6, 0, TAU); ctx.fill(); } ctx.restore();
      ctx.fillStyle = '#8a5570'; ctx.beginPath(); ctx.arc(10, -10, 4, 0, TAU); ctx.fill();
      ctx.fillStyle = flash ? '#fff' : '#9b6a84'; ctx.beginPath(); ctx.arc(2, 0, 8, 0, TAU); ctx.fill();
      ctx.fillStyle = '#eee'; ctx.beginPath(); ctx.moveTo(0, -6); ctx.lineTo(-4, -13); ctx.lineTo(3, -8); ctx.moveTo(0, 6); ctx.lineTo(-4, 13); ctx.lineTo(3, 8); ctx.fill();
      ctx.fillStyle = '#ffd23a'; ctx.beginPath(); ctx.arc(7, -3, 1.8, 0, TAU); ctx.arc(7, 3, 1.8, 0, TAU); ctx.fill();
    }
    ctx.restore(); ctx.globalAlpha = 1;
  }
  drawProjectiles(g) {
    const ctx = this.ctx, v = this.view;
    for (const p of g.combat.projectiles) {
      if (p.x < v.x0 || p.x > v.x1 || p.y < v.y0 || p.y > v.y1) continue;
      ctx.save(); ctx.translate(p.x, p.y); ctx.rotate(p.ang);
      if (p.kind === 'arrow') { ctx.strokeStyle = '#8a6a3a'; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(-14, 0); ctx.lineTo(8, 0); ctx.stroke(); ctx.fillStyle = '#dde3ea'; ctx.beginPath(); ctx.moveTo(8, -3); ctx.lineTo(14, 0); ctx.lineTo(8, 3); ctx.fill(); ctx.strokeStyle = '#d24'; ctx.beginPath(); ctx.moveTo(-14, 0); ctx.lineTo(-18, -3); ctx.moveTo(-14, 0); ctx.lineTo(-18, 3); ctx.stroke(); }
      else if (p.kind === 'bullet') { const gr = ctx.createLinearGradient(-16, 0, 6, 0); gr.addColorStop(0, 'rgba(255,230,120,0)'); gr.addColorStop(1, '#fff6b0'); ctx.strokeStyle = gr; ctx.lineWidth = 3.5; ctx.beginPath(); ctx.moveTo(-16, 0); ctx.lineTo(6, 0); ctx.stroke(); }
      else if (p.kind === 'orb') { const gr = ctx.createRadialGradient(0, 0, 1, 0, 0, 14); gr.addColorStop(0, '#fff'); gr.addColorStop(0.4, '#d29bff'); gr.addColorStop(1, 'rgba(170,90,255,0)'); ctx.fillStyle = gr; ctx.beginPath(); ctx.arc(0, 0, 14, 0, TAU); ctx.fill(); }
      else if (p.kind === 'flame') { ctx.fillStyle = 'rgba(255,170,40,0.25)'; ctx.beginPath(); ctx.arc(0, 0, 10, 0, TAU); ctx.fill(); }
      ctx.restore();
    }
  }
  drawParticles(g) {
    const ctx = this.ctx, v = this.view;
    for (const r of g.fx.rings) {
      const p = 1 - r.life / r.max; ctx.globalAlpha = (1 - p) * 0.9; ctx.strokeStyle = r.color; ctx.lineWidth = r.width * (1 - p * 0.5);
      ctx.beginPath(); ctx.arc(r.x, r.y, r.r0 + (r.r1 - r.r0) * p, 0, TAU); ctx.stroke();
    }
    for (const p of g.fx.parts) {
      if (p.x < v.x0 || p.x > v.x1 || p.y < v.y0 || p.y > v.y1) continue;
      const a = p.life / p.max;
      if (p.kind === 'fire') {
        const r = p.size * (0.5 + (1 - a) * 0.8); const gr = ctx.createRadialGradient(p.x, p.y, 2, p.x, p.y, r);
        gr.addColorStop(0, `rgba(255,250,200,${a})`); gr.addColorStop(0.4, `rgba(255,150,40,${a * 0.9})`); gr.addColorStop(1, 'rgba(255,60,0,0)');
        ctx.globalAlpha = 1; ctx.fillStyle = gr; ctx.beginPath(); ctx.arc(p.x, p.y, r, 0, TAU); ctx.fill(); continue;
      }
      ctx.globalAlpha = p.kind === 'smoke' ? a * 0.6 : a;
      ctx.fillStyle = p.color; ctx.beginPath(); ctx.arc(p.x, p.y, Math.max(0.5, p.size), 0, TAU); ctx.fill();
    }
    ctx.globalAlpha = 1;
  }

  // ======================= sobreposições =======================
  drawZone(g) {
    const ctx = this.ctx, cam = this.cam, z = cam.zoom, z0 = g.zone;
    if (g.phase === 'lobby') return;
    const cx = (z0.cx - cam.x) * z + this.vw / 2, cy = (z0.cy - cam.y) * z + this.vh / 2, r = z0.r * z;
    ctx.save();
    ctx.beginPath(); ctx.rect(0, 0, this.vw, this.vh); ctx.arc(cx, cy, Math.max(1, r), 0, TAU, true);
    ctx.fillStyle = 'rgba(160,15,40,0.28)'; ctx.fill('evenodd');
    ctx.restore();
    const pulse = 0.6 + 0.4 * Math.sin(this.t * 5);
    ctx.strokeStyle = `rgba(255,80,110,${0.55 + 0.35 * pulse})`; ctx.lineWidth = Math.max(3, 6 * z); ctx.beginPath(); ctx.arc(cx, cy, Math.max(1, r), 0, TAU); ctx.stroke();
    if (!z0.overtime && (z0.phase === 'shrink' || z0.timer < 25)) {
      const nx = (z0.nx - cam.x) * z + this.vw / 2, ny = (z0.ny - cam.y) * z + this.vh / 2;
      ctx.strokeStyle = 'rgba(255,255,255,0.8)'; ctx.lineWidth = Math.max(2, 3 * z); ctx.setLineDash([16, 12]); ctx.beginPath(); ctx.arc(nx, ny, Math.max(1, z0.nr * z), 0, TAU); ctx.stroke(); ctx.setLineDash([]);
    }
  }
  drawWeather(g, dt) {
    const ctx = this.ctx, st = g.events.stormT;
    if (st <= 0) return;
    const k = Math.min(1, st / 3, (30 - st) / 2 + 0.3);
    ctx.fillStyle = `rgba(15,25,55,${0.32 * Math.min(1, k)})`; ctx.fillRect(0, 0, this.vw, this.vh);
    ctx.strokeStyle = 'rgba(190,215,255,0.5)'; ctx.lineWidth = 1.4; ctx.beginPath();
    for (const d of this.rain) {
      d.y += dt * 1.6 * d.s; d.x -= dt * 0.35 * d.s; if (d.y > 1) { d.y = -0.05; d.x = Math.random() * 1.2; }
      const px = d.x * this.vw, py = d.y * this.vh; ctx.moveTo(px, py); ctx.lineTo(px - 7, py + 20);
    }
    ctx.stroke();
  }
  /** efeito ambiente do mapa: neve caindo / poeira do deserto */
  drawAmbient(dt) {
    const kind = this.map.theme.visual.ambient;
    if (kind === 'none' || !this.game.fx.enabled) return;
    const ctx = this.ctx, N = kind === 'snow' ? 110 : 40;
    if (!this.flakes) this.flakes = Array.from({ length: N }, () => ({ x: Math.random(), y: Math.random(), s: 0.5 + Math.random(), p: Math.random() * 6 }));
    if (kind === 'snow') {
      ctx.fillStyle = 'rgba(255,255,255,0.85)';
      for (const f of this.flakes) {
        f.y += dt * 0.06 * f.s; f.p += dt * 1.5; f.x += Math.sin(f.p) * dt * 0.02 - dt * 0.01;
        if (f.y > 1.02) { f.y = -0.02; f.x = Math.random(); } if (f.x < -0.02) f.x = 1.02;
        ctx.beginPath(); ctx.arc(f.x * this.vw, f.y * this.vh, 1.4 + f.s * 1.6, 0, TAU); ctx.fill();
      }
      ctx.fillStyle = 'rgba(210,230,255,0.07)'; ctx.fillRect(0, 0, this.vw, this.vh);
    } else {
      ctx.fillStyle = 'rgba(120,80,30,0.55)';
      for (const f of this.flakes) {
        f.x += dt * 0.12 * f.s; f.y += Math.sin(f.p) * dt * 0.01; f.p += dt;
        if (f.x > 1.02) { f.x = -0.02; f.y = Math.random(); }
        ctx.fillRect(f.x * this.vw, f.y * this.vh, 2 + f.s, 1.5);
      }
      ctx.fillStyle = 'rgba(255,190,90,0.05)'; ctx.fillRect(0, 0, this.vw, this.vh);
    }
  }
  drawVignette() {
    const ctx = this.ctx;
    if (!this.vignette) {
      const c = document.createElement('canvas'); c.width = this.vw; c.height = this.vh; const x = c.getContext('2d');
      const gr = x.createRadialGradient(this.vw / 2, this.vh / 2, Math.min(this.vw, this.vh) * 0.35, this.vw / 2, this.vh / 2, Math.hypot(this.vw, this.vh) * 0.55);
      gr.addColorStop(0, 'rgba(0,0,0,0)'); gr.addColorStop(1, 'rgba(0,0,0,0.55)'); x.fillStyle = gr; x.fillRect(0, 0, this.vw, this.vh);
      this.vignette = c;
    }
    ctx.drawImage(this.vignette, 0, 0);
  }
  worldToScreen(x, y) { const z = this.cam.zoom; return [(x - this.cam.x) * z + this.vw / 2, (y - this.cam.y) * z + this.vh / 2]; }
  drawLabels(g) {
    const ctx = this.ctx, z = this.cam.zoom;
    this.rankT -= 1;
    if (this.rankT <= 0) { this.rankT = 15; const rk = computeRanking(g); this.rank.clear(); rk.all.forEach((f, i) => this.rank.set(f.id, i + 1)); }
    const fs = clamp(12 * Math.pow(z, 0.35) * (this.vw / 1920 + 0.45), 10, 17);
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.lineJoin = 'round';
    for (const f of g.fighters) {
      if (!f.alive || (f.hidden && g.cameraMode !== 'overview')) continue;
      const [sx, sy0] = this.worldToScreen(f.x, f.y);
      if (sx < -80 || sx > this.vw + 80 || sy0 < -80 || sy0 > this.vh + 80) continue;
      const drop = f.dropT > 0 ? f.dropT / 1.3 : 0;
      const sy = sy0 - (f.r + 28) * z - drop * 520 * z;
      const B = BEHAVIORS[f.behavior];
      const rk = this.rank.get(f.id) || 0;
      ctx.font = `700 ${fs}px "Segoe UI", system-ui, sans-serif`;
      const bd = g.ranking && g.ranking.badgeOf(f.id); // emblema do nível do espectador (Prata ou acima)
      const label = bd ? `${bd.icon} ${f.name}` : f.name;
      const tw = ctx.measureText(label).width;
      ctx.lineWidth = 4; ctx.strokeStyle = 'rgba(0,0,0,0.85)'; ctx.fillStyle = bd && bd.index >= 3 ? bd.color : '#fff';
      ctx.strokeText(label, sx, sy - fs * 0.9); ctx.fillText(label, sx, sy - fs * 0.9);
      // posição no ranking e abates
      ctx.font = `800 ${fs * 0.8}px "Segoe UI", system-ui, sans-serif`;
      ctx.fillStyle = B.color; ctx.textAlign = 'right'; ctx.strokeText(`#${rk}`, sx - tw / 2 - 5, sy - fs * 0.9); ctx.fillText(`#${rk}`, sx - tw / 2 - 5, sy - fs * 0.9);
      if (f.kills > 0) { ctx.fillStyle = '#ffd34d'; ctx.textAlign = 'left'; ctx.strokeText(`⚔${f.kills}`, sx + tw / 2 + 5, sy - fs * 0.9); ctx.fillText(`⚔${f.kills}`, sx + tw / 2 + 5, sy - fs * 0.9); }
      ctx.textAlign = 'center';
      // barras
      const bw = Math.max(38, 54 * Math.pow(z, 0.5)), bh = Math.max(5, 7 * Math.pow(z, 0.5)), bx = sx - bw / 2, by = sy - fs * 0.2;
      ctx.fillStyle = 'rgba(0,0,0,0.65)'; ctx.fillRect(bx - 1.5, by - 1.5, bw + 3, bh + 3);
      const p = clamp(f.hp / f.maxHp, 0, 1);
      ctx.fillStyle = p > 0.6 ? '#46d65a' : p > 0.3 ? '#f2c230' : '#ef4545'; ctx.fillRect(bx, by, bw * p, bh);
      if (f.shield > 0) { ctx.fillStyle = 'rgba(120,200,255,0.9)'; ctx.fillRect(bx, by, bw * clamp(f.shield / 100, 0, 1), Math.max(2, bh * 0.4)); }
      ctx.fillStyle = '#4db8ff'; ctx.fillRect(bx, by + bh + 1.5, bw * clamp(f.energy / f.maxEnergy, 0, 1), 2);
    }
    // vida dos monstros
    for (const m of g.monsters) {
      if (!m.alive || (m.type !== 'giant' && m.hp >= m.maxHp)) continue;
      const [sx, sy0] = this.worldToScreen(m.x, m.y);
      if (sx < -80 || sx > this.vw + 80 || sy0 < -120 || sy0 > this.vh + 80) continue;
      const big = m.type === 'giant', bw = big ? 120 : 34, sy = sy0 - (m.r * (big ? 1.5 : 1) + 18) * z;
      if (big) { ctx.font = `800 ${fs + 3}px "Segoe UI", system-ui, sans-serif`; ctx.lineWidth = 4; ctx.strokeStyle = '#000'; ctx.fillStyle = '#ff6b8b'; ctx.strokeText('👹 MONSTRO GIGANTE', sx, sy - 12); ctx.fillText('👹 MONSTRO GIGANTE', sx, sy - 12); }
      ctx.fillStyle = 'rgba(0,0,0,0.7)'; ctx.fillRect(sx - bw / 2 - 1.5, sy - 1.5, bw + 3, (big ? 9 : 5) + 3);
      ctx.fillStyle = big ? '#d63a6a' : '#e0743a'; ctx.fillRect(sx - bw / 2, sy, bw * clamp(m.hp / m.maxHp, 0, 1), big ? 9 : 5);
    }
  }
  drawFloatTexts(g) {
    const ctx = this.ctx, z = this.cam.zoom;
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.lineJoin = 'round';
    for (const t of g.fx.texts) {
      const [sx, sy] = this.worldToScreen(t.x, t.y);
      if (sx < -40 || sx > this.vw + 40 || sy < -40 || sy > this.vh + 40) continue;
      const a = Math.min(1, t.life / 0.35);
      ctx.globalAlpha = a; ctx.font = `800 ${t.size * clamp(Math.pow(z, 0.4), 0.85, 1.2)}px "Segoe UI", system-ui, sans-serif`;
      ctx.lineWidth = 3.5; ctx.strokeStyle = 'rgba(0,0,0,0.9)'; ctx.strokeText(t.str, sx, sy); ctx.fillStyle = t.color; ctx.fillText(t.str, sx, sy);
    }
    ctx.globalAlpha = 1;
  }

  // ======================= minimapa =======================
  drawMinimap(mc, size) {
    const g = this.game, S = size / MAP_W, z = g.zone;
    mc.clearRect(0, 0, size, size);
    mc.drawImage(this.mini, 0, 0, size, size);
    mc.fillStyle = 'rgba(0,0,0,0.15)'; mc.fillRect(0, 0, size, size);
    if (g.phase !== 'lobby') {
      mc.save(); mc.beginPath(); mc.rect(0, 0, size, size); mc.arc(z.cx * S, z.cy * S, z.r * S, 0, TAU, true); mc.fillStyle = 'rgba(190,20,50,0.35)'; mc.fill('evenodd'); mc.restore();
      mc.strokeStyle = '#ff5a7a'; mc.lineWidth = 2; mc.beginPath(); mc.arc(z.cx * S, z.cy * S, z.r * S, 0, TAU); mc.stroke();
      if (!z.overtime) { mc.strokeStyle = '#fff'; mc.lineWidth = 1; mc.setLineDash([4, 3]); mc.beginPath(); mc.arc(z.nx * S, z.ny * S, z.nr * S, 0, TAU); mc.stroke(); mc.setLineDash([]); }
    }
    for (const c of g.items.crates) { mc.fillStyle = c.golden ? '#ffd34d' : '#d9a05a'; mc.fillRect(c.x * S - 2.5, c.y * S - 2.5, 5, 5); }
    for (const m of g.monsters) if (m.alive) { mc.fillStyle = m.type === 'giant' ? '#ff2f6a' : '#9c4f4f'; const r = m.type === 'giant' ? 4.5 : 1.8; mc.beginPath(); mc.arc(m.x * S, m.y * S, r, 0, TAU); mc.fill(); }
    for (const f of g.fighters) if (f.alive) { mc.fillStyle = '#fff'; mc.beginPath(); mc.arc(f.x * S, f.y * S, 3.2, 0, TAU); mc.fill(); mc.fillStyle = f.look.accent; mc.beginPath(); mc.arc(f.x * S, f.y * S, 2.2, 0, TAU); mc.fill(); }
    const c = this.cam;
    mc.strokeStyle = 'rgba(255,255,255,0.9)'; mc.lineWidth = 1.5; mc.strokeRect((c.x - this.vw / 2 / c.zoom) * S, (c.y - this.vh / 2 / c.zoom) * S, (this.vw / c.zoom) * S, (this.vh / c.zoom) * S);
  }
}
