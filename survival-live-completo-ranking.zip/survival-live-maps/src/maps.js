// Catálogo de mapas: cada tema define como o mundo é gerado (gen) e como é desenhado (visual).
// O mapa "forest" reproduz exatamente os valores originais do jogo.
// Para criar um novo mapa, copie um tema abaixo, mude o id/nome/valores e adicione em MAPS.

const FOREST = {
  id: 'forest', icon: '🌲', name: 'Floresta Sombria',
  desc: 'O mapa clássico: florestas densas, vilas abandonadas, lagos, rio raso e pântanos tóxicos.',
  hazard: 'Pântano tóxico',
  gen: { lakes: 4, lakeRx: [150, 260], lakeRy: [110, 200], river: true, swamps: 4, swampR: [110, 190], mountains: 5, mountR: [100, 170], villages: 5, houseMin: 3, houseVar: 3, rocks: 90, forests: 12, forestR: [200, 320], forestDensity: 5.5, scatterTrees: 160, bushes: 70 },
  visual: {
    trees: 'forest', ambient: 'none', bubbles: ['#b6ff7a', '#d29bff'], bush: ['#2c7a3a', '#3f9a4a', '#62bd5a'],
    rock: { c0: '#b9bec6', c1: '#656b75', line: '#3f444c', cap: false },
    mountain: { g0: '#a9aeb6', g1: '#767c86', g2: '#474c55', stroke: '#32363d', ridge: 'rgba(40,44,52,0.55)', cap: '#f4f8ff', capScale: 1 },
    house: { wall: '#6e5a46', roofs: [['#8a3b2a', '#a74a35', '#5e2a1e'], ['#59616b', '#6e7884', '#3d434b'], ['#4f6b3a', '#668a4a', '#33472a']], holes: 3, moss: 'rgba(90,140,60,0.55)', snow: false },
    ground: {
      base: '#4f8f3a', blotchLight: 'rgba(130,190,80,0.22)', blotchDark: 'rgba(30,90,40,0.22)', tuft: 'grass', tuftA: 'rgba(35,100,40,0.55)', tuftB: 'rgba(150,210,100,0.4)',
      path: ['#8a6a3f', '#a98450'], yard: 'rgba(150,115,70,0.85)',
      river: ['#cdbb86', '#3f8fbf', '#5db4de'], riverHl: 'rgba(255,255,255,0.35)',
      lake: { rim: '#d7c58f', g: ['#3a9ad0', '#1f6fa6', '#17598a'], arcs: 'rgba(255,255,255,0.28)' },
      swamp: { g: ['#4a3a66', '#3d5a3a', 'rgba(60,80,40,0)'], dots: ['rgba(160,255,120,0.5)', 'rgba(190,120,255,0.5)'] },
      plaza: { g: ['#9b9486', '#8a8374', 'rgba(138,131,116,0)'], line: 'rgba(70,64,54,0.5)' },
      deco: ['#ffe36a', '#ff8fb3', '#ffffff', '#b58cff'], decoN: 900, edge: 'rgba(10,20,10,0.75)',
    },
  },
};

const DESERT = {
  id: 'desert', icon: '🏜️', name: 'Deserto das Ruínas',
  desc: 'Dunas abertas com pouca cobertura: cactos, palmeiras em oásis, mesas de arenito, ruínas e areia movediça.',
  hazard: 'Areia movediça',
  gen: { lakes: 3, lakeRx: [90, 150], lakeRy: [70, 120], river: true, swamps: 5, swampR: [100, 170], mountains: 6, mountR: [90, 160], villages: 4, houseMin: 3, houseVar: 3, rocks: 110, forests: 7, forestR: [130, 230], forestDensity: 7, scatterTrees: 130, bushes: 36 },
  visual: {
    trees: 'desert', ambient: 'dust', bubbles: ['#ffd27a', '#7a5230'], bush: ['#8f7a3f', '#b49a56', '#d4bc7a'],
    rock: { c0: '#e0b27a', c1: '#9a6a3a', line: '#6b4524', cap: false },
    mountain: { g0: '#e3a46c', g1: '#b8743f', g2: '#7a4a26', stroke: '#5a3418', ridge: 'rgba(90,45,15,0.5)', cap: '#f0cf98', capScale: 0.7 },
    house: { wall: '#c7a26a', roofs: [['#b8794a', '#d09560', '#7d4f2c'], ['#a69070', '#c0aa88', '#6d5e46'], ['#9c6a44', '#b8835a', '#6b4630']], holes: 5, moss: 'rgba(238,212,150,0.65)', snow: false },
    ground: {
      base: '#d9b46c', blotchLight: 'rgba(246,220,155,0.32)', blotchDark: 'rgba(168,118,58,0.26)', tuft: 'ripple', tuftA: 'rgba(160,110,55,0.40)', tuftB: 'rgba(252,232,178,0.50)',
      path: ['#b8915a', '#c9a56c'], yard: 'rgba(196,152,92,0.85)',
      river: ['#c19a5c', '#8a6a3a', '#a2804a'], riverHl: 'rgba(80,50,20,0.35)',
      lake: { rim: '#8fb85a', g: ['#43c4cc', '#2196aa', '#16708a'], arcs: 'rgba(255,255,255,0.3)' },
      swamp: { g: ['#3a2c1f', '#6b4e2e', 'rgba(110,80,40,0)'], dots: ['rgba(255,210,120,0.5)', 'rgba(50,30,15,0.65)'] },
      plaza: { g: ['#cdb07a', '#bc9b64', 'rgba(188,155,100,0)'], line: 'rgba(110,80,40,0.5)' },
      deco: ['#a98457', '#8d6a42', '#e8d3a0', '#c4a070'], decoN: 1100, edge: 'rgba(80,50,20,0.7)',
    },
  },
};

const SNOW = {
  id: 'snow', icon: '❄️', name: 'Montanha Congelada',
  desc: 'Neve, pinheiros carregados, lagos congelados, montanhas gigantes, cabanas e fendas de gelo traiçoeiras.',
  hazard: 'Fenda de gelo',
  gen: { lakes: 5, lakeRx: [120, 230], lakeRy: [90, 170], river: true, swamps: 4, swampR: [100, 170], mountains: 8, mountR: [110, 190], villages: 4, houseMin: 3, houseVar: 2, rocks: 80, forests: 15, forestR: [190, 310], forestDensity: 6, scatterTrees: 140, bushes: 50 },
  visual: {
    trees: 'snow', ambient: 'snow', bubbles: ['#ffffff', '#9fe0ff'], bush: ['#3f6e57', '#6a9c84', '#e6f1f6'],
    rock: { c0: '#dbe6f0', c1: '#7f93aa', line: '#4a5a6e', cap: true },
    mountain: { g0: '#c8d6e6', g1: '#8fa3bb', g2: '#5b6f88', stroke: '#3f4f66', ridge: 'rgba(40,55,80,0.5)', cap: '#ffffff', capScale: 1.9 },
    house: { wall: '#6b4a30', roofs: [['#e4ecf6', '#fbfdff', '#b3c4d8'], ['#d7e2ef', '#f2f7fc', '#a5b8cf'], ['#e9eff7', '#ffffff', '#b9c9dc']], holes: 0, moss: null, snow: true },
    ground: {
      base: '#e4edf5', blotchLight: 'rgba(255,255,255,0.55)', blotchDark: 'rgba(120,160,205,0.25)', tuft: 'sparkle', tuftA: 'rgba(130,170,210,0.45)', tuftB: 'rgba(255,255,255,0.85)',
      path: ['#9fb4c9', '#c3d3e2'], yard: 'rgba(188,204,224,0.85)',
      river: ['#f0f6fb', '#9cc4e4', '#cfe6f6'], riverHl: 'rgba(255,255,255,0.7)',
      lake: { rim: '#f2f7fb', g: ['#b6e0f4', '#78b8de', '#4a8cba'], arcs: 'rgba(255,255,255,0.55)' },
      swamp: { g: ['#16315c', '#4574a6', 'rgba(120,170,210,0)'], dots: ['rgba(255,255,255,0.65)', 'rgba(150,225,255,0.65)'] },
      plaza: { g: ['#c9d6e4', '#b4c4d6', 'rgba(180,196,214,0)'], line: 'rgba(90,110,140,0.5)' },
      deco: ['#ffffff', '#d6ecff', '#bfe0ff', '#f5fbff'], decoN: 1100, edge: 'rgba(30,50,80,0.6)',
    },
  },
};

export const MAPS = { forest: FOREST, desert: DESERT, snow: SNOW };
export const MAP_IDS = ['forest', 'desert', 'snow'];
/** valores aceitos em settings.mapId */
export const MAP_CHOICES = [...MAP_IDS, 'random'];

/** 'random' sorteia um mapa a cada rodada; ids desconhecidos voltam para a floresta */
export function resolveMapId(id) {
  if (id === 'random') return MAP_IDS[Math.floor(Math.random() * MAP_IDS.length)];
  return MAPS[id] ? id : 'forest';
}
