// Telas do ranking de espectadores (usadas no jogo e no painel do streamer).
// Só desenha e encaminha cliques; os dados vêm de RankingSystem/ViewerStore.
import { TABS, SORTS, LEVELS } from './viewers.js';
import { hashStr } from './utils.js';

export const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
export const fmt = (n) => Number(n || 0).toLocaleString('pt-BR');
const PERIODS = { all: 'Geral', week: 'Semana', month: 'Mês' };
const ago = (ts) => {
  const s = Math.max(0, (Date.now() - ts) / 1000);
  return s < 60 ? 'agora' : s < 3600 ? `${Math.floor(s / 60)} min` : s < 86400 ? `${Math.floor(s / 3600)} h` : `${Math.floor(s / 86400)} d`;
};

// ---------- avatar: o mesmo "boneco" do jogo, gerado a partir do nome ----------
const SKINS = ['#f1c9a5', '#e0ac82', '#c68a5e', '#a86a43', '#7d4a2c', '#f6d7bd'];
const HAIRS = ['#2b1d12', '#5a3a1e', '#a8702a', '#d9b45a', '#1b1b1f', '#8a2f1f', '#7d7d86'];
const avCache = new Map();
export function avatarURL(name, size = 64) {
  const k = name.toLowerCase() + '|' + size;
  let u = avCache.get(k);
  if (u) return u;
  try {
    const h = hashStr(name.toLowerCase()), hue = h % 360, c = document.createElement('canvas');
    c.width = c.height = size;
    const x = c.getContext('2d'), s = size / 64;
    const g = x.createLinearGradient(0, 0, 0, size); g.addColorStop(0, `hsl(${hue} 60% 28%)`); g.addColorStop(1, `hsl(${(hue + 40) % 360} 55% 14%)`);
    x.fillStyle = g; x.fillRect(0, 0, size, size);
    x.fillStyle = `hsl(${hue} 72% 52%)`; x.beginPath(); x.ellipse(32 * s, 66 * s, 26 * s, 22 * s, 0, Math.PI, 0); x.fill(); // ombros
    x.fillStyle = `hsl(${hue} 72% 36%)`; x.fillRect(27 * s, 40 * s, 10 * s, 8 * s);
    x.fillStyle = SKINS[h % SKINS.length]; x.beginPath(); x.arc(32 * s, 30 * s, 14 * s, 0, 6.3); x.fill();
    x.fillStyle = HAIRS[(h >> 5) % HAIRS.length]; x.beginPath();
    const st = (h >> 9) % 3;
    if (st === 0) x.arc(32 * s, 27 * s, 14.5 * s, Math.PI, 0); else if (st === 1) { x.arc(32 * s, 26 * s, 15 * s, Math.PI * 0.95, Math.PI * 2.05); x.lineTo(46 * s, 36 * s); x.lineTo(18 * s, 36 * s); } else x.ellipse(32 * s, 22 * s, 15 * s, 9 * s, 0, 0, 6.3);
    x.fill();
    x.fillStyle = '#1b1b1f'; x.beginPath(); x.arc(27 * s, 31 * s, 1.8 * s, 0, 6.3); x.arc(37 * s, 31 * s, 1.8 * s, 0, 6.3); x.fill();
    u = c.toDataURL();
  } catch { u = ''; }
  avCache.set(k, u);
  return u;
}
export const avatar = (name, cls = '', size = 64) => `<img class="rk-av ${cls}" alt="" width="${size}" height="${size}" src="${avatarURL(name, size)}">`;
export const levelTag = (lv, big = false) => `<span class="rk-lv lv-${lv.id}${big ? ' big' : ''}" style="--lc:${lv.color}">${lv.icon} ${lv.name}</span>`;

// ---------- painel do ranking ----------
export class RankingPanel {
  /** mode: 'game' (tela da transmissão) | 'admin' (mais colunas e ações) */
  constructor({ root, ranking, mode = 'game', onOpen }) {
    this.root = root; this.ranking = ranking; this.mode = mode; this.onOpen = onOpen;
    this.tab = 'overall'; this.period = 'all'; this.sort = 'points'; this.search = ''; this.includeSim = true; this.limit = mode === 'game' ? 50 : 200;
    this.dirty = true; this.last = 0;
    this.build();
    ranking.on('change', () => { this.dirty = true; });
    this.timer = setInterval(() => { if (this.dirty && this.visible() && Date.now() - this.last > 700) this.render(); }, 400);
  }
  visible() { return !!(this.root && this.root.offsetParent !== null); }
  build() {
    const r = this.root;
    r.classList.add('rk-panel', 'rk-' + this.mode);
    r.innerHTML = `
      <div class="rk-tabs" data-role="tabs">${Object.entries(TABS).map(([k, t]) => `<button data-tab="${k}">${esc(t.label)}</button>`).join('')}</div>
      <div class="rk-tools">
        <div class="rk-seg" data-role="period">${Object.entries(PERIODS).map(([k, l]) => `<button data-period="${k}">${l}</button>`).join('')}</div>
        <label class="rk-f">Ordenar por <select data-role="sort">${Object.entries(SORTS).map(([k, l]) => `<option value="${k}">${l}</option>`).join('')}</select></label>
        <input data-role="search" type="search" placeholder="🔎 buscar usuário…" autocomplete="off">
        <label class="rk-chk"><input type="checkbox" data-role="sim" checked> simulados</label>
        <span class="rk-count" data-role="count"></span>
      </div>
      <div class="rk-head" data-role="head"></div>
      <div class="rk-list" data-role="list"></div>`;
    const q = (n) => r.querySelector(`[data-role=${n}]`);
    this.el = { tabs: q('tabs'), period: q('period'), sort: q('sort'), search: q('search'), sim: q('sim'), count: q('count'), head: q('head'), list: q('list') };
    r.addEventListener('click', (e) => {
      const t = e.target.closest('[data-tab]'); if (t) { this.tab = t.dataset.tab; this.sort = TABS[this.tab].sort; this.el.sort.value = this.sort; return this.render(); }
      const p = e.target.closest('[data-period]'); if (p) { this.period = p.dataset.period; return this.render(); }
      const h = e.target.closest('[data-sort]'); if (h) { this.sort = h.dataset.sort; this.el.sort.value = this.sort; return this.render(); }
      const row = e.target.closest('[data-key]'); if (row && this.onOpen) this.onOpen(row.dataset.key);
    });
    this.el.sort.onchange = () => { this.sort = this.el.sort.value; this.render(); };
    let st = 0; this.el.search.oninput = () => { clearTimeout(st); st = setTimeout(() => { this.search = this.el.search.value; this.render(); }, 120); };
    this.el.sim.onchange = () => { this.includeSim = this.el.sim.checked; this.render(); };
    this.render();
  }
  rows() { return this.ranking.store.board({ period: this.period, sort: this.sort, includeSim: this.includeSim, search: this.search, limit: this.limit }); }
  render() {
    this.dirty = false; this.last = Date.now();
    const { el } = this, admin = this.mode === 'admin';
    el.tabs.querySelectorAll('button').forEach((b) => b.classList.toggle('on', b.dataset.tab === this.tab));
    el.period.querySelectorAll('button').forEach((b) => b.classList.toggle('on', b.dataset.period === this.period));
    const cols = [['points', 'Pontos'], ['kills', '⚔ Elim.'], ['wins', '🏆 Vit.'], ['matches', '🎮 Partidas'], ['gifts', '🎁 Presentes']];
    el.head.innerHTML = `<span class="c-pos">#</span><span class="c-name">Espectador</span>` +
      cols.map(([k, l]) => `<button class="c-${k} ${this.sort === k ? 'on' : ''}" data-sort="${k}">${l}${this.sort === k ? ' ▾' : ''}</button>`).join('') + (admin ? '<span class="c-wr">Vitória %</span>' : '');
    const rows = this.rows();
    el.count.textContent = `${rows.length} espectador${rows.length === 1 ? '' : 'es'}${this.period === 'all' ? '' : ' no período'}`;
    if (!rows.length) { el.list.innerHTML = `<div class="rk-empty">${this.search ? 'Nenhum espectador encontrado.' : 'Ainda não há pontuação. Comente <b>!entrar</b> para aparecer aqui!'}</div>`; return; }
    el.list.innerHTML = rows.map((r) => {
      const top = r.rank;
      const cls = `rk-row lv-${r.level.id}${top <= 3 && !this.search ? ' top' + top : ''}`;
      const medal = top === 1 ? '🥇' : top === 2 ? '🥈' : top === 3 ? '🥉' : top;
      const wr = r.matches ? Math.round((r.wins / r.matches) * 1000) / 10 : 0;
      return `<div class="${cls}" data-key="${esc(r.key)}" style="--lc:${r.level.color}">
        <span class="c-pos">${medal}</span>
        ${avatar(r.name, 'sm', 44)}
        <span class="c-name"><b>${esc(r.name)}</b>${levelTag(r.level)}${r.real ? '' : '<i class="rk-sim" title="Perfil criado por simulação/demonstração">SIM</i>'}</span>
        <span class="c-points ${this.sort === 'points' ? 'on' : ''}"><em>${fmt(r.points)}</em><small>pts</small></span>
        <span class="c-kills ${this.sort === 'kills' ? 'on' : ''}"><small>⚔</small>${fmt(r.kills)}</span>
        <span class="c-wins ${this.sort === 'wins' ? 'on' : ''}"><small>🏆</small>${fmt(r.wins)}</span>
        <span class="c-matches ${this.sort === 'matches' ? 'on' : ''}"><small>🎮</small>${fmt(r.matches)}</span>
        <span class="c-gifts ${this.sort === 'gifts' ? 'on' : ''}"><small>🎁</small>${fmt(r.gifts)}</span>
        ${admin ? `<span class="c-wr">${wr}%</span>` : ''}
      </div>`;
    }).join('');
  }
  destroy() { clearInterval(this.timer); }
}

// ---------- perfil individual ----------
export function profileHTML(ranking, user, { admin = false } = {}) {
  const d = ranking.store.detail(user);
  if (!d) return '<div class="rk-empty">Perfil não encontrado.</div>';
  const lv = d.level, nxt = lv.next;
  const hist = d.history.length ? d.history.map((h) => `<li class="${h.won ? 'won' : ''}"><span>${h.won ? '🏆 Vitória' : h.place ? `☠ ${h.place}º lugar` : 'Partida'}</span><span>R${h.round} · ⚔ ${h.kills}</span><span class="pp">+${fmt(h.pts)} pts</span><span class="ag">${ago(h.ts)}</span></li>`).join('') : '<li class="empty">Nenhuma partida concluída ainda.</li>';
  const pos = (r) => (r ? `#${r}` : '—');
  return `
    <div class="rk-pf lv-${lv.id}" style="--lc:${lv.color}">
      <div class="rk-pf-head">
        ${avatar(d.name, 'lg', 96)}
        <div class="rk-pf-id">
          <h3>${esc(d.name)}</h3>
          <div>${levelTag(lv, true)} ${d.real ? '<span class="rk-src real">TikTok</span>' : '<span class="rk-src">Simulado</span>'}</div>
          <div class="rk-ranks"><b>${pos(d.rank)}</b> geral · <b>${pos(d.rankWeek)}</b> semana · <b>${pos(d.rankMonth)}</b> mês</div>
        </div>
        <div class="rk-pf-pts"><em>${fmt(d.total.points)}</em><small>pontos</small></div>
      </div>
      <div class="rk-prog"><div class="rk-bar"><b style="width:${Math.round(lv.progress * 100)}%"></b></div>
        <span>${nxt ? `${fmt(d.total.points)} / ${fmt(nxt.min)} pts para ${nxt.icon} ${nxt.name}` : 'Nível máximo alcançado!'}</span></div>
      <div class="rk-tiles">
        <div><em>${fmt(d.total.kills)}</em><span>⚔ Eliminações</span></div>
        <div><em>${fmt(d.total.wins)}</em><span>🏆 Vitórias</span></div>
        <div><em>${fmt(d.total.matches)}</em><span>🎮 Partidas</span></div>
        <div><em>${d.winRate}%</em><span>📈 Taxa de vitória</span></div>
        <div><em>${fmt(d.total.gifts)}</em><span>🎁 Presentes${d.total.giftsReal ? ` <small>(${fmt(d.total.giftsReal)} reais)</small>` : ''}</span></div>
        <div><em>${fmt(d.total.coins)}</em><span>🪙 Moedas</span></div>
      </div>
      <div class="rk-per"><span>Semana: <b>${fmt(d.week.points)}</b> pts</span><span>Mês: <b>${fmt(d.month.points)}</b> pts</span><span>Visto: ${ago(d.lastSeen)}</span></div>
      <h4>Histórico recente</h4>
      <ul class="rk-hist">${hist}</ul>
      ${admin ? `<h4>Ajustar pontos</h4><div class="rk-adj" data-user="${esc(d.name)}"><input type="number" class="rk-delta" value="50" step="10"><input type="text" class="rk-reason" placeholder="motivo (opcional)"><button data-adj="1" class="go">+ Adicionar</button><button data-adj="-1" class="danger">− Remover</button></div>` : ''}
    </div>`;
}

export function download(filename, text, mime = 'text/plain') {
  const a = document.createElement('a');
  a.href = URL.createObjectURL(new Blob([text], { type: mime + ';charset=utf-8' }));
  a.download = filename; document.body.appendChild(a); a.click();
  setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 500);
}
export { LEVELS };
