// Ponto de entrada da tela de transmissão (index.html)
import { Game } from './game.js';
import { Camera } from './camera.js';
import { Renderer } from './renderer.js';
import { AudioSystem } from './audio.js';
import { Link } from './websocket.js';
import { TikTokBridge } from './tiktok-bridge.js';
import { settings } from './settings.js';
import { BEHAVIORS } from './player.js';
import { computeRanking } from './leaderboard.js';
import { fmtTime } from './utils.js';
import { ZONE_RADII } from './safe-zone.js';
import { RankingSystem } from './ranking.js';
import { RankingPanel, profileHTML } from './ranking-ui.js';

const $ = (id) => document.getElementById(id);
const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

const game = new Game();
const cam = new Camera();
const renderer = new Renderer($('game'), game, cam);
const audio = new AudioSystem();
audio.enabled = settings.get('sound');
game.audio = (n) => audio.play(n);
window.__game = game; // facilita depuração / testes

// ----- comunicação (painel, servidor, TikTok) -----
const link = new Link({ role: 'game', token: localStorage.getItem('survivalLive.token') || '' });
const bridge = new TikTokBridge(game, link);
// ranking de espectadores: pontos, perfis e níveis (salvo no navegador e no servidor)
const ranking = new RankingSystem({ link, role: 'game' });
ranking.attachGame(game); bridge.ranking = ranking;
window.__ranking = ranking;
link.onStatus((s, n) => {
  const el = $('conn'); el.className = s === 'connected' ? 'on' : s === 'disconnected' ? '' : 'try';
  el.querySelector('em').textContent = s === 'connected' ? 'servidor' : s === 'connecting' ? 'conectando…' : s === 'reconnecting' ? `reconectando (${n})` : 'local';
});
link.connect();
setInterval(() => bridge.sendState(), 1000);

// ----- feeds -----
function pushFeed(id, html, max = 7) {
  const ul = $(id), li = document.createElement('li');
  li.innerHTML = html; ul.appendChild(li);
  while (ul.children.length > max) ul.removeChild(ul.firstChild);
  [...ul.children].forEach((c, i) => c.classList.toggle('old', i < ul.children.length - 3));
}
game.on('join', (j) => pushFeed('feedJoin', `<span class="n" style="color:${BEHAVIORS[j.behavior].color}">${esc(j.name)}</span> entrou${j.bot ? ' 🤖' : ''}`));
game.on('queued', (q) => pushFeed('feedJoin', `<span class="n">${esc(q.name)}</span> na fila (#${q.position})`));
game.on('kill', (k) => pushFeed('feedKill', `${esc(k.text)} <span style="color:#9aa6b8">(${k.remaining} vivos)</span>`));
game.on('monsterKill', (k) => pushFeed('feedKill', esc(k.text)));
game.on('gift', (g) => pushFeed('feedEvent', esc(g.text)));
game.on('event', (e) => { pushFeed('feedEvent', `${e.icon} <b>${esc(e.name)}</b>`); showEvent(e); });
game.on('start', () => { pushFeed('feedEvent', '🏁 <b>A partida começou!</b>'); flashCenter('VALENDO!', '', 1800); });
game.on('countdown', () => pushFeed('feedEvent', `⏳ Contagem regressiva iniciada`));
ranking.on('levelup', (e) => pushFeed('feedEvent', `${e.to.icon} <b>${esc(e.name)}</b> subiu para <b>${esc(e.to.name)}</b>!`));
game.on('phase', (p) => { if (p.phase === 'lobby') { $('winnerOverlay').classList.add('hidden'); } });
game.on('winner', (w) => {
  const o = $('winnerOverlay');
  o.querySelector('.w-name').textContent = w.name || 'EMPATE';
  o.querySelector('.w-label').textContent = w.name ? 'VENCEDOR' : 'SEM VENCEDOR';
  o.querySelector('.w-stats').textContent = w.name ? `⚔ ${w.kills} eliminações · ⏱ ${w.time}${w.wins > 1 ? ` · 🏆 ${w.wins} vitórias` : ''}` : '';
  o.classList.remove('hidden'); o.style.animation = 'none'; void o.offsetWidth; o.style.animation = '';
  pushFeed('feedEvent', `👑 <b>${esc(w.name || 'Ninguém')}</b> venceu a rodada!`);
});

let evTimer = 0;
function showEvent(e) {
  const b = $('eventBanner');
  b.style.setProperty('--ev', e.color || '#ff7a2e');
  b.querySelector('.ev-icon').textContent = e.icon; b.querySelector('.ev-name').textContent = e.name; b.querySelector('.ev-msg').textContent = e.msg;
  b.classList.remove('hidden'); b.style.animation = 'none'; void b.offsetWidth; b.style.animation = '';
  clearTimeout(evTimer); evTimer = setTimeout(() => b.classList.add('hidden'), 5500);
}
let flashT = 0, flashUntil = 0;
function flashCenter(big, sub, ms) { flashUntil = performance.now() + ms; const b = $('centerBanner'); b.className = 'pulse'; b.querySelector('.cb-title').textContent = ''; b.querySelector('.cb-big').textContent = big; b.querySelector('.cb-big').className = 'cb-big small'; b.querySelector('.cb-sub').innerHTML = sub; }

// ----- HUD -----
let hudT = 0, rkT = 0;
const mm = $('minimap').getContext('2d');
function updateHud(dt) {
  hudT -= dt; rkT -= dt;
  $('stTime').textContent = game.phase === 'playing' ? fmtTime(game.time) : game.phase === 'ending' ? fmtTime(game.winner ? game.winner.surviveTime : game.time) : '00:00';
  if (hudT <= 0) {
    hudT = 0.2;
    const max = settings.get('maxPlayers');
    $('stPlayers').textContent = game.phase === 'playing' || game.phase === 'ending' ? `${game.aliveCount()} vivos / ${game.fighters.length}` : `${game.fighters.length}/${max}`;
    $('stRound').textContent = '#' + game.round;
    const z = game.zone;
    $('stZone').textContent = game.phase === 'lobby' ? '—' : z.overtime ? 'FINAL' : `${z.stage + 1}/${ZONE_RADII.length - 1} ${z.phase === 'shrink' ? '▼ fechando' : '· ' + Math.ceil(z.timer) + 's'}`;
    $('stMonsters').textContent = game.monsters.filter((m) => m.alive).length;
    $('queueInfo').textContent = game.queue.length ? `${game.queue.length} na fila para a próxima rodada` : (game.phase === 'playing' ? 'Entrada na próxima rodada' : '');
    $('pausedOverlay').classList.toggle('hidden', !game.paused);
    updateBanner();
    renderer.drawMinimap(mm, 200);
  }
  if (rkT <= 0) { rkT = 0.5; updateRanking(); updateHall(); }
}
function updateBanner() {
  const b = $('centerBanner'), now = performance.now();
  if (now < flashUntil) return;
  const t = b.querySelector('.cb-title'), big = b.querySelector('.cb-big'), sub = b.querySelector('.cb-sub');
  const min = settings.get('minPlayers');
  if (game.phase === 'lobby') {
    b.className = '';
    if (game.countdown === null) {
      t.textContent = 'SALA DE ESPERA'; big.className = 'cb-big small'; big.textContent = 'AGUARDANDO JOGADORES';
      sub.innerHTML = `Digite <b>!entrar</b> ou <b>!join</b> no chat · ${game.fighters.length}/${min} mínimo`;
    } else {
      t.textContent = 'A PARTIDA COMEÇA EM'; big.className = 'cb-big'; big.textContent = Math.max(0, Math.ceil(game.countdown));
      sub.innerHTML = `${game.fighters.length} jogadores · Digite <b>!entrar</b> para participar`;
      if (game.countdown <= 10) b.className = 'pulse';
    }
  } else if (game.phase === 'ending' && game.holdEnding) {
    b.className = ''; t.textContent = 'FIM DA RODADA'; big.className = 'cb-big small'; big.textContent = 'AGUARDANDO O STREAMER'; sub.innerHTML = 'Inicie uma nova partida no painel';
    $('winnerOverlay').classList.remove('hidden');
  } else b.className = 'hidden';
}
function updateRanking() {
  const rk = computeRanking(game), tb = $('rkTable').querySelector('tbody');
  const rows = [];
  const top = rk.alive.slice(0, 8);
  top.forEach((f, i) => {
    const p = Math.max(0, f.hp / f.maxHp), col = p > 0.6 ? '#46d65a' : p > 0.3 ? '#f2c230' : '#ef4545';
    rows.push(`<tr><td class="pos">${i + 1}</td><td class="nm"><i style="background:${BEHAVIORS[f.behavior].color}"></i>${esc(f.name)}</td><td class="kl">⚔${f.kills}</td><td class="hp"><div class="bar"><b style="width:${p * 100}%;background:${col}"></b></div></td><td class="tm">${game.phase === 'lobby' ? '' : fmtTime(game.time)}</td></tr>`);
  });
  const extra = 8 - top.length;
  if (extra > 0 && game.phase !== 'lobby') rk.dead.slice(0, Math.min(extra, 3)).forEach((f) => rows.push(`<tr class="dead"><td class="pos">${f.placement || '–'}º</td><td class="nm"><i style="background:#666"></i>${esc(f.name)}</td><td class="kl">⚔${f.kills}</td><td class="hp"></td><td class="tm">${fmtTime(f.surviveTime)}</td></tr>`));
  if (!rows.length) rows.push('<tr><td colspan="5" style="text-align:center;color:#9aa6b8;padding:14px">Sem jogadores ainda</td></tr>');
  tb.innerHTML = rows.join('');
  const elim = game.fighters.filter((f) => !f.alive).length;
  $('rkInfo').textContent = `${rk.alive.length} vivos · ${elim} elim.`;
}
function updateHall() {
  const w = game.history.winners.slice(0, 5), ol = $('hallList');
  ol.innerHTML = w.length ? w.map((e) => `<li><span>🏆 ${esc(e.name)}</span><span>R${e.round} · ⚔${e.kills} · ${e.time}</span></li>`).join('') : '<li class="empty">Nenhum campeão nesta sessão</li>';
}

// ----- ranking dos espectadores (tela cheia sobre o jogo) -----
const rkOverlay = $('rankOverlay'), rkProf = $('rkProfile');
const rkPanel = new RankingPanel({ root: $('rkPanel'), ranking, mode: 'game', onOpen: (k) => openProfile(k) });
function openProfile(key) { $('rkProfileBody').innerHTML = profileHTML(ranking, key); rkProf.classList.remove('hidden'); }
function rkStatus() { const el = $('rkStorage'); const srv = ranking.mode === 'server'; el.className = 'rk-pill' + (srv ? ' on' : ''); el.textContent = srv ? '💾 salvo no servidor' : '💾 salvo neste navegador'; }
function toggleRank(force) {
  const show = force === undefined ? rkOverlay.classList.contains('hidden') : force;
  rkOverlay.classList.toggle('hidden', !show); if (!show) rkProf.classList.add('hidden');
  if (show) { rkStatus(); rkPanel.render(); }
}
$('btnRank').onclick = () => toggleRank(); $('rkClose').onclick = () => toggleRank(false); $('rkProfileClose').onclick = () => rkProf.classList.add('hidden');
rkOverlay.addEventListener('pointerdown', (e) => { if (e.target === rkOverlay) toggleRank(false); });
rkProf.addEventListener('pointerdown', (e) => { if (e.target === rkProf) rkProf.classList.add('hidden'); });
ranking.on('status', rkStatus);
window.addEventListener('keydown', (e) => {
  if (e.target && /input|textarea|select/i.test(e.target.tagName)) return;
  if (e.key === 'Escape') { if (!rkProf.classList.contains('hidden')) rkProf.classList.add('hidden'); else toggleRank(false); }
  else if (e.key.toLowerCase() === 'r' && !e.ctrlKey && !e.metaKey && !e.altKey) toggleRank();
});
// mini-ranking sempre visível no HUD (top 5 geral)
function updateViewerTop() {
  const rows = ranking.store.board({ period: 'all', sort: 'points', limit: 5 }).filter((r) => r.points > 0), ol = $('vtList');
  ol.innerHTML = rows.length ? rows.map((r) => `<li><span>${r.rank <= 3 ? ['🥇', '🥈', '🥉'][r.rank - 1] : r.rank}</span><b>${r.level.icon} ${esc(r.name)}</b><em>${r.points.toLocaleString('pt-BR')}</em></li>`).join('') : '<li class="empty">Pontue entrando nas partidas!</li>';
}
setInterval(updateViewerTop, 2000); updateViewerTop();

// ----- controles locais -----
function toggleUI() { document.body.classList.toggle('hide-ui'); }
function toggleFull() { if (document.fullscreenElement) document.exitFullscreen(); else document.documentElement.requestFullscreen?.().catch(() => {}); }
function toggleSound() { settings.patch({ sound: !settings.get('sound') }); audio.enabled = settings.get('sound'); $('btnSound').textContent = audio.enabled ? '🔊 Som' : '🔇 Mudo'; }
function togglePause() { game.command({ cmd: 'togglePause' }); $('btnPause').textContent = game.paused ? '▶ Retomar' : '⏸ Pausar'; }
$('btnFull').onclick = toggleFull; $('btnHide').onclick = toggleUI; $('btnSound').onclick = toggleSound; $('btnPause').onclick = togglePause;
window.addEventListener('keydown', (e) => {
  audio.unlock(); $('soundHint').classList.add('gone');
  if (e.target && /input|textarea|select/i.test(e.target.tagName)) return;
  const k = e.key.toLowerCase();
  if (k === 'h') toggleUI(); else if (k === 'f') toggleFull(); else if (k === 'm') toggleSound(); else if (k === 'p') togglePause();
});
window.addEventListener('pointerdown', () => { audio.unlock(); $('soundHint').classList.add('gone'); });
settings.onChange((d) => { audio.enabled = d.sound; $('btnSound').textContent = d.sound ? '🔊 Som' : '🔇 Mudo'; });
if (new URLSearchParams(location.search).get('ui') === '0') document.body.classList.add('hide-ui');
let idleT = 0;
function bump() { idleT = 0; document.body.classList.remove('idle'); }
window.addEventListener('mousemove', bump); window.addEventListener('keydown', bump);
window.addEventListener('resize', () => renderer.resize());
document.addEventListener('visibilitychange', () => { last = performance.now(); });
document.body.classList.add('idle');

// ----- laço principal (passo fixo de 60 Hz) -----
let last = performance.now(), acc = 0;
function frame(now) {
  let dt = (now - last) / 1000; last = now;
  if (dt > 0.1) dt = 0.1;
  idleT += dt; if (idleT > 3) document.body.classList.add('idle');
  acc += dt * settings.get('timeScale');
  let n = 0;
  while (acc >= 1 / 60 && n < 8) { game.update(1 / 60); acc -= 1 / 60; n++; }
  if (n >= 8) acc = 0;
  if (!game.paused || true) cam.update(game, dt, renderer.vw, renderer.vh);
  renderer.render(dt);
  updateHud(dt);
  requestAnimationFrame(frame);
}
cam.update(game, 0.016, renderer.vw, renderer.vh); cam.snap();
requestAnimationFrame(frame);
