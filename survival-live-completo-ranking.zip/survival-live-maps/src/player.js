// Personagens dos espectadores + inteligência artificial (sem DOM)
import { rand, pick, hashStr, angleTo, TAU } from './utils.js';
import { WEAPONS, BASIC_WEAPONS } from './combat.js';
import { ITEM_TYPES } from './items.js';
import { PLAZA, T_SWAMP, T_SHALLOW } from './map.js';

export const BEHAVIORS = {
  aggressive: { label: 'Agressivo', detect: 600, fleeHp: 0.18, lootRange: 170, zoneMargin: 40, chase: true, color: '#ff5a5a' },
  defensive: { label: 'Defensivo', detect: 320, fleeHp: 0.5, lootRange: 280, zoneMargin: 150, chase: false, color: '#5ab0ff' },
  explorer: { label: 'Explorador', detect: 360, fleeHp: 0.35, lootRange: 560, zoneMargin: 80, chase: true, color: '#7be07b' },
  strategic: { label: 'Estratégico', detect: 460, fleeHp: 0.4, lootRange: 340, zoneMargin: 170, chase: true, color: '#d68cff' },
};

const SKINS = ['#f6d3b3', '#e6b48a', '#c68642', '#8d5524', '#ffdbac', '#a9694a'];
const HAIRS = ['#2b1d12', '#5a3a1e', '#d9a441', '#c7452c', '#222', '#e8e8e8', '#6a3fa0', '#1f8a70'];

export const BASE_SPEED = 118;

/** movimento com desvio de obstáculos; usado por jogadores e monstros */
export function moveEntity(e, g, dx, dy, speed, dt) {
  const len = Math.hypot(dx, dy);
  let tvx = 0, tvy = 0;
  const map = g.map;
  const terr = map.terrain(e.x, e.y);
  if (e.dashT > 0) {
    tvx = Math.cos(e.dashAng) * speed * 3.4; tvy = Math.sin(e.dashAng) * speed * 3.4;
  } else if (len > 0.001) {
    const ang = Math.atan2(dy, dx);
    const look = e.r + 36;
    const swampOk = e.ignoreSwamp || terr === T_SWAMP;
    const blocked = (a) => {
      const px = e.x + Math.cos(a) * look, py = e.y + Math.sin(a) * look;
      return map.solidAt(px, py, e.r * 0.7) || (!swampOk && map.terrain(px, py) === T_SWAMP);
    };
    let use = ang;
    if (blocked(ang)) {
      const s = e.steerSign || 1;
      let found = false;
      for (let k = 1; k <= 4 && !found; k++) {
        for (const sg of [s, -s]) {
          const a = ang + sg * k * 0.5;
          if (!blocked(a)) { use = a; e.steerSign = sg; found = true; break; }
        }
      }
    }
    const sp = speed * (len < 1 ? len : 1) * (terr === T_SHALLOW ? 0.55 : terr === T_SWAMP ? 0.7 : 1);
    tvx = Math.cos(use) * sp; tvy = Math.sin(use) * sp;
  }
  const k = Math.min(1, (e.dashT > 0 ? 40 : 12) * dt);
  e.vx += (tvx - e.vx) * k; e.vy += (tvy - e.vy) * k;
  const ox = e.x, oy = e.y;
  e.x += e.vx * dt; e.y += e.vy * dt;
  g.map.resolve(e);
  e.moved = Math.hypot(e.x - ox, e.y - oy);
}

export class Fighter {
  constructor(game, name, { bot = false, behavior } = {}) {
    this.game = game;
    this.isFighter = true;
    this.name = name;
    this.id = name.toLowerCase();
    this.bot = bot;
    this.behavior = behavior && BEHAVIORS[behavior] ? behavior : pick(Object.keys(BEHAVIORS));
    const h = hashStr(this.id);
    const hue = h % 360;
    this.look = {
      skin: SKINS[h % SKINS.length], shirt: `hsl(${hue} 72% 52%)`, shirtDark: `hsl(${hue} 72% 36%)`,
      pants: `hsl(${(hue + 160) % 360} 28% 26%)`, hair: HAIRS[(h >> 5) % HAIRS.length], style: (h >> 9) % 3,
      accent: `hsl(${hue} 90% 62%)`,
    };
    this.r = 14;
    this.maxHp = 100; this.maxEnergy = 100;
    this.wins = 0;
    this.resetForRound();
  }
  resetForRound() {
    this.hp = this.maxHp; this.energy = this.maxEnergy; this.shield = 0; this.shieldT = 0; this.rageT = 0;
    this.kills = 0; this.monsterKills = 0; this.alive = true; this.placement = 0;
    this.weapon = pick(BASIC_WEAPONS);
    this.vx = this.vy = 0; this.facing = rand(TAU);
    this.attackCd = 0; this.swingT = 0; this.swingMax = 0.2; this.dashCd = 0; this.dashT = 0; this.dashAng = 0;
    this.hitFlash = 0; this.invuln = 0; this.dropT = 0; this.attackedT = 9; this.lastHitBy = null; this.lastHitT = -99;
    this.animT = rand(10); this.thinkT = rand(0.3); this.goal = null; this.enemy = null; this.hidden = false;
    this.joinTime = this.game ? this.game.time : 0; this.surviveTime = 0; this.deathT = 0; this.corpseT = 0;
    this.stuckT = 0; this.detourT = 0; this.lastX = 0; this.lastY = 0; this.lastCheck = 0; this.wp = null; this.wpT = 0;
    this.strafeDir = Math.random() < 0.5 ? 1 : -1; this.strafeT = 0; this.home = null; this.dmgMul = 1; this.moved = 0; this.dashEvadeT = 0;
  }
  startMatch(x, y) {
    this.x = x; this.y = y; this.vx = this.vy = 0;
    this.invuln = 3; this.dropT = 1.3; this.joinTime = 0; this.energy = this.maxEnergy; this.hp = this.maxHp;
    this.weapon = this.weapon || pick(BASIC_WEAPONS);
    this.goal = null; this.wp = null;
  }
  heal(n) {
    if (!this.alive) return;
    const a = Math.min(n, this.maxHp - this.hp);
    this.hp += a;
    if (a > 0) {
      this.game.fx.text(this.x, this.y - this.r - 14, `+${Math.round(a)}`, '#6dff8a', 15);
      this.game.fx.burst(this.x, this.y, 8, { speed: 70, life: 0.7, size: 3, color: '#6dff8a', grav: -30 });
    }
  }
  addShield(n, dur = 15) { this.shield = Math.min(100, this.shield + n); this.shieldT = Math.max(this.shieldT, dur); }
  get speed() { return BASE_SPEED * (this.rageT > 0 ? 1.2 : 1); }
  dash(ang) {
    if (this.energy < 25 || this.dashCd > 0 || this.dashT > 0) return false;
    this.energy -= 25; this.dashCd = 2.4; this.dashT = 0.18; this.dashAng = ang;
    this.game.fx.burst(this.x, this.y, 8, { speed: 80, life: 0.4, size: 4, color: 'rgba(220,210,190,0.7)', kind: 'smoke', grow: 8 });
    this.game.audio?.('dash', this);
    return true;
  }
  onHurt(src) { if (src && src !== this) this.attackerRef = src; }

  // ---------- atualização ----------
  update(dt) {
    const g = this.game;
    if (!this.alive) { this.corpseT += dt; return; }
    if (this.attackCd > 0) this.attackCd -= dt;
    if (this.swingT > 0) this.swingT -= dt;
    if (this.dashCd > 0) this.dashCd -= dt;
    if (this.dashT > 0) this.dashT -= dt;
    if (this.hitFlash > 0) this.hitFlash -= dt;
    if (this.invuln > 0) this.invuln -= dt;
    if (this.dropT > 0) this.dropT -= dt;
    if (this.rageT > 0) { this.rageT -= dt; if (this.rageT <= 0) this.dmgMul = 1; else this.dmgMul = 1; }
    if (this.shieldT > 0) { this.shieldT -= dt; if (this.shieldT <= 0) this.shield = 0; }
    this.attackedT += dt;
    this.energy = Math.min(this.maxEnergy, this.energy + 8 * dt);
    this.hidden = g.map.inBush(this.x, this.y) && this.attackedT > 1.1 && g.time - this.lastHitT > 1.5;
    if (g.phase === 'playing') this.surviveTime = g.time;
    if (this.dropT > 0) return; // caindo do céu

    this.thinkT -= dt;
    if (this.thinkT <= 0) { this.thinkT = 0.14 + Math.random() * 0.1; if (g.phase === 'playing') this.decide(); }
    this.act(dt);
    // detecção de travamento
    this.lastCheck += dt;
    if (this.lastCheck >= 0.5) {
      const mv = Math.hypot(this.x - this.lastX, this.y - this.lastY);
      if (this.wantMove && mv < 8 && this.dashT <= 0) this.stuckT += 0.5; else this.stuckT = 0;
      if (this.stuckT >= 1) { this.detourT = 1.1; this.detourAng = rand(TAU); this.stuckT = 0; this.wp = null; }
      this.lastX = this.x; this.lastY = this.y; this.lastCheck = 0;
    }
    this.animT += Math.hypot(this.vx, this.vy) * dt * 0.09;
  }

  findEnemy(B) {
    const g = this.game;
    let best = null, bs = Infinity;
    const consider = (e) => {
      const d = Math.hypot(e.x - this.x, e.y - this.y);
      if (e.hidden && d > 110) return;
      let reach = B.detect;
      if (e.isMonster) reach = Math.min(reach, this.behavior === 'defensive' ? 220 : 420);
      if (e === this.attackerRef && g.time - this.lastHitT < 6) reach = Math.max(reach, 500);
      if (d > reach) return;
      let s = d - (1 - e.hp / e.maxHp) * (this.behavior === 'strategic' ? 160 : 60);
      if (e.type === 'giant' && d > 160) s += 600;
      if (e.invuln > 0) s += 800;
      if (s < bs) { bs = s; best = e; }
    };
    for (const f of g.fighters) if (f.alive && f !== this && f.dropT <= 0) consider(f);
    for (const m of g.monsters) if (m.alive) consider(m);
    return best;
  }

  wantsItem(it) {
    const T = ITEM_TYPES[it.type];
    if (T.heal) return this.hp < this.maxHp - 12;
    if (T.energy) return this.energy < 55;
    if (T.shield) return this.shield < 30;
    if (it.type === 'weapon') { const nw = WEAPONS[it.weapon], ow = WEAPONS[this.weapon]; return nw.score > ow.score; }
    return false;
  }

  decide() {
    const g = this.game, B = BEHAVIORS[this.behavior], z = g.zone;
    const hpPct = this.hp / this.maxHp;
    this.goal = null;
    const enemy = this.enemy = this.findEnemy(B);
    const de = enemy ? Math.hypot(enemy.x - this.x, enemy.y - this.y) : Infinity;

    // 1) perigos telegrafados (meteoros, pisões, raios)
    for (const d of g.dangers) {
      if (d.t <= 0) continue;
      const dd = Math.hypot(this.x - d.x, this.y - d.y);
      if (dd < d.r + 45) {
        const a = Math.atan2(this.y - d.y, this.x - d.x);
        this.goal = { kind: 'dodge', x: this.x + Math.cos(a) * 220, y: this.y + Math.sin(a) * 220 };
        if (dd < d.r && d.t < 1.1) this.dash(a);
        return;
      }
    }
    // 2) zona segura
    const aim = z.aim;
    const dz = Math.hypot(this.x - aim.x, this.y - aim.y);
    const outsideNow = z.outside(this.x, this.y, 10);
    const outsideAim = dz > aim.r - B.zoneMargin;
    if (outsideNow || (outsideAim && de > 110)) {
      this.goal = { kind: 'zone', x: aim.x + rand(-aim.r * 0.3, aim.r * 0.3), y: aim.y + rand(-aim.r * 0.3, aim.r * 0.3) };
      if (outsideNow && dz > aim.r + 200 && this.energy >= 50) this.dash(angleTo(this, aim));
      return;
    }
    // 3) fuga / cura
    const giantNear = enemy && enemy.type === 'giant' && de < 300 && !(this.behavior === 'aggressive' && hpPct > 0.6);
    if (hpPct < B.fleeHp || giantNear) {
      const heal = g.items.nearest(this, 760, (it) => ITEM_TYPES[it.type].heal);
      if (heal && !giantNear && (!enemy || de > 100)) { this.goal = { kind: 'item', x: heal.x, y: heal.y, item: heal }; return; }
      if (enemy && de < 460 && this.stuckT < 0.5) {
        const a = angleTo(enemy, this) + rand(-0.3, 0.3);
        this.goal = { kind: 'flee', x: this.x + Math.cos(a) * 260, y: this.y + Math.sin(a) * 260 };
        if (de < 110 && this.energy >= 25) this.dash(a);
        return;
      }
    }
    // 4) item muito próximo
    const near = g.items.nearest(this, 90, (it) => this.wantsItem(it));
    if (near) { this.goal = { kind: 'item', x: near.x, y: near.y, item: near }; return; }
    // 5) combate
    if (enemy) {
      const engage = B.chase ? true : (de < 230 || (enemy === this.attackerRef && g.time - this.lastHitT < 5) || enemy.isMonster);
      if (engage) { this.goal = { kind: 'attack', target: enemy }; return; }
    }
    // 6) caixas e itens
    const crate = g.items.nearestCrate(this, B.lootRange * 1.8);
    if (crate && hpPct > 0.3) { this.goal = { kind: 'item', x: crate.x, y: crate.y, crate }; return; }
    const it = g.items.nearest(this, B.lootRange, (i) => this.wantsItem(i));
    if (it) { this.goal = { kind: 'item', x: it.x, y: it.y, item: it }; return; }

    // 7) comportamento de personalidade
    this.wpT -= 0.2;
    switch (this.behavior) {
      case 'aggressive': {
        let t = null, bd = Infinity;
        for (const f of g.fighters) if (f.alive && f !== this && !f.hidden) { const d = Math.hypot(f.x - this.x, f.y - this.y); if (d < bd) { bd = d; t = f; } }
        if (t) this.goal = { kind: 'hunt', x: t.x, y: t.y };
        break;
      }
      case 'defensive':
      case 'strategic': {
        const bush = this.nearestBush(aim, this.behavior === 'strategic' ? 500 : 380);
        if (bush) {
          const inside = Math.hypot(this.x - bush.x, this.y - bush.y) < bush.r * 0.6;
          this.goal = inside ? { kind: 'camp', x: this.x, y: this.y } : { kind: 'move', x: bush.x, y: bush.y };
        } else if (dz > aim.r * 0.5) this.goal = { kind: 'move', x: aim.x, y: aim.y };
        break;
      }
      default: { // explorador
        if (!this.wp || this.wpT <= 0 || Math.hypot(this.wp.x - this.x, this.wp.y - this.y) < 60) {
          const spot = g.map.lootSpots[(Math.random() * g.map.lootSpots.length) | 0];
          const ok = spot && !z.outside(spot.x, spot.y, 120);
          this.wp = ok ? { x: spot.x, y: spot.y } : g.map.randomFree(Math.random, { x: aim.x, y: aim.y, r: Math.max(60, aim.r * 0.8) }, 30);
          this.wpT = rand(9, 15);
        }
        this.goal = { kind: 'move', x: this.wp.x, y: this.wp.y };
      }
    }
    if (!this.goal) {
      if (!this.wp || this.wpT <= 0 || Math.hypot(this.wp.x - this.x, this.wp.y - this.y) < 50) {
        this.wp = g.map.randomFree(Math.random, { x: aim.x, y: aim.y, r: Math.max(60, aim.r * 0.8) }, 30); this.wpT = rand(5, 9);
      }
      this.goal = { kind: 'move', x: this.wp.x, y: this.wp.y };
    }
  }

  nearestBush(aim, range) {
    const g = this.game;
    let best = null, bd = range * range;
    const bs = g.map.bushes;
    // amostragem para não custar caro: no máx. 60 verificações por chamada
    const step = Math.max(1, Math.floor(bs.length / 60));
    for (let i = (Math.random() * step) | 0; i < bs.length; i += step) {
      const b = bs[i];
      const d = (b.x - this.x) ** 2 + (b.y - this.y) ** 2;
      if (d < bd && Math.hypot(b.x - aim.x, b.y - aim.y) < aim.r - 60) { bd = d; best = b; }
    }
    return best;
  }

  act(dt) {
    const g = this.game;
    let dx = 0, dy = 0, mul = 1;
    this.wantMove = false;
    if (g.phase !== 'playing') {
      // sala de espera: passeia perto da fogueira
      if (!this.home) this.home = { x: this.x, y: this.y };
      this.wpT -= dt;
      if (!this.wp || this.wpT <= 0) {
        const a = rand(TAU), d = rand(0, 60);
        this.wp = { x: this.home.x + Math.cos(a) * d, y: this.home.y + Math.sin(a) * d }; this.wpT = rand(2, 5);
      }
      dx = this.wp.x - this.x; dy = this.wp.y - this.y;
      const l = Math.hypot(dx, dy);
      if (l < 8) { dx = dy = 0; } else { mul = 0.4; dx /= l; dy /= l; }
      if (this.dashT > 0) this.dashT = 0;
      moveEntity(this, g, dx * mul, dy * mul, this.speed, dt);
      if (l > 8) this.facing = Math.atan2(this.vy, this.vx);
      return;
    }
    if (this.detourT > 0) {
      this.detourT -= dt;
      dx = Math.cos(this.detourAng); dy = Math.sin(this.detourAng);
      this.wantMove = false;
    } else if (this.goal) {
      const gl = this.goal;
      switch (gl.kind) {
        case 'attack': {
          const t = gl.target;
          if (!t.alive) { this.goal = null; break; }
          const w = WEAPONS[this.weapon];
          const dd = Math.hypot(t.x - this.x, t.y - this.y), d = dd - t.r;
          const ux = (t.x - this.x) / (dd || 1), uy = (t.y - this.y) / (dd || 1);
          this.strafeT -= dt;
          if (this.strafeT <= 0) { this.strafeT = rand(0.8, 2); if (Math.random() < 0.4) this.strafeDir *= -1; }
          if (w.type === 'melee') {
            if (d > w.range * 0.75) { dx = ux; dy = uy; this.wantMove = true; }
            else { dx = -uy * this.strafeDir * 0.5; dy = ux * this.strafeDir * 0.5; }
            if (d > 170 && this.behavior === 'aggressive' && this.energy >= 60) this.dash(Math.atan2(uy, ux));
          } else {
            if (d < w.range * 0.35) { dx = -ux; dy = -uy; this.wantMove = true; }
            else if (d > w.range * 0.85) { dx = ux; dy = uy; this.wantMove = true; }
            else { dx = -uy * this.strafeDir * 0.7; dy = ux * this.strafeDir * 0.7; }
          }
          // esquiva de pisão/ataque pesado de monstros próximos
          break;
        }
        case 'camp': dx = dy = 0; break;
        case 'item':
          if (gl.item && !g.items.list.includes(gl.item) && !gl.crate) { this.goal = null; break; }
          if (gl.crate && gl.crate.opened) { this.goal = null; break; }
          dx = gl.x - this.x; dy = gl.y - this.y; this.wantMove = true; break;
        default: {
          dx = gl.x - this.x; dy = gl.y - this.y;
          const l = Math.hypot(dx, dy);
          if (l < 14) { dx = dy = 0; if (gl.kind === 'move') this.wpT = 0; } else { this.wantMove = true; }
        }
      }
      const l = Math.hypot(dx, dy);
      if (l > 1) { dx /= l; dy /= l; }
    }
    // ataque oportunista (também durante deslocamento/fuga)
    const e = this.enemy;
    if (e && e.alive && this.attackCd <= 0) {
      const w = WEAPONS[this.weapon];
      const d = Math.hypot(e.x - this.x, e.y - this.y) - e.r;
      if (d <= w.range * 0.98 && (w.type === 'melee' || !g.map.lineBlocked(this.x, this.y, e.x, e.y))) g.combat.attack(this, e);
    }
    moveEntity(this, g, dx, dy, this.speed, dt);
    if (this.swingT <= 0) {
      if (this.enemy && this.enemy.alive && this.goal && this.goal.kind === 'attack') this.facing = angleTo(this, this.enemy);
      else if (Math.hypot(this.vx, this.vy) > 10) this.facing = Math.atan2(this.vy, this.vx);
    }
  }

  /** posição inicial na sala de espera (anel ao redor da fogueira) */
  placeInLobby(others) {
    for (let t = 0; t < 30; t++) {
      const a = rand(TAU), d = rand(90, 300);
      const x = PLAZA.x + Math.cos(a) * d, y = PLAZA.y + Math.sin(a) * d;
      if (others.every((o) => o === this || Math.hypot(o.x - x, o.y - y) > 36)) { this.x = x; this.y = y; this.home = { x, y }; return; }
    }
    this.x = PLAZA.x + rand(-200, 200); this.y = PLAZA.y + rand(-200, 200); this.home = { x: this.x, y: this.y };
  }
}
