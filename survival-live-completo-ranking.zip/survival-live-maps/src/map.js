// Geração procedural do mapa + colisão (sem DOM)
import { mulberry32, rand as _r, TAU } from './utils.js';
import { settings } from './settings.js';
import { MAPS, resolveMapId } from './maps.js';

export const MAP_W = 3600;
export const MAP_H = 3600;
export const CELL = 256;
export const PLAZA = { x: MAP_W / 2, y: MAP_H / 2, r: 330 };
export const T_NORMAL = 0, T_SHALLOW = 1, T_SWAMP = 2;

export class GameMap {
  /** themeId: 'forest' | 'desert' | 'snow' (padrão: o mapa escolhido no painel; 'random' sorteia) */
  constructor(seed = (Math.random() * 1e9) | 0, themeId) {
    this.seed = seed;
    this.theme = MAPS[themeId] || MAPS[resolveMapId(settings.get('mapId'))];
    this.w = MAP_W; this.h = MAP_H;
    this.solids = [];   // colisão: circle | rect | ellipse
    this.lakes = [];    // elipses profundas
    this.river = [];    // círculos rasos (rio)
    this.riverPath = [];
    this.swamps = [];   // áreas perigosas
    this.bushes = [];   // esconderijos
    this.trees = [];
    this.rocks = [];
    this.houses = [];
    this.mountains = [];
    this.paths = [];
    this.lootSpots = [];
    this.villages = [];
    this.grid = new Map();      // solids
    this.softGrid = new Map();  // bushes / swamps / river
    this.generate();
  }

  // ---- grade espacial ----
  _key(cx, cy) { return cx * 1000 + cy; }
  _insert(grid, obj, x0, y0, x1, y1) {
    const a = Math.max(0, Math.floor(x0 / CELL)), b = Math.floor(x1 / CELL);
    const c = Math.max(0, Math.floor(y0 / CELL)), d = Math.floor(y1 / CELL);
    for (let cx = a; cx <= b; cx++) for (let cy = c; cy <= d; cy++) {
      const k = this._key(cx, cy);
      let l = grid.get(k);
      if (!l) grid.set(k, (l = []));
      l.push(obj);
    }
  }
  addSolid(s) {
    this.solids.push(s);
    if (s.kind === 'circle') this._insert(this.grid, s, s.x - s.r, s.y - s.r, s.x + s.r, s.y + s.r);
    else if (s.kind === 'rect') this._insert(this.grid, s, s.x, s.y, s.x + s.w, s.y + s.h);
    else this._insert(this.grid, s, s.x - s.rx, s.y - s.ry, s.x + s.rx, s.y + s.ry);
    return s;
  }
  addSoft(o) {
    this._insert(this.softGrid, o, o.x - o.r, o.y - o.r, o.x + o.r, o.y + o.r);
  }
  _cell(grid, x, y) { return grid.get(this._key(Math.floor(x / CELL), Math.floor(y / CELL))); }

  // ---- consultas ----
  /** empurra a entidade para fora de sólidos e mantém dentro do mapa */
  resolve(e) {
    const r = e.r;
    e.x = Math.min(this.w - r, Math.max(r, e.x));
    e.y = Math.min(this.h - r, Math.max(r, e.y));
    const l = this._cell(this.grid, e.x, e.y);
    if (!l) return;
    for (let i = 0; i < l.length; i++) {
      const s = l[i];
      if (s.kind === 'circle') {
        const dx = e.x - s.x, dy = e.y - s.y, m = s.r + r;
        const d2 = dx * dx + dy * dy;
        if (d2 < m * m) {
          const d = Math.sqrt(d2) || 0.001;
          e.x = s.x + (dx / d) * m; e.y = s.y + (dy / d) * m;
        }
      } else if (s.kind === 'rect') {
        const cx = Math.max(s.x, Math.min(e.x, s.x + s.w)), cy = Math.max(s.y, Math.min(e.y, s.y + s.h));
        let dx = e.x - cx, dy = e.y - cy;
        const d2 = dx * dx + dy * dy;
        if (d2 < r * r) {
          if (d2 > 0.0001) { const d = Math.sqrt(d2); e.x = cx + (dx / d) * r; e.y = cy + (dy / d) * r; }
          else {
            const l1 = e.x - s.x, r1 = s.x + s.w - e.x, t1 = e.y - s.y, b1 = s.y + s.h - e.y;
            const m = Math.min(l1, r1, t1, b1);
            if (m === l1) e.x = s.x - r; else if (m === r1) e.x = s.x + s.w + r;
            else if (m === t1) e.y = s.y - r; else e.y = s.y + s.h + r;
          }
        }
      } else {
        const rx = s.rx + r, ry = s.ry + r;
        const px = (e.x - s.x) / rx, py = (e.y - s.y) / ry;
        const k = Math.hypot(px, py);
        if (k < 1) {
          if (k < 0.0001) { e.y = s.y - ry; } else { e.x = s.x + (px / k) * rx; e.y = s.y + (py / k) * ry; }
        }
      }
    }
  }
  /** há algo sólido (ou água profunda) neste ponto? */
  solidAt(x, y, r = 0) {
    if (x < r || y < r || x > this.w - r || y > this.h - r) return true;
    const l = this._cell(this.grid, x, y);
    if (!l) return false;
    for (let i = 0; i < l.length; i++) {
      const s = l[i];
      if (s.kind === 'circle') { const m = s.r + r; if ((x - s.x) ** 2 + (y - s.y) ** 2 < m * m) return true; }
      else if (s.kind === 'rect') { if (x > s.x - r && x < s.x + s.w + r && y > s.y - r && y < s.y + s.h + r) return true; }
      else if (((x - s.x) / (s.rx + r)) ** 2 + ((y - s.y) / (s.ry + r)) ** 2 < 1) return true;
    }
    return false;
  }
  terrain(x, y) {
    const l = this._cell(this.softGrid, x, y);
    if (!l) return T_NORMAL;
    let t = T_NORMAL;
    for (let i = 0; i < l.length; i++) {
      const o = l[i];
      if (o.type === 'bush') continue;
      if ((x - o.x) ** 2 + (y - o.y) ** 2 < o.r * o.r) {
        if (o.type === 'swamp') return T_SWAMP;
        t = T_SHALLOW;
      }
    }
    return t;
  }
  inBush(x, y) {
    const l = this._cell(this.softGrid, x, y);
    if (!l) return false;
    for (let i = 0; i < l.length; i++) {
      const o = l[i];
      if (o.type === 'bush' && (x - o.x) ** 2 + (y - o.y) ** 2 < o.r * o.r) return true;
    }
    return false;
  }
  lineBlocked(x1, y1, x2, y2) {
    const d = Math.hypot(x2 - x1, y2 - y1);
    const n = Math.ceil(d / 36);
    for (let i = 1; i < n; i++) {
      const t = i / n;
      const x = x1 + (x2 - x1) * t, y = y1 + (y2 - y1) * t;
      const l = this._cell(this.grid, x, y);
      if (!l) continue;
      for (let j = 0; j < l.length; j++) {
        const s = l[j];
        if (s.type === 'tree' || s.type === 'lake') continue; // não bloqueiam visão/tiro
        if (s.kind === 'circle' && (x - s.x) ** 2 + (y - s.y) ** 2 < s.r * s.r) return true;
        if (s.kind === 'rect' && x > s.x && x < s.x + s.w && y > s.y && y < s.y + s.h) return true;
      }
    }
    return false;
  }
  /** ponto livre para surgir: fora de sólidos, água e pântano */
  randomFree(rng, region, margin = 30, tries = 60) {
    const rr = region || { x: this.w / 2, y: this.h / 2, r: this.w / 2 - 80 };
    for (let i = 0; i < tries; i++) {
      const a = rng() * TAU, d = Math.sqrt(rng()) * rr.r;
      const x = rr.x + Math.cos(a) * d, y = rr.y + Math.sin(a) * d;
      if (x < 60 || y < 60 || x > this.w - 60 || y > this.h - 60) continue;
      if (!this.solidAt(x, y, margin) && this.terrain(x, y) !== T_SWAMP) return { x, y };
    }
    return { x: rr.x, y: rr.y };
  }

  // ---- geração ----
  generate() {
    const rng = mulberry32(this.seed);
    const R = (a, b) => a + rng() * (b - a);
    const W = this.w, H = this.h;
    const G = this.theme.gen;
    const free = (x, y, r, pad = 0) => {
      if (x < 120 || y < 120 || x > W - 120 || y > H - 120) return false;
      if (Math.hypot(x - PLAZA.x, y - PLAZA.y) < PLAZA.r + r + pad) return false;
      if (this.solidAt(x, y, r + pad)) return false;
      const l = this._cell(this.softGrid, x, y);
      if (l) for (const o of l) if (o.type !== 'bush' && Math.hypot(x - o.x, y - o.y) < o.r + r) return false;
      return true;
    };

    // lagos
    for (let i = 0; i < G.lakes; i++) {
      for (let t = 0; t < 40; t++) {
        const x = R(500, W - 500), y = R(500, H - 500), rx = R(...G.lakeRx), ry = R(...G.lakeRy);
        if (Math.hypot(x - PLAZA.x, y - PLAZA.y) < PLAZA.r + rx + 120) continue;
        if (this.lakes.some((l) => Math.hypot(l.x - x, l.y - y) < l.rx + rx + 160)) continue;
        const lake = { kind: 'ellipse', type: 'lake', x, y, rx, ry };
        this.lakes.push(lake); this.addSolid(lake);
        break;
      }
    }
    // rio (raso, atravessável) de cima a baixo, serpenteando
    if (G.river) {
      let x = R(700, W - 700);
      const wob = R(0.004, 0.008), ph = R(TAU);
      const amp = R(160, 280);
      const baseX = x;
      for (let y = 0; y <= H; y += 38) {
        x = baseX + Math.sin(y * wob + ph) * amp;
        // desvia da praça
        if (Math.abs(y - PLAZA.y) < PLAZA.r + 80 && Math.abs(x - PLAZA.x) < PLAZA.r + 120) x += x < PLAZA.x ? -(PLAZA.r + 140) : PLAZA.r + 140;
        const o = { x, y, r: 46, type: 'river' };
        this.river.push(o); this.addSoft(o); this.riverPath.push({ x, y });
      }
    }
    // pântanos tóxicos
    for (let i = 0; i < G.swamps; i++) {
      for (let t = 0; t < 40; t++) {
        const x = R(400, W - 400), y = R(400, H - 400), r = R(...G.swampR);
        if (!free(x, y, r, 40)) continue;
        if (this.river.some((o) => Math.hypot(o.x - x, o.y - y) < o.r + r)) continue;
        const o = { x, y, r, type: 'swamp' };
        this.swamps.push(o); this.addSoft(o);
        break;
      }
    }
    // montanhas
    for (let i = 0; i < G.mountains; i++) {
      for (let t = 0; t < 40; t++) {
        const x = R(300, W - 300), y = R(300, H - 300), r = R(...G.mountR);
        if (!free(x, y, r, 60)) continue;
        if (this.river.some((o) => Math.hypot(o.x - x, o.y - y) < o.r + r)) continue;
        const m = { kind: 'circle', type: 'mountain', x, y, r: r * 0.82, vr: r, v: (rng() * 3) | 0 };
        this.mountains.push(m); this.addSolid(m);
        // pedras ao redor
        for (let k = 0; k < 7; k++) {
          const a = rng() * TAU, d = r * R(0.95, 1.5), rx = x + Math.cos(a) * d, ry = y + Math.sin(a) * d;
          if (free(rx, ry, 24, 10)) this.addRock(rx, ry, R(16, 30), rng);
        }
        break;
      }
    }
    // vilas abandonadas
    for (let i = 0; i < G.villages; i++) {
      for (let t = 0; t < 60; t++) {
        const cx = R(400, W - 400), cy = R(400, H - 400);
        if (!free(cx, cy, 230, 20)) continue;
        if (this.river.some((o) => Math.hypot(o.x - cx, o.y - cy) < o.r + 230)) continue;
        const village = { x: cx, y: cy, r: 220 };
        const n = G.houseMin + ((rng() * G.houseVar) | 0);
        let placed = 0;
        for (let k = 0; k < 18 && placed < n; k++) {
          const w = R(110, 160), h = R(80, 110);
          const hx = cx + R(-170, 170) - w / 2, hy = cy + R(-150, 150) - h / 2;
          if (!free(hx + w / 2, hy + h / 2, Math.max(w, h) / 2 + 30)) continue;
          const house = { kind: 'rect', type: 'house', x: hx, y: hy, w, h, v: (rng() * 3) | 0 };
          this.houses.push(house); this.addSolid(house); placed++;
          this.lootSpots.push({ x: hx + w / 2, y: hy + h + 34 });
        }
        if (placed < 2) { this.houses.splice(this.houses.length - placed, placed); continue; }
        this.villages.push(village);
        break;
      }
    }
    // pedras soltas
    for (let i = 0; i < G.rocks; i++) {
      const x = R(150, W - 150), y = R(150, H - 150);
      if (free(x, y, 30, 10)) this.addRock(x, y, R(14, 34), rng);
    }
    // florestas (aglomerados) + árvores soltas
    const forests = [];
    for (let i = 0; i < G.forests; i++) {
      for (let t = 0; t < 30; t++) {
        const x = R(250, W - 250), y = R(250, H - 250), r = R(...G.forestR);
        if (Math.hypot(x - PLAZA.x, y - PLAZA.y) < PLAZA.r + r * 0.4) continue;
        forests.push({ x, y, r });
        break;
      }
    }
    for (const f of forests) {
      const n = Math.floor(f.r / G.forestDensity);
      for (let k = 0; k < n; k++) {
        const a = rng() * TAU, d = Math.sqrt(rng()) * f.r;
        const x = f.x + Math.cos(a) * d, y = f.y + Math.sin(a) * d;
        if (free(x, y, 16, 4) && !this.river.some((o) => Math.hypot(o.x - x, o.y - y) < o.r + 10)) this.addTree(x, y, rng);
      }
    }
    for (let i = 0; i < G.scatterTrees; i++) {
      const x = R(150, W - 150), y = R(150, H - 150);
      if (free(x, y, 16, 20) && !this.river.some((o) => Math.hypot(o.x - x, o.y - y) < o.r + 10)) this.addTree(x, y, rng);
    }
    // arbustos / esconderijos
    for (let i = 0; i < G.bushes; i++) {
      const x = R(150, W - 150), y = R(150, H - 150);
      if (!free(x, y, 30, 0)) continue;
      const n = 2 + ((rng() * 3) | 0);
      for (let k = 0; k < n; k++) {
        const bx = x + R(-45, 45), by = y + R(-45, 45);
        if (!this.solidAt(bx, by, 10) && this.terrain(bx, by) === T_NORMAL) {
          const b = { x: bx, y: by, r: R(26, 40), type: 'bush' };
          this.bushes.push(b); this.addSoft(b);
        }
      }
    }
    // pontos de loot extras
    for (let i = 0; i < 40; i++) {
      const p = this.randomFree(rng, null, 40);
      this.lootSpots.push(p);
    }
    // trilhas: praça -> vilas
    for (const v of this.villages) this.paths.push([{ x: PLAZA.x, y: PLAZA.y }, { x: (PLAZA.x + v.x) / 2 + R(-120, 120), y: (PLAZA.y + v.y) / 2 + R(-120, 120) }, { x: v.x, y: v.y }]);
  }
  addTree(x, y, rng) {
    const t = { kind: 'circle', type: 'tree', x, y, r: 11, v: (rng() * 3) | 0, s: 0.85 + rng() * 0.4 };
    this.trees.push(t); this.addSolid(t);
  }
  addRock(x, y, r, rng) {
    const o = { kind: 'circle', type: 'rock', x, y, r, v: (rng() * 3) | 0 };
    this.rocks.push(o); this.addSolid(o);
  }
}
