# SURVIVAL LIVE — Battle Arena

Battle Royale 2D de sobrevivência feito para **transmissões ao vivo do TikTok**: cada espectador que comenta `!entrar` ou `!join` vira um personagem numa arena top-down. Os bots lutam sozinhos (IA), a zona segura fecha, monstros e eventos aparecem, e o último sobrevivente vence. Presentes do TikTok viram curas, escudos, fúria, meteoros e mais.

HTML5 + CSS3 + JavaScript puro (módulos ES), Canvas 2D, Node.js só para o servidor. **Sem dependências obrigatórias.**

## Rodar (modo demonstração — não precisa de TikTok nem de internet)

Requer Node.js 18+ (testado no 22).

```bash
npm install          # opcional: só instala o conector do TikTok (opcional, veja abaixo)
npm run dev          # servidor + jogo com recarga automática do servidor
```

Abra:

| O quê | URL |
|---|---|
| **Jogo** (a tela da transmissão) | http://localhost:3000/ |
| **Painel do streamer** | http://localhost:3000/admin.html |

A porta `3000` é só o padrão: `PORT` **não é obrigatória** (`PORT=8080 npm run dev` ou `--port 8080` se quiser mudar; se estiver ocupada, o servidor tenta a próxima).

Ao abrir o jogo, ele já preenche a sala com bots (configurável: "Completar com bots até" = 0 desliga), faz a contagem de 30 s e começa. Use o painel para simular comentários, presentes, eventos e monstros.

> Os módulos ES não funcionam abrindo o `index.html` direto do disco (`file://`); use sempre o servidor (`npm run dev`/`npm start`) ou qualquer servidor estático.

## Comandos npm

| Comando | O que faz |
|---|---|
| `npm run dev` | Servidor com `--watch` (reinicia ao editar `server/`) servindo a pasta do projeto |
| `npm start` | Mesmo servidor, sem `--watch` |
| `npm run build` | Valida a sintaxe de todos os módulos e gera `dist/` (site estático). Não exige `PORT` nem variáveis de ambiente |
| `npm run preview` | Serve o `dist/` gerado |
| `npm test` | Testes headless: simulação de partidas completas, entrada por chat, presentes, eventos, servidor/WebSocket/API |
| `npm run test:e2e` | Teste ponta a ponta no navegador (precisa do Playwright instalado) |

## Usar na transmissão (TikTok LIVE Studio / OBS)

1. Rode `npm run dev` e abra o jogo (`http://localhost:3000/`) em uma janela dedicada (ou como *Browser Source* 1920×1080 no OBS). Para o som funcionar em navegador comum, clique uma vez na janela.
2. Abra o **painel** em outra aba/janela. Ele fala com o jogo pelo servidor (WebSocket) e, no mesmo navegador, também por um canal local.
3. Atalhos no jogo: `H` oculta toda a interface (só a arena aparece) · `F` tela cheia · `M` som · `P` pausa. Passe o mouse no topo para ver a barra de botões. `?ui=0` na URL já abre sem interface.

## Mapas

O jogo tem 3 mapas: **Floresta Sombria** (clássico), **Deserto das Ruínas** e **Montanha Congelada**, além de **Aleatório** (sorteia um a cada rodada).

- Escolha no painel, no cartão **🗺️ Mapa da arena**: *Aplicar e reiniciar a sala* troca na hora; *Aplicar só na próxima rodada* não interrompe a partida em andamento.
- A escolha fica salva (localStorage) e vale também após recarregar o jogo.
- Para criar outro mapa: copie um tema em `src/maps.js`, mude `id`, nome, valores de geração (`gen`) e cores (`visual`) e inclua em `MAPS` e `MAP_IDS`. Ele aparece sozinho no painel.
- Teste: `node scripts/test.js` (seção Mapas) e `node scripts/e2e-maps.cjs` (navegador, gera screenshots).

## Conectar ao TikTok LIVE (eventos reais)

O jogo **não** se conecta ao TikTok sozinho. A arquitetura é:

```
TikTok LIVE ──► server/tiktok-adapter.js ──► server/server.js ──WebSocket──► jogo (src/tiktok-bridge.js)
                (tiktok-live-connector)                                  ▲
                                          painel (admin.html) ───────────┘
```

1. `npm install tiktok-live-connector` (já está como dependência **opcional** no `package.json`).
2. No painel, seção *Conexão com o TikTok LIVE*, digite seu `@usuario` (a live precisa estar no ar) e clique **Conectar**.
3. Comentários `!entrar` / `!join` e presentes passam a chegar ao jogo.

**Avisos honestos:** `tiktok-live-connector` é uma biblioteca **não oficial** que usa endpoints não documentados do TikTok; pode quebrar, ser limitada ou violar termos de uso. Esta integração foi escrita conforme a API da biblioteca, mas **não foi testada contra uma live real** (o ambiente de desenvolvimento não tinha acesso ao TikTok). Sem a biblioteca, o painel mostra um erro claro e o modo demonstração segue funcionando. Você também pode alimentar o jogo por outra fonte enviando eventos ao servidor:

```bash
curl -X POST http://localhost:3000/api/event -d '{"type":"chat","user":"maria","text":"!entrar"}'
curl -X POST http://localhost:3000/api/event -d '{"type":"gift","user":"maria","gift":"Rose","count":1,"coins":1}'
```

Segurança: por padrão o servidor escuta só em `127.0.0.1`. Se expor na rede (`HOST=0.0.0.0`), defina `ADMIN_TOKEN=uma-senha` — comandos do painel e da API passam a exigir o token (campo "ADMIN_TOKEN" no painel).

## Ranking dos espectadores

Cada espectador tem um perfil persistente (pontos, eliminações, vitórias, partidas, presentes, nível e histórico).

- **Ver:** botão **🏅 Ranking** (ou tecla **R**) na tela do jogo — abas Geral / Mais eliminações / Mais vitórias / Mais ativos / Mais presentes, períodos Geral / Semana / Mês, ordenação, busca e perfil individual (clique no espectador). O TOP 5 também aparece no HUD.
- **Pontuação padrão:** participação +10 (partida concluída) · eliminação +25 · vitória +100 · presente pequeno +5 / médio +25 / grande +100. A faixa do presente vem do preço em moedas enviado pelo TikTok (a partir de 10 = médio, 500 = grande); sem preço, vale o tipo do presente. Tudo é configurável no painel (**🏅 Ranking dos espectadores**).
- **Níveis:** Bronze → Prata (250) → Ouro (750) → Platina (2.000) → Diamante (5.000) → Lendário (12.000), configuráveis. Prata ou acima ganha emblema ao lado do nome na arena.
- **Painel do streamer:** ver todas as estatísticas, buscar, adicionar/remover pontos, zerar ranking semanal/mensal, configurar pontuação e níveis, exportar CSV/JSON, apagar perfis simulados.
- **Persistência:** o servidor grava `data/ranking.json` (troque o caminho com `RANKING_FILE`). Sem servidor, o ranking fica no `localStorage` do navegador e é enviado ao servidor quando ele conectar. Uma janela nova (ex.: OBS) carrega o ranking do servidor. Faça backup copiando `data/ranking.json`.
- **Sem pontos duplicados:** cada evento tem um id único; o mesmo evento processado de novo (reenvio, reconexão, duas telas) é ignorado. Jogador removido pelo streamer não ganha participação, partidas reiniciadas no meio não pontuam.
- **TikTok:** comentários, presentes e eliminações usam o nome de usuário do TikTok como chave do perfil. Só eventos vindos do servidor/TikTok (ou da API `/api/event`) contam como **reais**; comentários e presentes do painel de simulação criam perfis marcados **SIM** e nunca entram na contagem de presentes reais. Você pode ocultá-los na lista ou apagá-los pelo painel.
- **Futuro banco de dados:** o servidor usa `server/ranking-store.js` (arquivo JSON). Para SQLite/Postgres/Redis, implemente a mesma interface (`apply(op)`, `snapshot()`, `importState()`, `flush()`) — o núcleo (`src/viewers.js`) não depende de armazenamento.
- Testes: `npm test` (seção 8) e `node scripts/e2e-ranking.cjs` (navegador, gera screenshots).

## Regras do jogo

- **Ciclo:** sala de espera → contagem de 30 s (assim que há o mínimo de jogadores) → partida → zona fecha em 6 estágios → último vivo vence → 12 s de comemoração → nova rodada automática.
- **Entrada:** `!entrar` / `!join`. Na sala de espera entra direto; durante a partida vai para a **fila** da próxima rodada (opção "Entrada tardia" permite entrar no 1º minuto). Se a sala encher, humanos tomam o lugar de bots, senão vão para a fila. Limite inicial: 30.
- **Estilo de luta** (opcional): o espectador comenta `!agressivo`, `!defensivo`, `!explorador` ou `!estrategico`.
- **Personagem:** 100 de vida, 100 de energia, habilidade básica **Investida** (dash, 25 energia), arma inicial aleatória. Sem respawn: quem morre vira espectador até a próxima rodada. Matar cura +12.
- **Armas:** Espada, Machado, Lança, Arco, Blaster (arma de fogo fictícia) e especiais (Cajado Arcano, Martelo do Trovão, Lança-chamas) em caixas e presentes. Cada uma com dano, alcance e velocidade próprios.
- **IA:** 4 personalidades (agressivo, defensivo, explorador, estratégico): perseguem, atacam, fogem com pouca vida, buscam cura/caixas, escondem-se em arbustos, desviam de meteoros, pântanos e da zona.
- **Monstros:** Zumbi (lento), Lobo (rápido, em matilha), Monstro Gigante (900+ de vida, pisão em área; aparece como chefe).
- **Eventos** (automáticos ou pelo painel): Chuva de Meteoros, Invasão de Zumbis, Tempestade (zona fecha 2,5× mais rápido + raios), Chefe Final, Caixa de Suprimentos.
- **Presentes** (editáveis no painel; efeitos no jogador que enviou): Rosa = cura 25 · Coração = escudo · Mini Coração = energia · TikTok = fúria · Leão = arma especial · Galáxia = meteoros · Universo = supernova · etc. Presentes sem regra usam o valor em moedas.
- **Estrutura:** `src/` é dividido em módulos — `game.js` (ciclo), `map.js`, `player.js` (personagens + IA), `enemies.js`, `combat.js`, `items.js`, `events.js`, `safe-zone.js`, `leaderboard.js`, `camera.js`, `renderer.js`/`sprites.js`, `audio.js`, `settings.js` (localStorage), `websocket.js` (com reconexão), `tiktok-bridge.js`, `main.js`/`admin.js`.

## Publicar

- **Site estático** (Netlify, Vercel, GitHub Pages, Cloudflare Pages): `npm run build` e publique a pasta `dist/`. Funciona em modo demonstração; jogo e painel conversam pelo mesmo navegador (BroadcastChannel). Sem servidor não há integração com o TikTok.
- **Com servidor** (VPS, Render, Railway, Fly…): suba o projeto, `npm install && npm start`, e defina `HOST=0.0.0.0` e `ADMIN_TOKEN`. Use HTTPS/WSS por trás de um proxy (o cliente usa `wss://` automaticamente em páginas HTTPS). `npm run preview` serve o `dist/`.

## Desempenho

Medido em Chromium headless **sem GPU** (pior caso), 1920×1080, 30 jogadores + ~15 monstros: ~44 fps; a lógica do jogo custa ~0,1 ms por passo. O canvas interno é limitado a 1920 px de largura; o chão do mapa é pré-renderizado em meia resolução e sprites são cacheados. Em PCs com aceleração gráfica o desempenho é bem melhor.
