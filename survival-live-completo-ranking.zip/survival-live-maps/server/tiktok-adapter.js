// Adaptador de eventos reais do TikTok LIVE.
// Usa a biblioteca NÃO OFICIAL "tiktok-live-connector" (opcional). Sem ela instalada,
// o adaptador informa claramente que está indisponível — nada é simulado aqui.
// Atenção: a biblioteca depende de endpoints não documentados do TikTok e pode quebrar
// ou ser bloqueada a qualquer momento. Esta integração NÃO foi testada contra uma live real.
import { EventEmitter } from 'node:events';

export class TikTokAdapter extends EventEmitter {
  constructor() {
    super();
    this.conn = null;
    this.username = null;
    this.state = 'idle';
    this.retry = 0;
    this.timer = null;
    this.wanted = false;
  }
  status(state, message) {
    this.state = state;
    this.emit('status', { state, message });
  }
  async connect(username) {
    username = String(username || '').replace(/^@/, '').trim();
    if (!/^[\w.]{2,40}$/.test(username)) return this.status('error', 'Usuário inválido');
    await this.disconnect(true);
    this.username = username; this.wanted = true;
    let lib;
    try { lib = await import('tiktok-live-connector'); }
    catch {
      this.wanted = false;
      return this.status('error', 'Pacote "tiktok-live-connector" não instalado. Rode: npm install tiktok-live-connector (o modo demonstração funciona sem ele).');
    }
    
this.status('connecting', `Conectando a @${username}…`);
try {
  const legacy = await import('tiktok-live-connector/legacy');
  const lib = await import('tiktok-live-connector');

  const Ctor = legacy.WebcastPushConnection;
  if (!Ctor) throw new Error('WebcastPushConnection não encontrada');

  const conn = (this.conn = new Ctor(username, {}));

  const on = (names, fn) => {
    for (const n of names) {
      if (n) conn.on(n, fn);
    }
  };

  const WE = lib.WebcastEvent || {};
  const CE = lib.ControlEvent || {};

  on([WE.CHAT, 'chat'], (d) => {
    const user = d.user?.uniqueId || d.uniqueId || d.user?.nickname || d.nickname;
    const text = d.comment ?? d.content ?? '';
    if (user) this.emit('event', { type: 'chat', src: 'tiktok', user, text });
  });

  on([WE.GIFT, 'gift'], (d) => {
    const gift = d.giftDetails?.giftName || d.giftName || d.extendedGiftInfo?.name;
    const streakable = (d.giftDetails?.giftType ?? d.giftType) === 1;
    const ended = d.repeatEnd === true || d.repeatEnd === 1;
    if (streakable && !ended) return;

    const user = d.user?.uniqueId || d.uniqueId || d.nickname;
    const coins = (d.giftDetails?.diamondCount ?? d.diamondCount ?? 0) * (d.repeatCount || 1);

    if (user) {
      this.emit('event', {
        type: 'gift',
        src: 'tiktok',
        user,
        gift,
        count: d.repeatCount || 1,
        coins
      });
    }
  });

  on([CE.DISCONNECTED, WE.STREAM_END, 'disconnected', 'streamEnd'], () => {
    this.status('disconnected', 'Desconectado da live');
    this.scheduleRetry();
  });

  on([CE.ERROR, 'error'], (e) => {
    this.status('error', 'Erro: ' + (e?.message || e?.info || e));
  });

  await conn.connect();

      this.retry = 0;
      this.status('connected', `Conectado à live de @${username}`);
    } catch (e) {
      this.status('error', `Falha ao conectar: ${e?.message || e}`);
      this.scheduleRetry();
    }
  }
  scheduleRetry() {
    if (!this.wanted) return;
    clearTimeout(this.timer);
    this.retry++;
    const delay = Math.min(60000, 3000 * 2 ** Math.min(this.retry, 5));
    this.timer = setTimeout(() => this.wanted && this.connect(this.username), delay);
    this.timer.unref?.();
  }
  async disconnect(silent = false) {
    this.wanted = false; clearTimeout(this.timer);
    try { await this.conn?.disconnect?.(); } catch { /* ignora */ }
    this.conn = null;
    if (!silent) this.status('idle', 'Desconectado');
  }
}
