// Armazenamento persistente do ranking no servidor (arquivo JSON, sem dependências).
// Usa o mesmo núcleo do navegador (src/viewers.js), então as regras e a deduplicação são idênticas.
// Para trocar por um banco de dados no futuro (SQLite/Postgres/Redis), basta implementar a mesma
// interface: apply(op) -> 'applied'|'dup'|'invalid', snapshot(), importState(state), flush().
import fs from 'node:fs';
import path from 'node:path';
import { ViewerStore } from '../src/viewers.js';

export class RankingStore {
  constructor(file) {
    this.file = file;
    this.timer = null;
    let state = null;
    try { if (file && fs.existsSync(file)) state = JSON.parse(fs.readFileSync(file, 'utf8')); }
    catch (e) {
      console.error(`[ranking] não foi possível ler ${file}: ${e.message}`);
      try { fs.copyFileSync(file, file + '.corrompido-' + Date.now()); } catch { /* ignora */ }
    }
    this.store = new ViewerStore(state);
    this.store.on('change', () => this.schedule());
  }
  apply(op) { return this.store.apply(op); }
  snapshot() { return this.store.snapshot(); }
  get rev() { return this.store.rev; }
  /** importa um ranking inicial (só aceito se o servidor ainda estiver vazio) */
  importState(state) {
    if (this.store.rev > 0) return false;
    const probe = new ViewerStore(state);
    if (!probe.size && probe.rev === 0) return false;
    this.store.load(probe.snapshot());
    this.schedule();
    return true;
  }
  schedule() { if (this.timer || !this.file) return; this.timer = setTimeout(() => this.flush(), 800); this.timer.unref?.(); }
  flush() {
    clearTimeout(this.timer); this.timer = null;
    if (!this.file || (this.store.rev === 0 && !fs.existsSync(this.file))) return; // nada para gravar ainda
    try {
      fs.mkdirSync(path.dirname(this.file), { recursive: true });
      const tmp = this.file + '.tmp';
      fs.writeFileSync(tmp, JSON.stringify(this.store.snapshot()));
      fs.renameSync(tmp, this.file); // gravação atômica: nunca deixa o arquivo pela metade
    } catch (e) { console.error('[ranking] falha ao salvar:', e.message); }
  }
}
