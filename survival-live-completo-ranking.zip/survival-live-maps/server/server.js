// Servidor: arquivos estáticos + WebSocket (implementação própria, sem dependências) + API de eventos.
// Uso: node server/server.js [--dir dist] [--port 3000] [--host 127.0.0.1]
// PORT é OPCIONAL (padrão 3000; se estiver ocupada, tenta as próximas).
import http from 'node:http';
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { TikTokAdapter } from './tiktok-adapter.js';
import { RankingStore } from './ranking-store.js';

const here = path.dirname(fileURLToPath(import.meta.url));
const argv = process.argv.slice(2);
const arg = (n) => { const i = argv.indexOf('--' + n); return i >= 0 ? argv[i + 1] : undefined; };
const ROOT = path.resolve(arg('dir') || process.env.STATIC_DIR || path.join(here, '..'));
const HOST = arg('host') || process.env.HOST || '127.0.0.1';
const BASE_PORT = Number(arg('port') || process.env.PORT || 3000);
const TOKEN = process.env.ADMIN_TOKEN || '';
const GUID = '258EAFA5-E914-47DA-95CA-C5AB0DC85B11';
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.json': 'application/json', '.png': 'image/png', '.jpg': 'image/jpeg', '.svg': 'image/svg+xml', '.ico': 'image/x-icon', '.mp3': 'audio/mpeg', '.ogg': 'audio/ogg', '.wav': 'audio/wav', '.woff2': 'font/woff2' };
const BLOCKED = /^\/(server|scripts|data|node_modules|\.git)(\/|$)|^\/package(-lock)?\.json$/;
const CONTROL = new Set(['cmd', 'settings', 'tiktok.connect', 'tiktok.disconnect']);

const clients = new Set();
// ranking de espectadores (persistido em data/ranking.json; RANKING_FILE troca o caminho)
const ranking = new RankingStore(process.env.RANKING_FILE || path.join(here, '..', 'data', 'ranking.json'));
let eidSeq = 0;
const nextEid = () => `s${process.pid}-${Date.now().toString(36)}-${++eidSeq}`; // id único por evento (evita pontos em dobro)

// ---------- WebSocket (RFC 6455, mínimo) ----------
function encodeFrame(str, opcode = 1) {
  const p = Buffer.from(str);
  let h;
  if (p.length < 126) h = Buffer.from([0x80 | opcode, p.length]);
  else if (p.length < 65536) { h = Buffer.alloc(4); h[0] = 0x80 | opcode; h[1] = 126; h.writeUInt16BE(p.length, 2); }
  else { h = Buffer.alloc(10); h[0] = 0x80 | opcode; h[1] = 127; h.writeBigUInt64BE(BigInt(p.length), 2); }
  return Buffer.concat([h, p]);
}
class Client {
  constructor(socket) {
    this.socket = socket; this.buf = Buffer.alloc(0); this.frag = []; this.role = 'viewer'; this.authed = !TOKEN; this.alive = true;
    socket.on('data', (d) => this.onData(d));
    socket.on('close', () => this.close());
    socket.on('error', () => this.close());
  }
  send(obj) { if (this.alive && !this.socket.destroyed) this.socket.write(encodeFrame(typeof obj === 'string' ? obj : JSON.stringify(obj))); }
  close() { if (!this.alive) return; this.alive = false; clients.delete(this); try { this.socket.destroy(); } catch { /* ignora */ } }
  onData(d) {
    this.buf = Buffer.concat([this.buf, d]);
    if (this.buf.length > 4 * 1024 * 1024) return this.close();
    for (;;) {
      const b = this.buf;
      if (b.length < 2) return;
      const fin = (b[0] & 0x80) !== 0, op = b[0] & 0x0f, masked = (b[1] & 0x80) !== 0;
      let len = b[1] & 0x7f, off = 2;
      if (len === 126) { if (b.length < 4) return; len = b.readUInt16BE(2); off = 4; }
      else if (len === 127) { if (b.length < 10) return; len = Number(b.readBigUInt64BE(2)); off = 10; }
      if (len > 1024 * 1024) return this.close();
      const need = off + (masked ? 4 : 0) + len;
      if (b.length < need) return;
      let payload = b.subarray(off + (masked ? 4 : 0), need);
      if (masked) { const m = b.subarray(off, off + 4); payload = Buffer.from(payload); for (let i = 0; i < payload.length; i++) payload[i] ^= m[i & 3]; }
      this.buf = b.subarray(need);
      if (op === 8) { try { this.socket.write(Buffer.from([0x88, 0])); } catch { /* ignora */ } return this.close(); }
      if (op === 9) { this.socket.write(encodeFrame(payload.toString(), 10)); continue; }
      if (op === 10) continue;
      if (op === 1 || op === 0) {
        this.frag.push(payload);
        if (fin) { const txt = Buffer.concat(this.frag).toString('utf8'); this.frag = []; this.onMessage(txt); }
      }
    }
  }
  onMessage(txt) {
    let m; try { m = JSON.parse(txt); } catch { return; }
    if (!m || typeof m !== 'object') return;
    if (m.type === 'hello') {
      this.role = m.role === 'admin' ? 'admin' : 'game';
      this.authed = !TOKEN || m.token === TOKEN;
      this.send({ type: 'tiktok.status', ...adapterStatus });
      broadcast({ type: 'hello', role: this.role }, this);
      return;
    }
    if (CONTROL.has(m.type) && !this.authed) { this.send({ type: 'error', message: 'Token de administrador inválido' }); return; }
    if (m.type === 'rank.op') {
      if (!this.authed) { this.send({ type: 'error', message: 'Token de administrador inválido' }); return; }
      const r = ranking.apply(m.op);
      this.send({ type: 'rank.ack', ids: [String(m.op && m.op.id)] });
      if (r !== 'applied') return; // duplicada/inválida: não repassa
    }
    if (m.type === 'tiktok.connect') { adapter.connect(m.username); return; }
    if (m.type === 'tiktok.disconnect') { adapter.disconnect(); return; }
    broadcast(m, this);
  }
}
function broadcast(msg, except) {
  const s = JSON.stringify(msg);
  for (const c of clients) if (c !== except) c.send(s);
}

// ---------- TikTok ----------
const adapter = new TikTokAdapter();
let adapterStatus = { state: 'idle', message: 'Sem conexão com o TikTok (modo demonstração)' };
adapter.on('status', (s) => { adapterStatus = s; console.log(`[tiktok] ${s.state}: ${s.message}`); broadcast({ type: 'tiktok.status', ...s }); });
adapter.on('event', (e) => broadcast({ ...e, eid: nextEid() }));

// ---------- HTTP ----------
function readBody(req, limit = 100000) {
  return new Promise((resolve, reject) => {
    let n = 0; const chunks = [];
    req.on('data', (c) => { n += c.length; if (n > limit) { reject(new Error('grande')); req.destroy(); } else chunks.push(c); });
    req.on('end', () => resolve(Buffer.concat(chunks).toString()));
    req.on('error', reject);
  });
}
const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://x');
  const json = (code, obj) => { res.writeHead(code, { 'Content-Type': 'application/json' }); res.end(JSON.stringify(obj)); };
  if (url.pathname === '/health') return json(200, { ok: true, clients: clients.size, tiktok: adapterStatus });
  // ranking persistido: GET devolve o estado; PUT importa um ranking inicial (só se o servidor estiver vazio)
  if (url.pathname === '/api/ranking') {
    if (req.method === 'GET') return json(200, { state: ranking.snapshot() });
    if (req.method === 'PUT') {
      if (TOKEN ? req.headers['x-token'] !== TOKEN : !['127.0.0.1', '::1', '::ffff:127.0.0.1'].includes(req.socket.remoteAddress)) return json(401, { error: 'token inválido' });
      try { const b = JSON.parse(await readBody(req, 8e6)); return json(200, { ok: ranking.importState(b.state) }); } catch { return json(400, { error: 'JSON inválido' }); }
    }
  }
  // API para integrações externas: POST /api/event {type:'chat'|'gift'|'cmd', ...}
  if (url.pathname === '/api/event' && req.method === 'POST') {
    if (TOKEN && req.headers['x-token'] !== TOKEN) return json(401, { error: 'token inválido' });
    try {
      const m = JSON.parse(await readBody(req));
      if (!['chat', 'gift', 'cmd', 'settings'].includes(m.type)) return json(400, { error: 'tipo inválido' });
      if ((m.type === 'cmd' || m.type === 'settings') && !TOKEN && !['127.0.0.1', '::1', '::ffff:127.0.0.1'].includes(req.socket.remoteAddress)) return json(403, { error: 'defina ADMIN_TOKEN para aceitar comandos remotos' });
      broadcast({ ...m, src: 'api', eid: m.eid ? String(m.eid).slice(0, 60) : nextEid() });
      return json(200, { ok: true });
    } catch { return json(400, { error: 'JSON inválido' }); }
  }
  if (req.method !== 'GET' && req.method !== 'HEAD') return json(405, { error: 'método não permitido' });
  let p = decodeURIComponent(url.pathname);
  if (p === '/') p = '/index.html';
  const file = path.normalize(path.join(ROOT, p));
  if (!file.startsWith(ROOT) || (ROOT === path.resolve(path.join(here, '..')) && BLOCKED.test(p))) { res.writeHead(403); return res.end('Proibido'); }
  fs.stat(file, (err, st) => {
    if (err || !st.isFile()) { res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' }); return res.end('Não encontrado'); }
    res.writeHead(200, { 'Content-Type': MIME[path.extname(file)] || 'application/octet-stream', 'Cache-Control': 'no-cache' });
    if (req.method === 'HEAD') return res.end();
    fs.createReadStream(file).pipe(res);
  });
});
server.on('upgrade', (req, socket) => {
  if (new URL(req.url, 'http://x').pathname !== '/ws' || !req.headers['sec-websocket-key']) { socket.destroy(); return; }
  socket.write(['HTTP/1.1 101 Switching Protocols', 'Upgrade: websocket', 'Connection: Upgrade', `Sec-WebSocket-Accept: ${crypto.createHash('sha1').update(req.headers['sec-websocket-key'] + GUID).digest('base64')}`, '', ''].join('\r\n'));
  socket.setNoDelay(true);
  clients.add(new Client(socket));
});

export function start(port = BASE_PORT, tries = 10) {
  return new Promise((resolve, reject) => {
    const attempt = (p, left) => {
      const onErr = (e) => { if (e.code === 'EADDRINUSE' && left > 0) attempt(p + 1, left - 1); else reject(e); };
      server.once('error', onErr);
      server.listen(p, HOST, () => { server.off('error', onErr); resolve(server.address().port); });
    };
    attempt(port, tries);
  });
}
export function stop() {
  return new Promise((resolve) => {
    for (const c of [...clients]) c.close();
    adapter.disconnect(true);
    ranking.flush();
    server.close(() => resolve());
    server.closeAllConnections?.();
  });
}
export { server, adapter, ranking };

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  if (!fs.existsSync(ROOT)) { console.error(`Pasta não encontrada: ${ROOT}. Rode "npm run build" primeiro.`); process.exit(1); }
  start().then((port) => {
    console.log(`\n  SURVIVAL LIVE rodando (${ROOT})\n  Jogo (OBS/TikTok LIVE Studio): http://${HOST === '0.0.0.0' ? 'localhost' : HOST}:${port}/\n  Painel do streamer:            http://${HOST === '0.0.0.0' ? 'localhost' : HOST}:${port}/admin.html\n  WebSocket:                     ws://${HOST}:${port}/ws${TOKEN ? '\n  Token de admin ATIVO (ADMIN_TOKEN)' : ''}\n`);
  }).catch((e) => { console.error('Falha ao iniciar o servidor:', e.message); process.exit(1); });
}
